/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 23);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_winston__ = __webpack_require__(22);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_winston___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_winston__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_path__ = __webpack_require__(21);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__config__ = __webpack_require__(3);




var logger;
if (__WEBPACK_IMPORTED_MODULE_0_winston___default.a.Logger) {
	logger = new __WEBPACK_IMPORTED_MODULE_0_winston___default.a.Logger({
		transports: [new __WEBPACK_IMPORTED_MODULE_0_winston___default.a.transports.DailyRotateFile({
			filename: function () {
				if (process.platform === "win32") {
					return __WEBPACK_IMPORTED_MODULE_1_path___default.a.resolve(process.env.APPDATA, "Zeplin", __WEBPACK_IMPORTED_MODULE_2__config__["a" /* default */].name + ".log");
				} else if (process.platform === "darwin") {
					return __WEBPACK_IMPORTED_MODULE_1_path___default.a.resolve(process.env.HOME, "Library", "Logs", "Zeplin", __WEBPACK_IMPORTED_MODULE_2__config__["a" /* default */].name + ".log");
				}
			}()
		})]
	});
} else {
	logger = {
		info: function () {
			console.log(Array.prototype.join.call(arguments, ", "));
		},
		error: function () {
			console.error(Array.prototype.join.call(arguments, ", "));
		}
	};
}
window.onerror = function (message, source, lineno, colno, error) {
	logger.error("%s:%d:%d %s %j", source, lineno, colno, message, error, {});
	return true;
};
logger.info("logger is initialized");
/* harmony default export */ __webpack_exports__["a"] = logger;

/***/ }),
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__config__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__logger__ = __webpack_require__(0);



__WEBPACK_IMPORTED_MODULE_1__logger__["a" /* default */].info("connecting to url: %s", __WEBPACK_IMPORTED_MODULE_0__config__["a" /* default */].socketUrl);
/* harmony default export */ __webpack_exports__["a"] = io.connect(__WEBPACK_IMPORTED_MODULE_0__config__["a" /* default */].socketUrl);

/***/ }),
/* 2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__logger__ = __webpack_require__(0);
/* harmony export (immutable) */ __webpack_exports__["b"] = addEventListener;
/* harmony export (immutable) */ __webpack_exports__["a"] = send;


var div = document.createElement("div");

function addEventListener(event, listener) {
    div.addEventListener(event, listener);
}

function send(event, data) {
    __WEBPACK_IMPORTED_MODULE_0__logger__["a" /* default */].info("sending " + event + ": " + data);
    div.dispatchEvent(new CustomEvent(event, { detail: data }));
}

/***/ }),
/* 3 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = {
    socketUrl: "http://127.0.0.1:17999",
    name: "io.zeplin.photoshop-panel",
    extensionId: "io.zeplin.ps.extension"
};

/***/ }),
/* 4 */,
/* 5 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_csinterface__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_csinterface___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_csinterface__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__config__ = __webpack_require__(3);



var csInterface = new __WEBPACK_IMPORTED_MODULE_0_csinterface___default.a();

function makePersistent(csInterface) {
	var event = new CSEvent("com.adobe.PhotoshopPersistent", "APPLICATION");
	event.extensionId = __WEBPACK_IMPORTED_MODULE_1__config__["a" /* default */].extensionId;
	csInterface.dispatchEvent(event);
}

/**
 * Convert the Color object to string in hexadecimal format;
 */
function toHex(color, delta) {
	function computeValue(value, delta) {
		var computedValue = !isNaN(delta) ? value + delta : value;
		if (computedValue < 0) {
			computedValue = 0;
		} else if (computedValue > 255) {
			computedValue = 255;
		}

		computedValue = computedValue.toString(16);
		return computedValue.length == 1 ? "0" + computedValue : computedValue;
	}

	var hex = "";
	if (color) {
		hex = computeValue(color.red, color.delta) + computeValue(color.green, color.delta) + computeValue(color.blue, color.delta);
	}
	return hex;
}

/**
 * Update the theme with the AppSkinInfo retrieved from the host product.
 */
function updateThemeWithAppSkinInfo(appSkinInfo) {
	var panelBackgroundColor = appSkinInfo.panelBackgroundColor.color;
	document.body.dataset.bg = "bg" + toHex(panelBackgroundColor);
}

function onAppThemeColorChanged(event) {
	// Should get a latest HostEnvironment object from application.
	var skinInfo = JSON.parse(window.__adobe_cep__.getHostEnvironment()).appSkinInfo;
	// Gets the style information such as color info from the skinInfo, 
	// and redraw all UI controls of your extension according to the style info.
	updateThemeWithAppSkinInfo(skinInfo);
}

updateThemeWithAppSkinInfo(csInterface.hostEnvironment.appSkinInfo);
// Update the color of the panel when the theme color of the product changed.
csInterface.addEventListener(__WEBPACK_IMPORTED_MODULE_0_csinterface___default.a.THEME_COLOR_CHANGED_EVENT, onAppThemeColorChanged);

makePersistent(csInterface);

/***/ }),
/* 6 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__socket__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__logger__ = __webpack_require__(0);



var tolerationDelay = 20000,
    telorationTimeoutId = 0,
    connected = false;

function onConnectError(error) {
    if (document.body.className === "connectionFailureDisplay") {
        __WEBPACK_IMPORTED_MODULE_1__logger__["a" /* default */].info("already showing connection failure display, skipping");
        return;
    }
    if (telorationTimeoutId) {
        __WEBPACK_IMPORTED_MODULE_1__logger__["a" /* default */].info("ignoring this, already setup toleration delay");
        return;
    }
    if (connected) {
        // connected before in this session already,
        __WEBPACK_IMPORTED_MODULE_1__logger__["a" /* default */].info("already connected before in this session, showing connect error right now");
        __WEBPACK_IMPORTED_MODULE_1__logger__["a" /* default */].error("connection error: %j", error, {});
        document.body.className = "connectionFailureDisplay";
        return;
    }
    __WEBPACK_IMPORTED_MODULE_1__logger__["a" /* default */].info("initial connect error, setting up toleration delay to display connection failure ");
    telorationTimeoutId = setTimeout(function () {
        __WEBPACK_IMPORTED_MODULE_1__logger__["a" /* default */].info("giving up after toleration delay");
        __WEBPACK_IMPORTED_MODULE_1__logger__["a" /* default */].error("connection error: %j", error, {});
        document.body.className = "connectionFailureDisplay";
        telorationTimeoutId = 0;
    }, tolerationDelay);
}

__WEBPACK_IMPORTED_MODULE_0__socket__["a" /* default */].on("connect_error", onConnectError);
__WEBPACK_IMPORTED_MODULE_0__socket__["a" /* default */].on("connect_timeout", onConnectError);

__WEBPACK_IMPORTED_MODULE_0__socket__["a" /* default */].on("connect", function () {
    __WEBPACK_IMPORTED_MODULE_1__logger__["a" /* default */].info("connected");
    if (telorationTimeoutId) {
        __WEBPACK_IMPORTED_MODULE_1__logger__["a" /* default */].info("clearing toleration timeout: %d", telorationTimeoutId);
        clearTimeout(telorationTimeoutId);
        telorationTimeoutId = 0;
    }
    document.body.className = "artboardSelection";
    connected = true;
});

/***/ }),
/* 7 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__socket__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__logger__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__dispatcher__ = __webpack_require__(2);




var selectProjectDiv = document.getElementById("selectProject");

__WEBPACK_IMPORTED_MODULE_0__socket__["a" /* default */].on("zeplinError", function (error) {
    __WEBPACK_IMPORTED_MODULE_1__logger__["a" /* default */].error("error recevied for zeplinError: %j", error, {});
    var el, gettingProjectsFailedTitle, planErrorText;
    if (selectProjectDiv.classList.contains("gettingOrganizationProjects")) {
        el = selectProjectDiv;
        el.classList.add("gettingProjectsFailed");
        el.classList.remove("gettingOrganizationProjects");
        gettingProjectsFailedTitle = el.querySelector(".gettingProjectsFailedTitle strong");
        planErrorText = el.querySelector(".planErrorText");
    } else {
        el = document.body;
        el.className = "gettingProjectsFailed";
        gettingProjectsFailedTitle = document.querySelector("body > .gettingProjectsFailedContent .gettingProjectsFailedTitle strong");
        planErrorText = document.querySelector("body > .gettingProjectsFailedContent .planErrorText");
    }

    el.classList.toggle("timeoutError", error.type === "timeout");
    el.classList.toggle("zeplinTokenError", error.type === "token_not_found");
    el.classList.toggle("planError", error.type === "plan");
    if (error.type === "plan") {
        gettingProjectsFailedTitle.textContent = error.title;
        planErrorText.textContent = error.message;
        localStorage.removeItem("lastSelectedProject");
    }
    if (error.type === "evict_cache") {
        localStorage.removeItem("lastSelectedProject");
        localStorage.removeItem("lastSelectedOrganization");
    }
});

[].forEach.call(document.querySelectorAll(".zeplinTokenErrorRetry"), function (zeplinTokenErrorRetry) {
    zeplinTokenErrorRetry.addEventListener("click", function (ev) {
        __WEBPACK_IMPORTED_MODULE_0__socket__["a" /* default */].emit("openZeplin");
        __WEBPACK_IMPORTED_MODULE_2__dispatcher__["a" /* send */]("goToSelectionDisplay");
    });
});

[].forEach.call(document.querySelectorAll(".gotItImPoor"), function (gotItImPoor) {
    gotItImPoor.addEventListener("click", function () {
        __WEBPACK_IMPORTED_MODULE_2__dispatcher__["a" /* send */]("goToSelectionDisplay");
    });
});

/***/ }),
/* 8 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__logger__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__socket__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__dispatcher__ = __webpack_require__(2);




var progress = document.getElementById("progress"),
    exportSelectedArtboards = document.getElementById("exportSelectedArtboards"),
    skipCheckbox = document.querySelector('input[type="checkbox"]'),
    failedLayer = document.getElementById("failedLayer"),
    failedArtboard = document.getElementById("failedArtboard"),
    report = document.getElementById("report"),
    gotIt = document.getElementById("gotIt");

function prepareReportHref(error, stack) {
    return encodeURI("mailto:support@zeplin.io?subject=Photoshop Export Error&body=I just got an error when exporting artboards from Photoshop:\n\n" + (error ? error : "") + (stack ? "\n\n" + stack : ""));
}

__WEBPACK_IMPORTED_MODULE_1__socket__["a" /* default */].on("progress", function (data) {
    __WEBPACK_IMPORTED_MODULE_0__logger__["a" /* default */].info("generator sent progress: %j", data, {});
    document.body.classList.add("withProgress");
    var progressPercentage = Math.floor(data.count / data.total * 100);
    progress.style.width = progressPercentage + "%";
});

__WEBPACK_IMPORTED_MODULE_1__socket__["a" /* default */].on("complete", function (data) {
    progress.style.width = "100%";
    __WEBPACK_IMPORTED_MODULE_0__logger__["a" /* default */].info("generator sent complete: %j", data, {});

    exportSelectedArtboards.disabled = false;
    skipCheckbox.disabled = false;
    progress.style.width = "0%";
    document.body.classList.remove("exporting", "withProgress");
    document.body.classList.add("selectionDisplay");
});

__WEBPACK_IMPORTED_MODULE_1__socket__["a" /* default */].on("parseError", function (data) {
    __WEBPACK_IMPORTED_MODULE_0__logger__["a" /* default */].error("generator sent an error: %j", data.error, {});

    failedLayer.textContent = data.layerName;
    failedLayer.classList.toggle("hidden", !data.layerName);

    failedArtboard.textContent = data.artboardName;

    report.href = prepareReportHref(data.error.message, data.error.stack);

    exportSelectedArtboards.disabled = false;
    skipCheckbox.disable = false;
    progress.style.width = "0%";
    document.body.className = "failureDisplay";
});

function onClickExport() {
    var data;
    var lastSelectedOrganization = localStorage.getItem("lastSelectedOrganization");
    if (lastSelectedOrganization && lastSelectedOrganization !== "user") {
        data = {
            oid: lastSelectedOrganization
        };
    }
    __WEBPACK_IMPORTED_MODULE_1__socket__["a" /* default */].emit("initiate", data);
    document.body.className = "gettingProjects";
}

exportSelectedArtboards.addEventListener("click", onClickExport);

__WEBPACK_IMPORTED_MODULE_2__dispatcher__["b" /* addEventListener */]("export", onClickExport);

gotIt.addEventListener("click", function (ev) {
    __WEBPACK_IMPORTED_MODULE_2__dispatcher__["a" /* send */]("goToSelectionDisplay");
});

/***/ }),
/* 9 */
/***/ (function(module, exports) {

var links = document.querySelectorAll("a");
var zeplin = document.getElementById("zeplin");
var whatINeedToChooseForDensity = document.querySelector("#selectDensityCommands .footerCommandsHeaderLine");

function openInDefaultBrowser(e) {
	e.preventDefault();
	window.cep.util.openURLInDefaultBrowser(e.target.href);
}

zeplin.addEventListener("click", function () {
	window.cep.util.openURLInDefaultBrowser("https://zeplin.io");
});

whatINeedToChooseForDensity.addEventListener("click", function () {
	window.cep.util.openURLInDefaultBrowser("https://support.zeplin.io/faq/all-the-measurements-are-wrong-halftwice-the-size");
});

for (var i = 0; i < links.length; i++) {
	links[i].addEventListener("click", openInDefaultBrowser);
}

/***/ }),
/* 10 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__socket__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__logger__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__util__ = __webpack_require__(16);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__dispatcher__ = __webpack_require__(2);





// stupid stupid hack to force repaint :(
document.body.style.display = "none";
document.body.offsetHeight;
document.body.style.display = "";

var projectsDiv = document.getElementById("projects"),
    importToProjectButton = document.getElementById("importToProject"),
    selectProjectDiv = document.getElementById("selectProject"),
    cancelProjectSelection = document.getElementById("cancelProjectSelection"),
    organizationDropdown = document.getElementById("organizationDropdown"),
    projectTemplate = document.getElementById("projectTemplate"),
    organizationsDiv = document.getElementById("organizations"),
    selectedOrganizationTextInDropdown = document.getElementById("selectedOrganization"),
    organizationTemplate = document.getElementById("organizationTemplate"),
    android = document.getElementById("android"),
    updateScreens = document.getElementById("updateScreens"),
    skipCheckbox = document.querySelector('input[type="checkbox"]'),
    exportSelectedArtboards = document.getElementById("exportSelectedArtboards"),
    predictedDensity = {};

var emojiRegex = /(?:0\u20E3|1\u20E3|2\u20E3|3\u20E3|4\u20E3|5\u20E3|6\u20E3|7\u20E3|8\u20E3|9\u20E3|#\u20E3|\*\u20E3|\uD83C(?:\uDDE6\uD83C(?:\uDDE8|\uDDE9|\uDDEA|\uDDEB|\uDDEC|\uDDEE|\uDDF1|\uDDF2|\uDDF4|\uDDF6|\uDDF7|\uDDF8|\uDDF9|\uDDFA|\uDDFC|\uDDFD|\uDDFF)|\uDDE7\uD83C(?:\uDDE6|\uDDE7|\uDDE9|\uDDEA|\uDDEB|\uDDEC|\uDDED|\uDDEE|\uDDEF|\uDDF1|\uDDF2|\uDDF3|\uDDF4|\uDDF6|\uDDF7|\uDDF8|\uDDF9|\uDDFB|\uDDFC|\uDDFE|\uDDFF)|\uDDE8\uD83C(?:\uDDE6|\uDDE8|\uDDE9|\uDDEB|\uDDEC|\uDDED|\uDDEE|\uDDF0|\uDDF1|\uDDF2|\uDDF3|\uDDF4|\uDDF5|\uDDF7|\uDDFA|\uDDFB|\uDDFC|\uDDFD|\uDDFE|\uDDFF)|\uDDE9\uD83C(?:\uDDEA|\uDDEC|\uDDEF|\uDDF0|\uDDF2|\uDDF4|\uDDFF)|\uDDEA\uD83C(?:\uDDE6|\uDDE8|\uDDEA|\uDDEC|\uDDED|\uDDF7|\uDDF8|\uDDF9|\uDDFA)|\uDDEB\uD83C(?:\uDDEE|\uDDEF|\uDDF0|\uDDF2|\uDDF4|\uDDF7)|\uDDEC\uD83C(?:\uDDE6|\uDDE7|\uDDE9|\uDDEA|\uDDEB|\uDDEC|\uDDED|\uDDEE|\uDDF1|\uDDF2|\uDDF3|\uDDF5|\uDDF6|\uDDF7|\uDDF8|\uDDF9|\uDDFA|\uDDFC|\uDDFE)|\uDDED\uD83C(?:\uDDF0|\uDDF2|\uDDF3|\uDDF7|\uDDF9|\uDDFA)|\uDDEE\uD83C(?:\uDDE8|\uDDE9|\uDDEA|\uDDF1|\uDDF2|\uDDF3|\uDDF4|\uDDF6|\uDDF7|\uDDF8|\uDDF9)|\uDDEF\uD83C(?:\uDDEA|\uDDF2|\uDDF4|\uDDF5)|\uDDF0\uD83C(?:\uDDEA|\uDDEC|\uDDED|\uDDEE|\uDDF2|\uDDF3|\uDDF5|\uDDF7|\uDDFC|\uDDFE|\uDDFF)|\uDDF1\uD83C(?:\uDDE6|\uDDE7|\uDDE8|\uDDEE|\uDDF0|\uDDF7|\uDDF8|\uDDF9|\uDDFA|\uDDFB|\uDDFE)|\uDDF2\uD83C(?:\uDDE6|\uDDE8|\uDDE9|\uDDEA|\uDDEB|\uDDEC|\uDDED|\uDDF0|\uDDF1|\uDDF2|\uDDF3|\uDDF4|\uDDF5|\uDDF6|\uDDF7|\uDDF8|\uDDF9|\uDDFA|\uDDFB|\uDDFC|\uDDFD|\uDDFE|\uDDFF)|\uDDF3\uD83C(?:\uDDE6|\uDDE8|\uDDEA|\uDDEB|\uDDEC|\uDDEE|\uDDF1|\uDDF4|\uDDF5|\uDDF7|\uDDFA|\uDDFF)|\uDDF4\uD83C\uDDF2|\uDDF5\uD83C(?:\uDDE6|\uDDEA|\uDDEB|\uDDEC|\uDDED|\uDDF0|\uDDF1|\uDDF2|\uDDF3|\uDDF7|\uDDF8|\uDDF9|\uDDFC|\uDDFE)|\uDDF6\uD83C\uDDE6|\uDDF7\uD83C(?:\uDDEA|\uDDF4|\uDDF8|\uDDFA|\uDDFC)|\uDDF8\uD83C(?:\uDDE6|\uDDE7|\uDDE8|\uDDE9|\uDDEA|\uDDEC|\uDDED|\uDDEE|\uDDEF|\uDDF0|\uDDF1|\uDDF2|\uDDF3|\uDDF4|\uDDF7|\uDDF8|\uDDF9|\uDDFB|\uDDFD|\uDDFE|\uDDFF)|\uDDF9\uD83C(?:\uDDE6|\uDDE8|\uDDE9|\uDDEB|\uDDEC|\uDDED|\uDDEF|\uDDF0|\uDDF1|\uDDF2|\uDDF3|\uDDF4|\uDDF7|\uDDF9|\uDDFB|\uDDFC|\uDDFF)|\uDDFA\uD83C(?:\uDDE6|\uDDEC|\uDDF2|\uDDF8|\uDDFE|\uDDFF)|\uDDFB\uD83C(?:\uDDE6|\uDDE8|\uDDEA|\uDDEC|\uDDEE|\uDDF3|\uDDFA)|\uDDFC\uD83C(?:\uDDEB|\uDDF8)|\uDDFD\uD83C\uDDF0|\uDDFE\uD83C(?:\uDDEA|\uDDF9)|\uDDFF\uD83C(?:\uDDE6|\uDDF2|\uDDFC)))|[\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u231A\u231B\u2328\u23CF\u23E9-\u23F3\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB-\u25FE\u2600-\u2604\u260E\u2611\u2614\u2615\u2618\u261D\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2648-\u2653\u2660\u2663\u2665\u2666\u2668\u267B\u267F\u2692-\u2694\u2696\u2697\u2699\u269B\u269C\u26A0\u26A1\u26AA\u26AB\u26B0\u26B1\u26BD\u26BE\u26C4\u26C5\u26C8\u26CE\u26CF\u26D1\u26D3\u26D4\u26E9\u26EA\u26F0-\u26F5\u26F7-\u26FA\u26FD\u2702\u2705\u2708-\u270D\u270F\u2712\u2714\u2716\u271D\u2721\u2728\u2733\u2734\u2744\u2747\u274C\u274E\u2753-\u2755\u2757\u2763\u2764\u2795-\u2797\u27A1\u27B0\u27BF\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B50\u2B55\u3030\u303D\u3297\u3299]|\uD83C[\uDC04\uDCCF\uDD70\uDD71\uDD7E\uDD7F\uDD8E\uDD91-\uDD9A\uDE01\uDE02\uDE1A\uDE2F\uDE32-\uDE3A\uDE50\uDE51\uDF00-\uDF21\uDF24-\uDF93\uDF96\uDF97\uDF99-\uDF9B\uDF9E-\uDFF0\uDFF3-\uDFF5\uDFF7-\uDFFF]|\uD83D[\uDC00-\uDCFD\uDCFF-\uDD3D\uDD49-\uDD4E\uDD50-\uDD67\uDD6F\uDD70\uDD73-\uDD79\uDD87\uDD8A-\uDD8D\uDD90\uDD95\uDD96\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDEF\uDDF3\uDDFA-\uDE4F\uDE80-\uDEC5\uDECB-\uDED0\uDEE0-\uDEE5\uDEE9\uDEEB\uDEEC\uDEF0\uDEF3]|\uD83E[\uDD10-\uDD18\uDD80-\uDD84\uDDC0]/g;
function handleProjects(projects) {
	document.body.className = "projectSelection";
	projectsDiv.innerHTML = "";
	importToProjectButton.disabled = true;

	if (selectProjectDiv.classList.contains("designerWithOrganization")) {
		selectProjectDiv.classList.remove("gettingOrganizationProjects");
		cancelProjectSelection.disabled = false;
		organizationDropdown.disabled = false;
	}

	var lastSelectedProject = localStorage.getItem("lastSelectedProject");

	document.body.classList.toggle("noProjects", !projects.length);

	var projectToSelect = projects.reduce(function (prev, project, index) {
		var newProject = document.importNode(projectTemplate.content, true);

		newProject.querySelector(".projectName").textContent = project.name.replace(emojiRegex, '').trim();

		newProject.querySelector(".project").dataset.type = project.type;

		newProject.querySelector(".project").dataset.pid = project.pid;
		newProject.querySelector(".project").dataset.density = project.density;

		newProject.querySelector(".projectIcon").dataset.type = project.icon.type;

		newProject.querySelector(".project").dataset.index = index;

		projectsDiv.appendChild(newProject);
		if (prev !== -1) {
			return prev;
		} else if (lastSelectedProject && lastSelectedProject === project.pid) {
			return index;
		} else {
			return prev;
		}
	}, -1);

	selectedProjectIndex = undefined;
	if (projectToSelect !== -1) {
		selectProject(projectToSelect);
	}
}

var selectedProjectIndex;
function selectProject(index) {
	var selectedProject;
	if (selectedProjectIndex !== undefined) {
		selectedProject = projectsDiv.querySelector('.project[data-index="' + selectedProjectIndex + '"]');
		selectedProject.classList.remove("selected");
	}

	selectedProjectIndex = parseInt(index, 10);
	selectedProject = projectsDiv.querySelector('.project[data-index="' + selectedProjectIndex + '"]');
	selectedProject.classList.add("selected");

	var container = selectProjectDiv.classList.contains("designerWithOrganization") ? selectProjectContent : projectsDiv;
	__WEBPACK_IMPORTED_MODULE_2__util__["a" /* scrollIfNecessary */](selectedProject, container);

	importToProjectButton.disabled = false;
	localStorage.setItem("lastSelectedProject", selectedProject.dataset.pid);
}

__WEBPACK_IMPORTED_MODULE_0__socket__["a" /* default */].on("projectsV2", function (projectsData) {
	var projects = JSON.parse(projectsData);
	handleProjects(projects);
});

__WEBPACK_IMPORTED_MODULE_0__socket__["a" /* default */].on("projectsWithOrganizations", function (data) {
	var dataJSON = JSON.parse(data);

	var projects = dataJSON.projects;
	var organizations = dataJSON.organizations;
	var profiles = dataJSON.profiles;
	var oid = dataJSON.oid;

	predictedDensity = dataJSON.predictedDensity || {};

	var userCantUploadDesigns = false;

	if (organizations && organizations.length > 0) {
		organizationsDiv.innerHTML = "";
		selectedOrganizationTextInDropdown.classList.remove("nonPersonal");
		selectProjectDiv.classList.remove("listingOrganizationProjects");
		document.body.classList.remove("userCantUploadDesigns");
		selectedOrganizationTextInDropdown.textContent = "Personal projects";

		var newOrganization = document.importNode(organizationTemplate.content, true);

		newOrganization.querySelector(".organizationName").textContent = "Personal projects";
		newOrganization.querySelector(".organization").classList.add("selected");
		newOrganization.querySelector(".organization").dataset.oid = "user";

		organizationsDiv.appendChild(newOrganization);

		organizations.forEach(function (organization) {
			var newOrganization = document.importNode(organizationTemplate.content, true);

			newOrganization.querySelector(".organizationName").textContent = organization.name.replace(emojiRegex, '').trim();
			newOrganization.querySelector(".organization").dataset.oid = organization.oid;
			if (profiles[organization.oid]) {
				newOrganization.querySelector(".organization").dataset.userRole = profiles[organization.oid];
			}

			organizationsDiv.appendChild(newOrganization);
		});

		if (oid) {
			organizationsDiv.querySelector(".selected").classList.remove("selected");

			var organizationEl = organizationsDiv.querySelector('.organization[data-oid="' + oid + '"]');
			organizationEl.classList.add("selected");

			selectedOrganizationTextInDropdown.textContent = organizationEl.querySelector(".organizationName").textContent;
			selectedOrganizationTextInDropdown.classList.add("nonPersonal");
			selectProjectDiv.classList.add("listingOrganizationProjects");

			userCantUploadDesigns = organizationEl.dataset.oid !== "user" && organizationEl.dataset.userRole === "knight";
			document.body.className = "projectSelection";
			document.body.classList.toggle("userCantUploadDesigns", userCantUploadDesigns);
			importToProjectButton.disabled = true;
		}

		selectProjectDiv.classList.add("designerWithOrganization");
	}

	if (!userCantUploadDesigns) {
		handleProjects(projects);
	}
});

document.addEventListener("click", function () {
	organizationsDiv.classList.add("hidden");
});

organizationDropdown.addEventListener("click", function (ev) {
	ev.stopPropagation();
	organizationsDiv.classList.toggle("hidden");
});

function getOrganizationProjects(organizationEl) {
	localStorage.setItem("lastSelectedOrganization", organizationEl.dataset.oid);
	var oid;
	if (organizationEl.dataset.oid !== "user") {
		oid = organizationEl.dataset.oid;
	}
	__WEBPACK_IMPORTED_MODULE_0__socket__["a" /* default */].emit("getProjects", oid);
	selectProjectDiv.classList.add("gettingOrganizationProjects");
	organizationDropdown.disabled = true;
	importToProjectButton.disabled = true;
	cancelProjectSelection.disabled = true;
}

organizationsDiv.addEventListener("click", function (ev) {
	var organization = ev.target;

	while (organization && !organization.classList.contains("organization")) {
		organization = organization.parentElement;
	}

	if (!organization) {
		return;
	}

	ev.stopPropagation();

	var prevSelectedOrganization = organizationsDiv.querySelector(".selected");
	if (prevSelectedOrganization) {
		prevSelectedOrganization.classList.remove("selected");
	}
	organization.classList.add("selected");

	selectedOrganizationTextInDropdown.textContent = organization.querySelector(".organizationName").textContent;
	selectedOrganizationTextInDropdown.classList.toggle("nonPersonal", organization.dataset.oid !== "user");
	selectProjectDiv.classList.toggle("listingOrganizationProjects", organization.dataset.oid !== "user");

	organizationsDiv.classList.add("hidden");

	var userCantUploadDesigns = organization.dataset.oid !== "user" && organization.dataset.userRole === "knight";
	document.body.classList.toggle("userCantUploadDesigns", userCantUploadDesigns);
	document.body.classList.remove("noProjects");
	importToProjectButton.disabled = true;
	if (!userCantUploadDesigns) {
		getOrganizationProjects(organization);
	}
});

__WEBPACK_IMPORTED_MODULE_3__dispatcher__["b" /* addEventListener */]("getOrganizationProjects", function (event) {
	selectProjectDiv.className = "designerWithOrganization";
	getOrganizationProjects(event.detail);
});

projectsDiv.addEventListener("click", function (ev) {
	var project = ev.target;

	while (project && !project.classList.contains("project")) {
		project = project.parentElement;
	}

	if (!project) {
		return;
	}

	selectProject(project.dataset.index);
});

function importToProject(project) {
	localStorage.setItem("lastSelectedProject", project.dataset.pid);

	var selectedOrganization = organizationsDiv.querySelector(".organization.selected");
	if (selectedOrganization) {
		localStorage.setItem("lastSelectedOrganization", selectedOrganization.dataset.oid);
	}

	var densityToChoose = project.dataset.density;
	if (densityToChoose === "unknown") {
		if (!predictedDensity[project.dataset.type]) {
			document.body.className = "densitySelection";
			document.body.classList.add(project.dataset.type);
			return;
		}
		densityToChoose = predictedDensity[project.dataset.type];
	}

	__WEBPACK_IMPORTED_MODULE_0__socket__["a" /* default */].emit("export", {
		pid: project.dataset.pid,
		density: densityToChoose,
		type: project.dataset.type,
		replace: updateScreens.checked
	});

	exportSelectedArtboards.disabled = true;
	skipCheckbox.disabled = true;

	document.body.className = "selectionDisplay";
	document.body.classList.add("exporting");
}

projectsDiv.addEventListener("dblclick", function (ev) {
	var project = ev.target;

	while (project && !project.classList.contains("project")) {
		project = project.parentElement;
	}

	if (!project) {
		return;
	}

	importToProject(project);
});

importToProjectButton.addEventListener("click", function (ev) {
	var project = projectsDiv.querySelector(".project.selected");

	if (!project) {
		return;
	}

	importToProject(project);
});

cancelProjectSelection.addEventListener("click", function () {
	goToSelectionDisplay();
});

function goToSelectionDisplay() {
	exportSelectedArtboards.disabled = false;
	skipCheckbox.disabled = false;

	document.body.className = "selectionDisplay";
}

__WEBPACK_IMPORTED_MODULE_3__dispatcher__["b" /* addEventListener */]("goToSelectionDisplay", goToSelectionDisplay);

cancelDensitySelection.addEventListener("click", function () {
	goToSelectionDisplay();
});

chooseDensity.addEventListener("click", function () {
	var project = projectsDiv.querySelector(".project.selected");
	var projectType = project.dataset.type;
	if (projectType === "osx") {
		projectType = "ios";
	}
	var selectedDensity = document.querySelector('input[type="radio"][name="' + projectType + 'Density"]:checked').value;
	project.dataset.density = selectedDensity;
	importToProject(project);
});

function repaintAndroidDensities() {
	var scrollTop = android.parentElement.scrollTop;
	android.style.display = "none";
	android.offsetHeight;
	android.style.display = "";
	android.parentElement.scrollTop = scrollTop;
}

[].forEach.call(document.querySelectorAll('input[type="radio"][name="androidDensity"]'), function (phoneRadio) {
	phoneRadio.addEventListener("change", function (ev) {
		var tabletRadio = document.querySelector('input[type="radio"][name="tabletDensity"][value="' + ev.target.value + '"]');
		if (tabletRadio) {
			tabletRadio.checked = true;
		} else {
			tabletRadio = document.querySelector('input[type="radio"][name="tabletDensity"]:checked');
			if (tabletRadio) {
				tabletRadio.checked = false;
			}
		}
		repaintAndroidDensities();
	});
});

[].forEach.call(document.querySelectorAll('input[type="radio"][name="tabletDensity"]'), function (tabletRadio) {
	tabletRadio.addEventListener("change", function (ev) {
		var phoneRadio = document.querySelector('input[type="radio"][name="androidDensity"][value="' + ev.target.value + '"]');
		if (phoneRadio) {
			phoneRadio.checked = true;
		}
		repaintAndroidDensities();
	});
});

updateScreens.checked = function () {
	var replaceScreens = localStorage.getItem("replaceScreens");
	if (replaceScreens && replaceScreens === "false") {
		return false;
	} else {
		return true;
	}
}();
updateScreens.addEventListener("change", function (ev) {
	localStorage.setItem("replaceScreens", updateScreens.checked);
});

/***/ }),
/* 11 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__dispatcher__ = __webpack_require__(2);


function onClickRetry(ev) {
	var gettingProjectsFailed = ev.target;

	while (gettingProjectsFailed && !gettingProjectsFailed.classList.contains("gettingProjectsFailed")) {
		gettingProjectsFailed = gettingProjectsFailed.parentElement;
	}

	if (!gettingProjectsFailed) {
		return;
	}

	var selectedOrganization = gettingProjectsFailed.querySelector(".organization.selected");

	if (selectedOrganization) {
		__WEBPACK_IMPORTED_MODULE_0__dispatcher__["a" /* send */]("getOrganizationProjects", selectedOrganization);
	} else {
		__WEBPACK_IMPORTED_MODULE_0__dispatcher__["a" /* send */]("export");
	}
}

[].forEach.call(document.querySelectorAll(".retry"), function (retry) {
	retry.addEventListener("click", onClickRetry);
});

/***/ }),
/* 12 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__socket__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__logger__ = __webpack_require__(0);



var main = document.querySelector("main"),
    selectedArtboardInformation = document.getElementById("selectedArtboardInformation"),
    selectProjectDiv = document.getElementById("selectProject"),
    exportSelectedArtboards = document.getElementById("exportSelectedArtboards"),
    skipCheckbox = document.querySelector('input[type="checkbox"]'),
    exportingOne = document.querySelector("#exportingOne span"),
    exportingMany = document.querySelector("#exportingMany span"),
    selectedLayerCount = document.querySelector("#selectedLayerInformation strong"),
    selectedLayerGroupCount = document.querySelector("#selectedLayerGroupInformation strong"),
    markAsAsset = document.getElementById("markAsAsset"),
    unmarkAsAsset = document.getElementById("unmarkAsAsset"),
    selectedLayers = [];

function processArtboardSelection(artboardCount, selectionCount) {
	var returnEarly = false;
	if (artboardCount > 0) {
		document.body.className = "selectionDisplay";
		selectedArtboardCount.textContent = artboardCount;
		if (artboardCount > 1) {
			selectedArtboardInformation.dataset.many = true;
		} else {
			delete selectedArtboardInformation.dataset.many;
		}
	} else {
		document.body.className = "artboardSelection";
		if (artboardCount === 0 && selectionCount > 0) {
			document.body.className = "noArtboardSelected";
			document.body.classList.toggle("selectedMultipleLayers", selectionCount > 1);
		}
		returnEarly = true;
	}
	return returnEarly;
}

function updateSelectionInfo(selection, artboards) {
	if (document.body.classList.contains("gettingProjects") || selectProjectDiv.classList.contains("gettingOrganizationProjects")) {
		return;
	}
	exportSelectedArtboards.disabled = false;
	skipCheckbox.disabled = false;
	selectedLayers = selection;

	if (selection) {
		var artboardCount = artboards.length;
		if (processArtboardSelection(artboardCount, selection.length)) {
			return;
		}
		main.dataset.artboardCount = artboardCount;

		var layers = selection.filter(function (item) {
			return item.type === "layer";
		});
		var layerGroups = selection.filter(function (item) {
			return item.type === "layerSection";
		});

		if (artboardCount === 1) {
			exportingOne.textContent = artboards[0].name;
		} else if (artboardCount > 1) {
			exportingMany.textContent = artboardCount;
		}

		selectedLayerCount.textContent = layers.length;
		selectedLayerCount.classList.toggle("manyLayers", layers.length > 1);

		selectedLayerGroupCount.textContent = layerGroups.length;
		selectedLayerGroupCount.classList.toggle("manyLayerGroups", layerGroups.length > 1);

		if (layerGroups.length >= 1 && artboardCount === 1 && layers.length === 0) {
			var exportableLayerGroupCount = layerGroups.filter(function (layerGroup) {
				return layerGroup.exportable;
			}).length;

			if (exportableLayerGroupCount > 0) {
				document.body.classList.add("markLayerGroupAsAsset");
			} else {
				document.body.classList.add("unmarkLayerGroupAsAsset");
			}

			if (layerGroups.length === 1) {
				document.body.classList.add("oneLayerGroup");
				skipCheckbox.checked = !layerGroups[0].skippable;
			}
		} else if (layers.length > 0) {
			var exportableLayerCount = selection.filter(function (layer) {
				return layer.exportable;
			}).length;

			if (exportableLayerCount > 0) {
				document.body.classList.add("markLayerAsAsset");
			} else {
				document.body.classList.add("unmarkLayerAsAsset");
			}
		}
	}
}

__WEBPACK_IMPORTED_MODULE_0__socket__["a" /* default */].on("activeDocumentChanged", function (data) {
	__WEBPACK_IMPORTED_MODULE_1__logger__["a" /* default */].info("activeDocumentChanged: %j", data, {});
	updateSelectionInfo(data.selection, data.artboards);
});

markAsAsset.addEventListener("click", function (ev) {
	__WEBPACK_IMPORTED_MODULE_0__socket__["a" /* default */].emit("rename", {
		export: true,
		skip: false,
		layers: selectedLayers,
		checked: true
	});
});

unmarkAsAsset.addEventListener("click", function (ev) {
	__WEBPACK_IMPORTED_MODULE_0__socket__["a" /* default */].emit("rename", {
		export: true,
		skip: false,
		layer: selectedLayers,
		checked: false
	});
});

skipCheckbox.addEventListener("change", function (ev) {
	__WEBPACK_IMPORTED_MODULE_0__socket__["a" /* default */].emit("rename", {
		export: false,
		skip: true,
		layers: selectedLayers,
		checked: ev.target.checked
	});
});

/***/ }),
/* 13 */,
/* 14 */,
/* 15 */,
/* 16 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = scrollIfNecessary;
function getFirstScrollableParent(element) {
	var container = element.parentElement;

	// find first scrollable container
	while (container && container.scrollHeight <= container.clientHeight) {
		container = container.parentElement;
	}

	return container;
}

function scrollIfNecessary(element, container) {
	container = container || getFirstScrollableParent(element);

	if (!container) {
		return;
	}

	var elementRect = element.getBoundingClientRect(),
	    containerRect = container.getBoundingClientRect();

	if (elementRect.top < containerRect.top) {
		container.scrollTop -= containerRect.top - elementRect.top;
	} else if (elementRect.bottom > containerRect.bottom) {
		container.scrollTop += elementRect.bottom - containerRect.bottom;
	}
}

/***/ }),
/* 17 */,
/* 18 */,
/* 19 */,
/* 20 */
/***/ (function(module, exports) {

module.exports = CSInterface;

/***/ }),
/* 21 */
/***/ (function(module, exports) {

module.exports = path;

/***/ }),
/* 22 */
/***/ (function(module, exports) {

module.exports = winston;

/***/ }),
/* 23 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__socket__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__bgcolor__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__connection__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__selection__ = __webpack_require__(12);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__export__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__projects__ = __webpack_require__(10);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__retry__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__error__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__links__ = __webpack_require__(9);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__links___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__links__);










/***/ })
/******/ ]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAgMzIzYmFkMWJhNTQ1MmM1ODMwYTQiLCJ3ZWJwYWNrOi8vLy4uL0V4dGVuc2lvbkNvbnRlbnQvc3JjL2xvZ2dlci5qcyIsIndlYnBhY2s6Ly8vLi4vRXh0ZW5zaW9uQ29udGVudC9zcmMvc29ja2V0LmpzIiwid2VicGFjazovLy8uLi9FeHRlbnNpb25Db250ZW50L3NyYy9kaXNwYXRjaGVyLmpzIiwid2VicGFjazovLy8uLi9FeHRlbnNpb25Db250ZW50L3NyYy9jb25maWcuanMiLCJ3ZWJwYWNrOi8vLy4uL0V4dGVuc2lvbkNvbnRlbnQvc3JjL2JnY29sb3IuanMiLCJ3ZWJwYWNrOi8vLy4uL0V4dGVuc2lvbkNvbnRlbnQvc3JjL2Nvbm5lY3Rpb24uanMiLCJ3ZWJwYWNrOi8vLy4uL0V4dGVuc2lvbkNvbnRlbnQvc3JjL2Vycm9yLmpzIiwid2VicGFjazovLy8uLi9FeHRlbnNpb25Db250ZW50L3NyYy9leHBvcnQuanMiLCJ3ZWJwYWNrOi8vLy4uL0V4dGVuc2lvbkNvbnRlbnQvc3JjL2xpbmtzLmpzIiwid2VicGFjazovLy8uLi9FeHRlbnNpb25Db250ZW50L3NyYy9wcm9qZWN0cy5qcyIsIndlYnBhY2s6Ly8vLi4vRXh0ZW5zaW9uQ29udGVudC9zcmMvcmV0cnkuanMiLCJ3ZWJwYWNrOi8vLy4uL0V4dGVuc2lvbkNvbnRlbnQvc3JjL3NlbGVjdGlvbi5qcyIsIndlYnBhY2s6Ly8vLi4vRXh0ZW5zaW9uQ29udGVudC9zcmMvdXRpbC5qcyIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJDU0ludGVyZmFjZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInBhdGhcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJ3aW5zdG9uXCIiLCJ3ZWJwYWNrOi8vLy4uL0V4dGVuc2lvbkNvbnRlbnQvc3JjL2V4dGVuc2lvbi5qcyJdLCJuYW1lcyI6WyJsb2dnZXIiLCJ3aW5zdG9uIiwiTG9nZ2VyIiwidHJhbnNwb3J0cyIsIkRhaWx5Um90YXRlRmlsZSIsImZpbGVuYW1lIiwicHJvY2VzcyIsInBsYXRmb3JtIiwicGF0aCIsInJlc29sdmUiLCJlbnYiLCJBUFBEQVRBIiwiUGFuZWxDb25maWciLCJuYW1lIiwiSE9NRSIsImluZm8iLCJjb25zb2xlIiwibG9nIiwiQXJyYXkiLCJwcm90b3R5cGUiLCJqb2luIiwiY2FsbCIsImFyZ3VtZW50cyIsImVycm9yIiwid2luZG93Iiwib25lcnJvciIsIm1lc3NhZ2UiLCJzb3VyY2UiLCJsaW5lbm8iLCJjb2xubyIsInNvY2tldFVybCIsImlvIiwiY29ubmVjdCIsImRpdiIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImFkZEV2ZW50TGlzdGVuZXIiLCJldmVudCIsImxpc3RlbmVyIiwic2VuZCIsImRhdGEiLCJkaXNwYXRjaEV2ZW50IiwiQ3VzdG9tRXZlbnQiLCJkZXRhaWwiLCJleHRlbnNpb25JZCIsImNzSW50ZXJmYWNlIiwibWFrZVBlcnNpc3RlbnQiLCJDU0V2ZW50IiwidG9IZXgiLCJjb2xvciIsImRlbHRhIiwiY29tcHV0ZVZhbHVlIiwidmFsdWUiLCJjb21wdXRlZFZhbHVlIiwiaXNOYU4iLCJ0b1N0cmluZyIsImxlbmd0aCIsImhleCIsInJlZCIsImdyZWVuIiwiYmx1ZSIsInVwZGF0ZVRoZW1lV2l0aEFwcFNraW5JbmZvIiwiYXBwU2tpbkluZm8iLCJwYW5lbEJhY2tncm91bmRDb2xvciIsImJvZHkiLCJkYXRhc2V0IiwiYmciLCJvbkFwcFRoZW1lQ29sb3JDaGFuZ2VkIiwic2tpbkluZm8iLCJKU09OIiwicGFyc2UiLCJfX2Fkb2JlX2NlcF9fIiwiZ2V0SG9zdEVudmlyb25tZW50IiwiaG9zdEVudmlyb25tZW50IiwiQ1NJbnRlcmZhY2UiLCJUSEVNRV9DT0xPUl9DSEFOR0VEX0VWRU5UIiwidG9sZXJhdGlvbkRlbGF5IiwidGVsb3JhdGlvblRpbWVvdXRJZCIsImNvbm5lY3RlZCIsIm9uQ29ubmVjdEVycm9yIiwiY2xhc3NOYW1lIiwic2V0VGltZW91dCIsInNvY2tldCIsIm9uIiwiY2xlYXJUaW1lb3V0Iiwic2VsZWN0UHJvamVjdERpdiIsImdldEVsZW1lbnRCeUlkIiwiZWwiLCJnZXR0aW5nUHJvamVjdHNGYWlsZWRUaXRsZSIsInBsYW5FcnJvclRleHQiLCJjbGFzc0xpc3QiLCJjb250YWlucyIsImFkZCIsInJlbW92ZSIsInF1ZXJ5U2VsZWN0b3IiLCJ0b2dnbGUiLCJ0eXBlIiwidGV4dENvbnRlbnQiLCJ0aXRsZSIsImxvY2FsU3RvcmFnZSIsInJlbW92ZUl0ZW0iLCJmb3JFYWNoIiwicXVlcnlTZWxlY3RvckFsbCIsInplcGxpblRva2VuRXJyb3JSZXRyeSIsImV2IiwiZW1pdCIsImRpc3BhdGNoZXIiLCJnb3RJdEltUG9vciIsInByb2dyZXNzIiwiZXhwb3J0U2VsZWN0ZWRBcnRib2FyZHMiLCJza2lwQ2hlY2tib3giLCJmYWlsZWRMYXllciIsImZhaWxlZEFydGJvYXJkIiwicmVwb3J0IiwiZ290SXQiLCJwcmVwYXJlUmVwb3J0SHJlZiIsInN0YWNrIiwiZW5jb2RlVVJJIiwicHJvZ3Jlc3NQZXJjZW50YWdlIiwiTWF0aCIsImZsb29yIiwiY291bnQiLCJ0b3RhbCIsInN0eWxlIiwid2lkdGgiLCJkaXNhYmxlZCIsImxheWVyTmFtZSIsImFydGJvYXJkTmFtZSIsImhyZWYiLCJkaXNhYmxlIiwib25DbGlja0V4cG9ydCIsImxhc3RTZWxlY3RlZE9yZ2FuaXphdGlvbiIsImdldEl0ZW0iLCJvaWQiLCJsaW5rcyIsInplcGxpbiIsIndoYXRJTmVlZFRvQ2hvb3NlRm9yRGVuc2l0eSIsIm9wZW5JbkRlZmF1bHRCcm93c2VyIiwiZSIsInByZXZlbnREZWZhdWx0IiwiY2VwIiwidXRpbCIsIm9wZW5VUkxJbkRlZmF1bHRCcm93c2VyIiwidGFyZ2V0IiwiaSIsImRpc3BsYXkiLCJvZmZzZXRIZWlnaHQiLCJwcm9qZWN0c0RpdiIsImltcG9ydFRvUHJvamVjdEJ1dHRvbiIsImNhbmNlbFByb2plY3RTZWxlY3Rpb24iLCJvcmdhbml6YXRpb25Ecm9wZG93biIsInByb2plY3RUZW1wbGF0ZSIsIm9yZ2FuaXphdGlvbnNEaXYiLCJzZWxlY3RlZE9yZ2FuaXphdGlvblRleHRJbkRyb3Bkb3duIiwib3JnYW5pemF0aW9uVGVtcGxhdGUiLCJhbmRyb2lkIiwidXBkYXRlU2NyZWVucyIsInByZWRpY3RlZERlbnNpdHkiLCJlbW9qaVJlZ2V4IiwiaGFuZGxlUHJvamVjdHMiLCJwcm9qZWN0cyIsImlubmVySFRNTCIsImxhc3RTZWxlY3RlZFByb2plY3QiLCJwcm9qZWN0VG9TZWxlY3QiLCJyZWR1Y2UiLCJwcmV2IiwicHJvamVjdCIsImluZGV4IiwibmV3UHJvamVjdCIsImltcG9ydE5vZGUiLCJjb250ZW50IiwicmVwbGFjZSIsInRyaW0iLCJwaWQiLCJkZW5zaXR5IiwiaWNvbiIsImFwcGVuZENoaWxkIiwic2VsZWN0ZWRQcm9qZWN0SW5kZXgiLCJ1bmRlZmluZWQiLCJzZWxlY3RQcm9qZWN0Iiwic2VsZWN0ZWRQcm9qZWN0IiwicGFyc2VJbnQiLCJjb250YWluZXIiLCJzZWxlY3RQcm9qZWN0Q29udGVudCIsInNldEl0ZW0iLCJwcm9qZWN0c0RhdGEiLCJkYXRhSlNPTiIsIm9yZ2FuaXphdGlvbnMiLCJwcm9maWxlcyIsInVzZXJDYW50VXBsb2FkRGVzaWducyIsIm5ld09yZ2FuaXphdGlvbiIsIm9yZ2FuaXphdGlvbiIsInVzZXJSb2xlIiwib3JnYW5pemF0aW9uRWwiLCJzdG9wUHJvcGFnYXRpb24iLCJnZXRPcmdhbml6YXRpb25Qcm9qZWN0cyIsInBhcmVudEVsZW1lbnQiLCJwcmV2U2VsZWN0ZWRPcmdhbml6YXRpb24iLCJpbXBvcnRUb1Byb2plY3QiLCJzZWxlY3RlZE9yZ2FuaXphdGlvbiIsImRlbnNpdHlUb0Nob29zZSIsImNoZWNrZWQiLCJnb1RvU2VsZWN0aW9uRGlzcGxheSIsImNhbmNlbERlbnNpdHlTZWxlY3Rpb24iLCJjaG9vc2VEZW5zaXR5IiwicHJvamVjdFR5cGUiLCJzZWxlY3RlZERlbnNpdHkiLCJyZXBhaW50QW5kcm9pZERlbnNpdGllcyIsInNjcm9sbFRvcCIsInBob25lUmFkaW8iLCJ0YWJsZXRSYWRpbyIsInJlcGxhY2VTY3JlZW5zIiwib25DbGlja1JldHJ5IiwiZ2V0dGluZ1Byb2plY3RzRmFpbGVkIiwicmV0cnkiLCJtYWluIiwic2VsZWN0ZWRBcnRib2FyZEluZm9ybWF0aW9uIiwiZXhwb3J0aW5nT25lIiwiZXhwb3J0aW5nTWFueSIsInNlbGVjdGVkTGF5ZXJDb3VudCIsInNlbGVjdGVkTGF5ZXJHcm91cENvdW50IiwibWFya0FzQXNzZXQiLCJ1bm1hcmtBc0Fzc2V0Iiwic2VsZWN0ZWRMYXllcnMiLCJwcm9jZXNzQXJ0Ym9hcmRTZWxlY3Rpb24iLCJhcnRib2FyZENvdW50Iiwic2VsZWN0aW9uQ291bnQiLCJyZXR1cm5FYXJseSIsInNlbGVjdGVkQXJ0Ym9hcmRDb3VudCIsIm1hbnkiLCJ1cGRhdGVTZWxlY3Rpb25JbmZvIiwic2VsZWN0aW9uIiwiYXJ0Ym9hcmRzIiwibGF5ZXJzIiwiZmlsdGVyIiwiaXRlbSIsImxheWVyR3JvdXBzIiwiZXhwb3J0YWJsZUxheWVyR3JvdXBDb3VudCIsImxheWVyR3JvdXAiLCJleHBvcnRhYmxlIiwic2tpcHBhYmxlIiwiZXhwb3J0YWJsZUxheWVyQ291bnQiLCJsYXllciIsImV4cG9ydCIsInNraXAiLCJnZXRGaXJzdFNjcm9sbGFibGVQYXJlbnQiLCJlbGVtZW50Iiwic2Nyb2xsSGVpZ2h0IiwiY2xpZW50SGVpZ2h0Iiwic2Nyb2xsSWZOZWNlc3NhcnkiLCJlbGVtZW50UmVjdCIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsImNvbnRhaW5lclJlY3QiLCJ0b3AiLCJib3R0b20iXSwibWFwcGluZ3MiOiI7QUFBQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7QUFHQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQSxtREFBMkMsY0FBYzs7QUFFekQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFLO0FBQ0w7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBMkIsMEJBQTBCLEVBQUU7QUFDdkQseUNBQWlDLGVBQWU7QUFDaEQ7QUFDQTtBQUNBOztBQUVBO0FBQ0EsOERBQXNELCtEQUErRDs7QUFFckg7QUFDQTs7QUFFQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDaEVBO0FBQ0E7QUFDQTs7QUFFQSxJQUFJQSxNQUFKO0FBQ0EsSUFBSSwrQ0FBQUMsQ0FBUUMsTUFBWixFQUFvQjtBQUNuQkYsVUFBUyxJQUFLLCtDQUFBQyxDQUFRQyxNQUFiLENBQXFCO0FBQzdCQyxjQUFZLENBQ1gsSUFBSywrQ0FBQUYsQ0FBUUUsVUFBUixDQUFtQkMsZUFBeEIsQ0FBeUM7QUFDeENDLGFBQVcsWUFBWTtBQUN0QixRQUFJQyxRQUFRQyxRQUFSLEtBQXFCLE9BQXpCLEVBQWtDO0FBQ2pDLFlBQU8sNENBQUFDLENBQUtDLE9BQUwsQ0FBYUgsUUFBUUksR0FBUixDQUFZQyxPQUF6QixFQUFrQyxRQUFsQyxFQUE0Qyx3REFBQUMsQ0FBWUMsSUFBWixHQUFtQixNQUEvRCxDQUFQO0FBQ0EsS0FGRCxNQUVPLElBQUlQLFFBQVFDLFFBQVIsS0FBcUIsUUFBekIsRUFBbUM7QUFDekMsWUFBTyw0Q0FBQUMsQ0FBS0MsT0FBTCxDQUFhSCxRQUFRSSxHQUFSLENBQVlJLElBQXpCLEVBQStCLFNBQS9CLEVBQTBDLE1BQTFDLEVBQWtELFFBQWxELEVBQTRELHdEQUFBRixDQUFZQyxJQUFaLEdBQW1CLE1BQS9FLENBQVA7QUFDQTtBQUNELElBTlM7QUFEOEIsR0FBekMsQ0FEVztBQURpQixFQUFyQixDQUFUO0FBYUEsQ0FkRCxNQWNPO0FBQ05iLFVBQVM7QUFDUmUsUUFBTSxZQUFZO0FBQ2pCQyxXQUFRQyxHQUFSLENBQVlDLE1BQU1DLFNBQU4sQ0FBZ0JDLElBQWhCLENBQXFCQyxJQUFyQixDQUEwQkMsU0FBMUIsRUFBcUMsSUFBckMsQ0FBWjtBQUNBLEdBSE87QUFJUkMsU0FBTyxZQUFZO0FBQ2xCUCxXQUFRTyxLQUFSLENBQWNMLE1BQU1DLFNBQU4sQ0FBZ0JDLElBQWhCLENBQXFCQyxJQUFyQixDQUEwQkMsU0FBMUIsRUFBcUMsSUFBckMsQ0FBZDtBQUNBO0FBTk8sRUFBVDtBQVFBO0FBQ0RFLE9BQU9DLE9BQVAsR0FBaUIsVUFBVUMsT0FBVixFQUFtQkMsTUFBbkIsRUFBMkJDLE1BQTNCLEVBQW1DQyxLQUFuQyxFQUEwQ04sS0FBMUMsRUFBaUQ7QUFDakV2QixRQUFPdUIsS0FBUCxDQUFhLGdCQUFiLEVBQStCSSxNQUEvQixFQUF1Q0MsTUFBdkMsRUFBK0NDLEtBQS9DLEVBQXNESCxPQUF0RCxFQUErREgsS0FBL0QsRUFBc0UsRUFBdEU7QUFDQSxRQUFPLElBQVA7QUFDQSxDQUhEO0FBSUF2QixPQUFPZSxJQUFQLENBQVksdUJBQVo7QUFDQSx3REFBZWYsTUFBZixDOzs7Ozs7Ozs7QUNsQ0E7QUFDQTs7QUFFQSx3REFBQUEsQ0FBT2UsSUFBUCxDQUFZLHVCQUFaLEVBQXFDLHdEQUFBSCxDQUFZa0IsU0FBakQ7QUFDQSx3REFBZUMsR0FBR0MsT0FBSCxDQUFXLHdEQUFBcEIsQ0FBWWtCLFNBQXZCLENBQWYsQzs7Ozs7Ozs7OztBQ0pBOztBQUVBLElBQUlHLE1BQU1DLFNBQVNDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBVjs7QUFFTyxTQUFTQyxnQkFBVCxDQUEwQkMsS0FBMUIsRUFBaUNDLFFBQWpDLEVBQTJDO0FBQzlDTCxRQUFJRyxnQkFBSixDQUFxQkMsS0FBckIsRUFBNEJDLFFBQTVCO0FBQ0g7O0FBRU0sU0FBU0MsSUFBVCxDQUFjRixLQUFkLEVBQXFCRyxJQUFyQixFQUEyQjtBQUM5QnhDLElBQUEsd0RBQUFBLENBQU9lLElBQVAsQ0FBWSxhQUFhc0IsS0FBYixHQUFxQixJQUFyQixHQUE0QkcsSUFBeEM7QUFDQVAsUUFBSVEsYUFBSixDQUFrQixJQUFJQyxXQUFKLENBQWdCTCxLQUFoQixFQUF1QixFQUFFTSxRQUFRSCxJQUFWLEVBQXZCLENBQWxCO0FBQ0gsQzs7Ozs7OztBQ1hELHdEQUFlO0FBQ1hWLGVBQVcsd0JBREE7QUFFWGpCLFVBQU0sMkJBRks7QUFHWCtCLGlCQUFhO0FBSEYsQ0FBZixDOzs7Ozs7Ozs7OztBQ0FBO0FBQ0E7O0FBRUEsSUFBSUMsY0FBYyxJQUFJLG1EQUFKLEVBQWxCOztBQUVBLFNBQVNDLGNBQVQsQ0FBd0JELFdBQXhCLEVBQXFDO0FBQ3BDLEtBQUlSLFFBQVEsSUFBSVUsT0FBSixDQUFZLCtCQUFaLEVBQTZDLGFBQTdDLENBQVo7QUFDQVYsT0FBTU8sV0FBTixHQUFvQix3REFBQWhDLENBQVlnQyxXQUFoQztBQUNBQyxhQUFZSixhQUFaLENBQTBCSixLQUExQjtBQUNBOztBQUVEOzs7QUFHQSxTQUFTVyxLQUFULENBQWVDLEtBQWYsRUFBc0JDLEtBQXRCLEVBQTZCO0FBQzVCLFVBQVNDLFlBQVQsQ0FBc0JDLEtBQXRCLEVBQTZCRixLQUE3QixFQUFvQztBQUNuQyxNQUFJRyxnQkFBZ0IsQ0FBQ0MsTUFBTUosS0FBTixDQUFELEdBQWdCRSxRQUFRRixLQUF4QixHQUFnQ0UsS0FBcEQ7QUFDQSxNQUFJQyxnQkFBZ0IsQ0FBcEIsRUFBdUI7QUFDdEJBLG1CQUFnQixDQUFoQjtBQUNBLEdBRkQsTUFFTyxJQUFJQSxnQkFBZ0IsR0FBcEIsRUFBeUI7QUFDL0JBLG1CQUFnQixHQUFoQjtBQUNBOztBQUVEQSxrQkFBZ0JBLGNBQWNFLFFBQWQsQ0FBdUIsRUFBdkIsQ0FBaEI7QUFDQSxTQUFPRixjQUFjRyxNQUFkLElBQXdCLENBQXhCLEdBQTRCLE1BQU1ILGFBQWxDLEdBQWtEQSxhQUF6RDtBQUNBOztBQUVELEtBQUlJLE1BQU0sRUFBVjtBQUNBLEtBQUlSLEtBQUosRUFBVztBQUNWUSxRQUFNTixhQUFhRixNQUFNUyxHQUFuQixFQUF3QlQsTUFBTUMsS0FBOUIsSUFBdUNDLGFBQWFGLE1BQU1VLEtBQW5CLEVBQTBCVixNQUFNQyxLQUFoQyxDQUF2QyxHQUFnRkMsYUFBYUYsTUFBTVcsSUFBbkIsRUFBeUJYLE1BQU1DLEtBQS9CLENBQXRGO0FBQ0E7QUFDRCxRQUFPTyxHQUFQO0FBQ0E7O0FBRUQ7OztBQUdBLFNBQVNJLDBCQUFULENBQW9DQyxXQUFwQyxFQUFpRDtBQUNoRCxLQUFJQyx1QkFBdUJELFlBQVlDLG9CQUFaLENBQWlDZCxLQUE1RDtBQUNBZixVQUFTOEIsSUFBVCxDQUFjQyxPQUFkLENBQXNCQyxFQUF0QixHQUEyQixPQUFPbEIsTUFBTWUsb0JBQU4sQ0FBbEM7QUFDQTs7QUFFRCxTQUFTSSxzQkFBVCxDQUFnQzlCLEtBQWhDLEVBQXVDO0FBQ3RDO0FBQ0EsS0FBSStCLFdBQVdDLEtBQUtDLEtBQUwsQ0FBVzlDLE9BQU8rQyxhQUFQLENBQXFCQyxrQkFBckIsRUFBWCxFQUFzRFYsV0FBckU7QUFDQTtBQUNBO0FBQ0FELDRCQUEyQk8sUUFBM0I7QUFDQTs7QUFFRFAsMkJBQTJCaEIsWUFBWTRCLGVBQVosQ0FBNEJYLFdBQXZEO0FBQ0E7QUFDQWpCLFlBQVlULGdCQUFaLENBQTZCLG1EQUFBc0MsQ0FBWUMseUJBQXpDLEVBQW9FUixzQkFBcEU7O0FBRUFyQixlQUFlRCxXQUFmLEU7Ozs7Ozs7OztBQ3REQTtBQUNBOztBQUVBLElBQUkrQixrQkFBa0IsS0FBdEI7QUFBQSxJQUNJQyxzQkFBc0IsQ0FEMUI7QUFBQSxJQUVJQyxZQUFZLEtBRmhCOztBQUlBLFNBQVNDLGNBQVQsQ0FBd0J4RCxLQUF4QixFQUErQjtBQUMzQixRQUFJVyxTQUFTOEIsSUFBVCxDQUFjZ0IsU0FBZCxLQUE0QiwwQkFBaEMsRUFBNEQ7QUFDeERoRixRQUFBLHdEQUFBQSxDQUFPZSxJQUFQLENBQVksc0RBQVo7QUFDQTtBQUNIO0FBQ0QsUUFBSThELG1CQUFKLEVBQXlCO0FBQ3JCN0UsUUFBQSx3REFBQUEsQ0FBT2UsSUFBUCxDQUFZLCtDQUFaO0FBQ0E7QUFDSDtBQUNELFFBQUkrRCxTQUFKLEVBQWU7QUFBRTtBQUNiOUUsUUFBQSx3REFBQUEsQ0FBT2UsSUFBUCxDQUFZLDJFQUFaO0FBQ0FmLFFBQUEsd0RBQUFBLENBQU91QixLQUFQLENBQWEsc0JBQWIsRUFBcUNBLEtBQXJDLEVBQTRDLEVBQTVDO0FBQ0FXLGlCQUFTOEIsSUFBVCxDQUFjZ0IsU0FBZCxHQUEwQiwwQkFBMUI7QUFDQTtBQUNIO0FBQ0RoRixJQUFBLHdEQUFBQSxDQUFPZSxJQUFQLENBQVksbUZBQVo7QUFDQThELDBCQUFzQkksV0FBVyxZQUFZO0FBQ3pDakYsUUFBQSx3REFBQUEsQ0FBT2UsSUFBUCxDQUFZLGtDQUFaO0FBQ0FmLFFBQUEsd0RBQUFBLENBQU91QixLQUFQLENBQWEsc0JBQWIsRUFBcUNBLEtBQXJDLEVBQTRDLEVBQTVDO0FBQ0FXLGlCQUFTOEIsSUFBVCxDQUFjZ0IsU0FBZCxHQUEwQiwwQkFBMUI7QUFDQUgsOEJBQXNCLENBQXRCO0FBQ0gsS0FMcUIsRUFLbkJELGVBTG1CLENBQXRCO0FBTUg7O0FBRUQsd0RBQUFNLENBQU9DLEVBQVAsQ0FBVSxlQUFWLEVBQTJCSixjQUEzQjtBQUNBLHdEQUFBRyxDQUFPQyxFQUFQLENBQVUsaUJBQVYsRUFBNkJKLGNBQTdCOztBQUVBLHdEQUFBRyxDQUFPQyxFQUFQLENBQVUsU0FBVixFQUFxQixZQUFZO0FBQzdCbkYsSUFBQSx3REFBQUEsQ0FBT2UsSUFBUCxDQUFZLFdBQVo7QUFDQSxRQUFJOEQsbUJBQUosRUFBeUI7QUFDckI3RSxRQUFBLHdEQUFBQSxDQUFPZSxJQUFQLENBQVksaUNBQVosRUFBK0M4RCxtQkFBL0M7QUFDQU8scUJBQWFQLG1CQUFiO0FBQ0FBLDhCQUFzQixDQUF0QjtBQUNIO0FBQ0QzQyxhQUFTOEIsSUFBVCxDQUFjZ0IsU0FBZCxHQUEwQixtQkFBMUI7QUFDQUYsZ0JBQVksSUFBWjtBQUNILENBVEQsRTs7Ozs7Ozs7OztBQ2xDQTtBQUNBO0FBQ0E7O0FBRUEsSUFBSU8sbUJBQW1CbkQsU0FBU29ELGNBQVQsQ0FBd0IsZUFBeEIsQ0FBdkI7O0FBRUEsd0RBQUFKLENBQU9DLEVBQVAsQ0FBVSxhQUFWLEVBQXlCLFVBQVU1RCxLQUFWLEVBQWlCO0FBQ3RDdkIsSUFBQSx3REFBQUEsQ0FBT3VCLEtBQVAsQ0FBYSxvQ0FBYixFQUFtREEsS0FBbkQsRUFBMEQsRUFBMUQ7QUFDQSxRQUFJZ0UsRUFBSixFQUFRQywwQkFBUixFQUFvQ0MsYUFBcEM7QUFDQSxRQUFJSixpQkFBaUJLLFNBQWpCLENBQTJCQyxRQUEzQixDQUFvQyw2QkFBcEMsQ0FBSixFQUF3RTtBQUNwRUosYUFBS0YsZ0JBQUw7QUFDQUUsV0FBR0csU0FBSCxDQUFhRSxHQUFiLENBQWlCLHVCQUFqQjtBQUNBTCxXQUFHRyxTQUFILENBQWFHLE1BQWIsQ0FBb0IsNkJBQXBCO0FBQ0FMLHFDQUE2QkQsR0FBR08sYUFBSCxDQUFpQixvQ0FBakIsQ0FBN0I7QUFDQUwsd0JBQWdCRixHQUFHTyxhQUFILENBQWlCLGdCQUFqQixDQUFoQjtBQUNILEtBTkQsTUFNTztBQUNIUCxhQUFLckQsU0FBUzhCLElBQWQ7QUFDQXVCLFdBQUdQLFNBQUgsR0FBZSx1QkFBZjtBQUNBUSxxQ0FBNkJ0RCxTQUFTNEQsYUFBVCxDQUF1Qix5RUFBdkIsQ0FBN0I7QUFDQUwsd0JBQWdCdkQsU0FBUzRELGFBQVQsQ0FBdUIscURBQXZCLENBQWhCO0FBQ0g7O0FBRURQLE9BQUdHLFNBQUgsQ0FBYUssTUFBYixDQUFvQixjQUFwQixFQUFvQ3hFLE1BQU15RSxJQUFOLEtBQWUsU0FBbkQ7QUFDQVQsT0FBR0csU0FBSCxDQUFhSyxNQUFiLENBQW9CLGtCQUFwQixFQUF3Q3hFLE1BQU15RSxJQUFOLEtBQWUsaUJBQXZEO0FBQ0FULE9BQUdHLFNBQUgsQ0FBYUssTUFBYixDQUFvQixXQUFwQixFQUFpQ3hFLE1BQU15RSxJQUFOLEtBQWUsTUFBaEQ7QUFDQSxRQUFJekUsTUFBTXlFLElBQU4sS0FBZSxNQUFuQixFQUEyQjtBQUN2QlIsbUNBQTJCUyxXQUEzQixHQUF5QzFFLE1BQU0yRSxLQUEvQztBQUNBVCxzQkFBY1EsV0FBZCxHQUE0QjFFLE1BQU1HLE9BQWxDO0FBQ0F5RSxxQkFBYUMsVUFBYixDQUF3QixxQkFBeEI7QUFDSDtBQUNELFFBQUk3RSxNQUFNeUUsSUFBTixLQUFlLGFBQW5CLEVBQWtDO0FBQzlCRyxxQkFBYUMsVUFBYixDQUF3QixxQkFBeEI7QUFDQUQscUJBQWFDLFVBQWIsQ0FBd0IsMEJBQXhCO0FBQ0g7QUFDSixDQTVCRDs7QUE4QkEsR0FBR0MsT0FBSCxDQUFXaEYsSUFBWCxDQUNJYSxTQUFTb0UsZ0JBQVQsQ0FBMEIsd0JBQTFCLENBREosRUFFSSxVQUFVQyxxQkFBVixFQUFpQztBQUM3QkEsMEJBQXNCbkUsZ0JBQXRCLENBQXVDLE9BQXZDLEVBQWdELFVBQVVvRSxFQUFWLEVBQWM7QUFDMUR0QixRQUFBLHdEQUFBQSxDQUFPdUIsSUFBUCxDQUFZLFlBQVo7QUFDQUMsUUFBQSwwREFBZ0Isc0JBQWhCO0FBQ0gsS0FIRDtBQUlILENBUEw7O0FBVUEsR0FBR0wsT0FBSCxDQUFXaEYsSUFBWCxDQUNJYSxTQUFTb0UsZ0JBQVQsQ0FBMEIsY0FBMUIsQ0FESixFQUVJLFVBQVVLLFdBQVYsRUFBdUI7QUFDbkJBLGdCQUFZdkUsZ0JBQVosQ0FBNkIsT0FBN0IsRUFBc0MsWUFBWTtBQUM5Q3NFLFFBQUEsMERBQWdCLHNCQUFoQjtBQUNILEtBRkQ7QUFHSCxDQU5MLEU7Ozs7Ozs7Ozs7QUM5Q0E7QUFDQTtBQUNBOztBQUVBLElBQUlFLFdBQVcxRSxTQUFTb0QsY0FBVCxDQUF3QixVQUF4QixDQUFmO0FBQUEsSUFDSXVCLDBCQUEwQjNFLFNBQVNvRCxjQUFULENBQXdCLHlCQUF4QixDQUQ5QjtBQUFBLElBRUl3QixlQUFlNUUsU0FBUzRELGFBQVQsQ0FBdUIsd0JBQXZCLENBRm5CO0FBQUEsSUFHSWlCLGNBQWM3RSxTQUFTb0QsY0FBVCxDQUF3QixhQUF4QixDQUhsQjtBQUFBLElBSUkwQixpQkFBaUI5RSxTQUFTb0QsY0FBVCxDQUF3QixnQkFBeEIsQ0FKckI7QUFBQSxJQUtJMkIsU0FBUy9FLFNBQVNvRCxjQUFULENBQXdCLFFBQXhCLENBTGI7QUFBQSxJQU1JNEIsUUFBUWhGLFNBQVNvRCxjQUFULENBQXdCLE9BQXhCLENBTlo7O0FBUUEsU0FBUzZCLGlCQUFULENBQTJCNUYsS0FBM0IsRUFBa0M2RixLQUFsQyxFQUF5QztBQUN4QyxXQUFPQyxVQUFVLG1JQUFtSTlGLFFBQVFBLEtBQVIsR0FBZ0IsRUFBbkosS0FBMEo2RixRQUFRLFNBQVNBLEtBQWpCLEdBQXlCLEVBQW5MLENBQVYsQ0FBUDtBQUNBOztBQUVELHdEQUFBbEMsQ0FBT0MsRUFBUCxDQUFVLFVBQVYsRUFBc0IsVUFBVTNDLElBQVYsRUFBZ0I7QUFDbEN4QyxJQUFBLHdEQUFBQSxDQUFPZSxJQUFQLENBQVksNkJBQVosRUFBMkN5QixJQUEzQyxFQUFpRCxFQUFqRDtBQUNBTixhQUFTOEIsSUFBVCxDQUFjMEIsU0FBZCxDQUF3QkUsR0FBeEIsQ0FBNEIsY0FBNUI7QUFDQSxRQUFJMEIscUJBQXFCQyxLQUFLQyxLQUFMLENBQVloRixLQUFLaUYsS0FBTCxHQUFhakYsS0FBS2tGLEtBQW5CLEdBQTRCLEdBQXZDLENBQXpCO0FBQ0FkLGFBQVNlLEtBQVQsQ0FBZUMsS0FBZixHQUF1Qk4scUJBQXFCLEdBQTVDO0FBQ0gsQ0FMRDs7QUFPQSx3REFBQXBDLENBQU9DLEVBQVAsQ0FBVSxVQUFWLEVBQXNCLFVBQVUzQyxJQUFWLEVBQWdCO0FBQ2xDb0UsYUFBU2UsS0FBVCxDQUFlQyxLQUFmLEdBQXVCLE1BQXZCO0FBQ0E1SCxJQUFBLHdEQUFBQSxDQUFPZSxJQUFQLENBQVksNkJBQVosRUFBMkN5QixJQUEzQyxFQUFpRCxFQUFqRDs7QUFFQXFFLDRCQUF3QmdCLFFBQXhCLEdBQW1DLEtBQW5DO0FBQ0FmLGlCQUFhZSxRQUFiLEdBQXdCLEtBQXhCO0FBQ0FqQixhQUFTZSxLQUFULENBQWVDLEtBQWYsR0FBdUIsSUFBdkI7QUFDQTFGLGFBQVM4QixJQUFULENBQWMwQixTQUFkLENBQXdCRyxNQUF4QixDQUErQixXQUEvQixFQUE0QyxjQUE1QztBQUNBM0QsYUFBUzhCLElBQVQsQ0FBYzBCLFNBQWQsQ0FBd0JFLEdBQXhCLENBQTRCLGtCQUE1QjtBQUNILENBVEQ7O0FBV0Esd0RBQUFWLENBQU9DLEVBQVAsQ0FBVSxZQUFWLEVBQXdCLFVBQVUzQyxJQUFWLEVBQWdCO0FBQ3BDeEMsSUFBQSx3REFBQUEsQ0FBT3VCLEtBQVAsQ0FBYSw2QkFBYixFQUE0Q2lCLEtBQUtqQixLQUFqRCxFQUF3RCxFQUF4RDs7QUFFQXdGLGdCQUFZZCxXQUFaLEdBQTBCekQsS0FBS3NGLFNBQS9CO0FBQ0FmLGdCQUFZckIsU0FBWixDQUFzQkssTUFBdEIsQ0FBNkIsUUFBN0IsRUFBdUMsQ0FBQ3ZELEtBQUtzRixTQUE3Qzs7QUFFQWQsbUJBQWVmLFdBQWYsR0FBNkJ6RCxLQUFLdUYsWUFBbEM7O0FBRUFkLFdBQU9lLElBQVAsR0FBY2Isa0JBQWtCM0UsS0FBS2pCLEtBQUwsQ0FBV0csT0FBN0IsRUFBc0NjLEtBQUtqQixLQUFMLENBQVc2RixLQUFqRCxDQUFkOztBQUVBUCw0QkFBd0JnQixRQUF4QixHQUFtQyxLQUFuQztBQUNBZixpQkFBYW1CLE9BQWIsR0FBdUIsS0FBdkI7QUFDQXJCLGFBQVNlLEtBQVQsQ0FBZUMsS0FBZixHQUF1QixJQUF2QjtBQUNBMUYsYUFBUzhCLElBQVQsQ0FBY2dCLFNBQWQsR0FBMEIsZ0JBQTFCO0FBQ0gsQ0FkRDs7QUFnQkEsU0FBU2tELGFBQVQsR0FBeUI7QUFDckIsUUFBSTFGLElBQUo7QUFDQSxRQUFJMkYsMkJBQTJCaEMsYUFBYWlDLE9BQWIsQ0FBcUIsMEJBQXJCLENBQS9CO0FBQ0EsUUFBSUQsNEJBQTRCQSw2QkFBNkIsTUFBN0QsRUFBcUU7QUFDakUzRixlQUFPO0FBQ0g2RixpQkFBS0Y7QUFERixTQUFQO0FBR0g7QUFDRGpELElBQUEsd0RBQUFBLENBQU91QixJQUFQLENBQVksVUFBWixFQUF3QmpFLElBQXhCO0FBQ0FOLGFBQVM4QixJQUFULENBQWNnQixTQUFkLEdBQTBCLGlCQUExQjtBQUNIOztBQUVENkIsd0JBQXdCekUsZ0JBQXhCLENBQXlDLE9BQXpDLEVBQWtEOEYsYUFBbEQ7O0FBRUEsc0VBQTRCLFFBQTVCLEVBQXNDQSxhQUF0Qzs7QUFFQWhCLE1BQU05RSxnQkFBTixDQUF1QixPQUF2QixFQUFnQyxVQUFVb0UsRUFBVixFQUFjO0FBQzFDRSxJQUFBLDBEQUFnQixzQkFBaEI7QUFDSCxDQUZELEU7Ozs7OztBQ2xFQSxJQUFJNEIsUUFBUXBHLFNBQVNvRSxnQkFBVCxDQUEwQixHQUExQixDQUFaO0FBQ0EsSUFBSWlDLFNBQVNyRyxTQUFTb0QsY0FBVCxDQUF3QixRQUF4QixDQUFiO0FBQ0EsSUFBSWtELDhCQUE4QnRHLFNBQVM0RCxhQUFULENBQXVCLGtEQUF2QixDQUFsQzs7QUFFQSxTQUFTMkMsb0JBQVQsQ0FBK0JDLENBQS9CLEVBQWtDO0FBQ2pDQSxHQUFFQyxjQUFGO0FBQ0FuSCxRQUFPb0gsR0FBUCxDQUFXQyxJQUFYLENBQWdCQyx1QkFBaEIsQ0FBd0NKLEVBQUVLLE1BQUYsQ0FBU2YsSUFBakQ7QUFDQTs7QUFFRE8sT0FBT25HLGdCQUFQLENBQXdCLE9BQXhCLEVBQWlDLFlBQVk7QUFDNUNaLFFBQU9vSCxHQUFQLENBQVdDLElBQVgsQ0FBZ0JDLHVCQUFoQixDQUF3QyxtQkFBeEM7QUFDQSxDQUZEOztBQUlBTiw0QkFBNEJwRyxnQkFBNUIsQ0FBNkMsT0FBN0MsRUFBc0QsWUFBWTtBQUM5RFosUUFBT29ILEdBQVAsQ0FBV0MsSUFBWCxDQUFnQkMsdUJBQWhCLENBQXdDLGlGQUF4QztBQUNILENBRkQ7O0FBSUEsS0FBSSxJQUFJRSxJQUFJLENBQVosRUFBZUEsSUFBSVYsTUFBTTlFLE1BQXpCLEVBQWlDd0YsR0FBakMsRUFBc0M7QUFDckNWLE9BQU1VLENBQU4sRUFBUzVHLGdCQUFULENBQTBCLE9BQTFCLEVBQW1DcUcsb0JBQW5DO0FBQ0EsQzs7Ozs7Ozs7Ozs7QUNuQkQ7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQXZHLFNBQVM4QixJQUFULENBQWMyRCxLQUFkLENBQW9Cc0IsT0FBcEIsR0FBOEIsTUFBOUI7QUFDQS9HLFNBQVM4QixJQUFULENBQWNrRixZQUFkO0FBQ0FoSCxTQUFTOEIsSUFBVCxDQUFjMkQsS0FBZCxDQUFvQnNCLE9BQXBCLEdBQThCLEVBQTlCOztBQUVBLElBQUlFLGNBQWNqSCxTQUFTb0QsY0FBVCxDQUF3QixVQUF4QixDQUFsQjtBQUFBLElBQ0k4RCx3QkFBd0JsSCxTQUFTb0QsY0FBVCxDQUF3QixpQkFBeEIsQ0FENUI7QUFBQSxJQUVJRCxtQkFBbUJuRCxTQUFTb0QsY0FBVCxDQUF3QixlQUF4QixDQUZ2QjtBQUFBLElBR0krRCx5QkFBeUJuSCxTQUFTb0QsY0FBVCxDQUF3Qix3QkFBeEIsQ0FIN0I7QUFBQSxJQUlJZ0UsdUJBQXVCcEgsU0FBU29ELGNBQVQsQ0FBd0Isc0JBQXhCLENBSjNCO0FBQUEsSUFLSWlFLGtCQUFrQnJILFNBQVNvRCxjQUFULENBQXdCLGlCQUF4QixDQUx0QjtBQUFBLElBTUlrRSxtQkFBbUJ0SCxTQUFTb0QsY0FBVCxDQUF3QixlQUF4QixDQU52QjtBQUFBLElBT0ltRSxxQ0FBcUN2SCxTQUFTb0QsY0FBVCxDQUF3QixzQkFBeEIsQ0FQekM7QUFBQSxJQVFJb0UsdUJBQXVCeEgsU0FBU29ELGNBQVQsQ0FBd0Isc0JBQXhCLENBUjNCO0FBQUEsSUFTSXFFLFVBQVV6SCxTQUFTb0QsY0FBVCxDQUF3QixTQUF4QixDQVRkO0FBQUEsSUFVSXNFLGdCQUFnQjFILFNBQVNvRCxjQUFULENBQXdCLGVBQXhCLENBVnBCO0FBQUEsSUFXQ3dCLGVBQWU1RSxTQUFTNEQsYUFBVCxDQUF1Qix3QkFBdkIsQ0FYaEI7QUFBQSxJQVlJZSwwQkFBMEIzRSxTQUFTb0QsY0FBVCxDQUF3Qix5QkFBeEIsQ0FaOUI7QUFBQSxJQWFDdUUsbUJBQW1CLEVBYnBCOztBQWVBLElBQUlDLGFBQWEsdWdIQUFqQjtBQUNBLFNBQVNDLGNBQVQsQ0FBd0JDLFFBQXhCLEVBQWtDO0FBQzlCOUgsVUFBUzhCLElBQVQsQ0FBY2dCLFNBQWQsR0FBMEIsa0JBQTFCO0FBQ0FtRSxhQUFZYyxTQUFaLEdBQXdCLEVBQXhCO0FBQ0FiLHVCQUFzQnZCLFFBQXRCLEdBQWlDLElBQWpDOztBQUVBLEtBQUl4QyxpQkFBaUJLLFNBQWpCLENBQTJCQyxRQUEzQixDQUFvQywwQkFBcEMsQ0FBSixFQUFxRTtBQUNqRU4sbUJBQWlCSyxTQUFqQixDQUEyQkcsTUFBM0IsQ0FBa0MsNkJBQWxDO0FBQ0F3RCx5QkFBdUJ4QixRQUF2QixHQUFrQyxLQUFsQztBQUNBeUIsdUJBQXFCekIsUUFBckIsR0FBZ0MsS0FBaEM7QUFDSDs7QUFFRCxLQUFJcUMsc0JBQXNCL0QsYUFBYWlDLE9BQWIsQ0FBcUIscUJBQXJCLENBQTFCOztBQUVEbEcsVUFBUzhCLElBQVQsQ0FBYzBCLFNBQWQsQ0FBd0JLLE1BQXhCLENBQStCLFlBQS9CLEVBQTZDLENBQUNpRSxTQUFTeEcsTUFBdkQ7O0FBRUMsS0FBSTJHLGtCQUFrQkgsU0FBU0ksTUFBVCxDQUFnQixVQUFVQyxJQUFWLEVBQWdCQyxPQUFoQixFQUF5QkMsS0FBekIsRUFBZ0M7QUFDbEUsTUFBSUMsYUFBYXRJLFNBQVN1SSxVQUFULENBQW9CbEIsZ0JBQWdCbUIsT0FBcEMsRUFBNkMsSUFBN0MsQ0FBakI7O0FBRUFGLGFBQVcxRSxhQUFYLENBQXlCLGNBQXpCLEVBQXlDRyxXQUF6QyxHQUF1RHFFLFFBQVF6SixJQUFSLENBQWE4SixPQUFiLENBQXFCYixVQUFyQixFQUFpQyxFQUFqQyxFQUFxQ2MsSUFBckMsRUFBdkQ7O0FBRUFKLGFBQVcxRSxhQUFYLENBQXlCLFVBQXpCLEVBQXFDN0IsT0FBckMsQ0FBNkMrQixJQUE3QyxHQUFvRHNFLFFBQVF0RSxJQUE1RDs7QUFFQXdFLGFBQVcxRSxhQUFYLENBQXlCLFVBQXpCLEVBQXFDN0IsT0FBckMsQ0FBNkM0RyxHQUE3QyxHQUFtRFAsUUFBUU8sR0FBM0Q7QUFDQUwsYUFBVzFFLGFBQVgsQ0FBeUIsVUFBekIsRUFBcUM3QixPQUFyQyxDQUE2QzZHLE9BQTdDLEdBQXVEUixRQUFRUSxPQUEvRDs7QUFFQU4sYUFBVzFFLGFBQVgsQ0FBeUIsY0FBekIsRUFBeUM3QixPQUF6QyxDQUFpRCtCLElBQWpELEdBQXdEc0UsUUFBUVMsSUFBUixDQUFhL0UsSUFBckU7O0FBRUF3RSxhQUFXMUUsYUFBWCxDQUF5QixVQUF6QixFQUFxQzdCLE9BQXJDLENBQTZDc0csS0FBN0MsR0FBcURBLEtBQXJEOztBQUVBcEIsY0FBWTZCLFdBQVosQ0FBd0JSLFVBQXhCO0FBQ0EsTUFBSUgsU0FBUyxDQUFDLENBQWQsRUFBaUI7QUFDYixVQUFPQSxJQUFQO0FBQ0gsR0FGRCxNQUVPLElBQUlILHVCQUF1QkEsd0JBQXdCSSxRQUFRTyxHQUEzRCxFQUFnRTtBQUNuRSxVQUFPTixLQUFQO0FBQ0gsR0FGTSxNQUVBO0FBQ0gsVUFBT0YsSUFBUDtBQUNIO0FBQ0osRUF0QnFCLEVBc0JuQixDQUFDLENBdEJrQixDQUF0Qjs7QUF3QkFZLHdCQUF1QkMsU0FBdkI7QUFDQSxLQUFJZixvQkFBb0IsQ0FBQyxDQUF6QixFQUE0QjtBQUN4QmdCLGdCQUFjaEIsZUFBZDtBQUNIO0FBQ0o7O0FBRUQsSUFBSWMsb0JBQUo7QUFDQSxTQUFTRSxhQUFULENBQXVCWixLQUF2QixFQUE4QjtBQUM3QixLQUFJYSxlQUFKO0FBQ0EsS0FBSUgseUJBQXlCQyxTQUE3QixFQUF3QztBQUN2Q0Usb0JBQWtCakMsWUFBWXJELGFBQVosQ0FBMEIsMEJBQTBCbUYsb0JBQTFCLEdBQWlELElBQTNFLENBQWxCO0FBQ0FHLGtCQUFnQjFGLFNBQWhCLENBQTBCRyxNQUExQixDQUFpQyxVQUFqQztBQUNBOztBQUVEb0Ysd0JBQXVCSSxTQUFTZCxLQUFULEVBQWdCLEVBQWhCLENBQXZCO0FBQ0FhLG1CQUFrQmpDLFlBQVlyRCxhQUFaLENBQTBCLDBCQUEwQm1GLG9CQUExQixHQUFpRCxJQUEzRSxDQUFsQjtBQUNBRyxpQkFBZ0IxRixTQUFoQixDQUEwQkUsR0FBMUIsQ0FBOEIsVUFBOUI7O0FBRUEsS0FBSTBGLFlBQVlqRyxpQkFBaUJLLFNBQWpCLENBQTJCQyxRQUEzQixDQUFvQywwQkFBcEMsSUFBa0U0RixvQkFBbEUsR0FBeUZwQyxXQUF6RztBQUNBTixDQUFBLGlFQUF1QnVDLGVBQXZCLEVBQXdDRSxTQUF4Qzs7QUFFQWxDLHVCQUFzQnZCLFFBQXRCLEdBQWlDLEtBQWpDO0FBQ0ExQixjQUFhcUYsT0FBYixDQUFxQixxQkFBckIsRUFBNENKLGdCQUFnQm5ILE9BQWhCLENBQXdCNEcsR0FBcEU7QUFDQTs7QUFFRCx3REFBQTNGLENBQU9DLEVBQVAsQ0FBVSxZQUFWLEVBQXdCLFVBQVVzRyxZQUFWLEVBQXdCO0FBQzVDLEtBQUl6QixXQUFXM0YsS0FBS0MsS0FBTCxDQUFXbUgsWUFBWCxDQUFmO0FBQ0ExQixnQkFBZUMsUUFBZjtBQUNILENBSEQ7O0FBS0Esd0RBQUE5RSxDQUFPQyxFQUFQLENBQVUsMkJBQVYsRUFBdUMsVUFBVTNDLElBQVYsRUFBZ0I7QUFDbkQsS0FBSWtKLFdBQVdySCxLQUFLQyxLQUFMLENBQVc5QixJQUFYLENBQWY7O0FBRUEsS0FBSXdILFdBQVcwQixTQUFTMUIsUUFBeEI7QUFDQSxLQUFJMkIsZ0JBQWdCRCxTQUFTQyxhQUE3QjtBQUNBLEtBQUlDLFdBQVdGLFNBQVNFLFFBQXhCO0FBQ0EsS0FBSXZELE1BQU1xRCxTQUFTckQsR0FBbkI7O0FBRUF3QixvQkFBbUI2QixTQUFTN0IsZ0JBQVQsSUFBNkIsRUFBaEQ7O0FBRUEsS0FBSWdDLHdCQUF3QixLQUE1Qjs7QUFFQSxLQUFJRixpQkFBaUJBLGNBQWNuSSxNQUFkLEdBQXVCLENBQTVDLEVBQStDO0FBQzNDZ0csbUJBQWlCUyxTQUFqQixHQUE2QixFQUE3QjtBQUNBUixxQ0FBbUMvRCxTQUFuQyxDQUE2Q0csTUFBN0MsQ0FBb0QsYUFBcEQ7QUFDQVIsbUJBQWlCSyxTQUFqQixDQUEyQkcsTUFBM0IsQ0FBa0MsNkJBQWxDO0FBQ0EzRCxXQUFTOEIsSUFBVCxDQUFjMEIsU0FBZCxDQUF3QkcsTUFBeEIsQ0FBK0IsdUJBQS9CO0FBQ0E0RCxxQ0FBbUN4RCxXQUFuQyxHQUFpRCxtQkFBakQ7O0FBRUEsTUFBSTZGLGtCQUFrQjVKLFNBQVN1SSxVQUFULENBQW9CZixxQkFBcUJnQixPQUF6QyxFQUFrRCxJQUFsRCxDQUF0Qjs7QUFFQW9CLGtCQUFnQmhHLGFBQWhCLENBQThCLG1CQUE5QixFQUFtREcsV0FBbkQsR0FBaUUsbUJBQWpFO0FBQ0E2RixrQkFBZ0JoRyxhQUFoQixDQUE4QixlQUE5QixFQUErQ0osU0FBL0MsQ0FBeURFLEdBQXpELENBQTZELFVBQTdEO0FBQ0FrRyxrQkFBZ0JoRyxhQUFoQixDQUE4QixlQUE5QixFQUErQzdCLE9BQS9DLENBQXVEb0UsR0FBdkQsR0FBNkQsTUFBN0Q7O0FBRUFtQixtQkFBaUJ3QixXQUFqQixDQUE2QmMsZUFBN0I7O0FBRUFILGdCQUFjdEYsT0FBZCxDQUFzQixVQUFVMEYsWUFBVixFQUF3QjtBQUMxQyxPQUFJRCxrQkFBa0I1SixTQUFTdUksVUFBVCxDQUFvQmYscUJBQXFCZ0IsT0FBekMsRUFBa0QsSUFBbEQsQ0FBdEI7O0FBRUFvQixtQkFBZ0JoRyxhQUFoQixDQUE4QixtQkFBOUIsRUFBbURHLFdBQW5ELEdBQWlFOEYsYUFBYWxMLElBQWIsQ0FBa0I4SixPQUFsQixDQUEwQmIsVUFBMUIsRUFBc0MsRUFBdEMsRUFBMENjLElBQTFDLEVBQWpFO0FBQ0FrQixtQkFBZ0JoRyxhQUFoQixDQUE4QixlQUE5QixFQUErQzdCLE9BQS9DLENBQXVEb0UsR0FBdkQsR0FBNkQwRCxhQUFhMUQsR0FBMUU7QUFDQSxPQUFJdUQsU0FBU0csYUFBYTFELEdBQXRCLENBQUosRUFBZ0M7QUFDNUJ5RCxvQkFBZ0JoRyxhQUFoQixDQUE4QixlQUE5QixFQUErQzdCLE9BQS9DLENBQXVEK0gsUUFBdkQsR0FBa0VKLFNBQVNHLGFBQWExRCxHQUF0QixDQUFsRTtBQUNIOztBQUVEbUIsb0JBQWlCd0IsV0FBakIsQ0FBNkJjLGVBQTdCO0FBQ0gsR0FWRDs7QUFZQSxNQUFJekQsR0FBSixFQUFTO0FBQ0xtQixvQkFBaUIxRCxhQUFqQixDQUErQixXQUEvQixFQUE0Q0osU0FBNUMsQ0FBc0RHLE1BQXRELENBQTZELFVBQTdEOztBQUVBLE9BQUlvRyxpQkFBaUJ6QyxpQkFBaUIxRCxhQUFqQixDQUErQiw2QkFBNkJ1QyxHQUE3QixHQUFtQyxJQUFsRSxDQUFyQjtBQUNBNEQsa0JBQWV2RyxTQUFmLENBQXlCRSxHQUF6QixDQUE2QixVQUE3Qjs7QUFFQTZELHNDQUFtQ3hELFdBQW5DLEdBQWlEZ0csZUFBZW5HLGFBQWYsQ0FBNkIsbUJBQTdCLEVBQWtERyxXQUFuRztBQUNBd0Qsc0NBQW1DL0QsU0FBbkMsQ0FBNkNFLEdBQTdDLENBQWlELGFBQWpEO0FBQ0FQLG9CQUFpQkssU0FBakIsQ0FBMkJFLEdBQTNCLENBQStCLDZCQUEvQjs7QUFFQWlHLDJCQUF3QkksZUFBZWhJLE9BQWYsQ0FBdUJvRSxHQUF2QixLQUErQixNQUEvQixJQUF5QzRELGVBQWVoSSxPQUFmLENBQXVCK0gsUUFBdkIsS0FBb0MsUUFBckc7QUFDQTlKLFlBQVM4QixJQUFULENBQWNnQixTQUFkLEdBQTBCLGtCQUExQjtBQUNBOUMsWUFBUzhCLElBQVQsQ0FBYzBCLFNBQWQsQ0FBd0JLLE1BQXhCLENBQStCLHVCQUEvQixFQUF3RDhGLHFCQUF4RDtBQUNBekMseUJBQXNCdkIsUUFBdEIsR0FBaUMsSUFBakM7QUFDSDs7QUFFRHhDLG1CQUFpQkssU0FBakIsQ0FBMkJFLEdBQTNCLENBQStCLDBCQUEvQjtBQUNIOztBQUVELEtBQUksQ0FBQ2lHLHFCQUFMLEVBQTRCO0FBQ3hCOUIsaUJBQWVDLFFBQWY7QUFDSDtBQUNKLENBN0REOztBQStEQTlILFNBQVNFLGdCQUFULENBQTBCLE9BQTFCLEVBQW1DLFlBQVk7QUFDOUNvSCxrQkFBaUI5RCxTQUFqQixDQUEyQkUsR0FBM0IsQ0FBK0IsUUFBL0I7QUFDQSxDQUZEOztBQUlBMEQscUJBQXFCbEgsZ0JBQXJCLENBQXNDLE9BQXRDLEVBQStDLFVBQVVvRSxFQUFWLEVBQWM7QUFDNURBLElBQUcwRixlQUFIO0FBQ0ExQyxrQkFBaUI5RCxTQUFqQixDQUEyQkssTUFBM0IsQ0FBa0MsUUFBbEM7QUFDQSxDQUhEOztBQUtBLFNBQVNvRyx1QkFBVCxDQUFpQ0YsY0FBakMsRUFBaUQ7QUFDaEQ5RixjQUFhcUYsT0FBYixDQUFxQiwwQkFBckIsRUFBaURTLGVBQWVoSSxPQUFmLENBQXVCb0UsR0FBeEU7QUFDQSxLQUFJQSxHQUFKO0FBQ0EsS0FBSTRELGVBQWVoSSxPQUFmLENBQXVCb0UsR0FBdkIsS0FBK0IsTUFBbkMsRUFBMkM7QUFDMUNBLFFBQU00RCxlQUFlaEksT0FBZixDQUF1Qm9FLEdBQTdCO0FBQ0E7QUFDRG5ELENBQUEsd0RBQUFBLENBQU91QixJQUFQLENBQVksYUFBWixFQUEyQjRCLEdBQTNCO0FBQ0FoRCxrQkFBaUJLLFNBQWpCLENBQTJCRSxHQUEzQixDQUErQiw2QkFBL0I7QUFDQTBELHNCQUFxQnpCLFFBQXJCLEdBQWdDLElBQWhDO0FBQ0F1Qix1QkFBc0J2QixRQUF0QixHQUFpQyxJQUFqQztBQUNBd0Isd0JBQXVCeEIsUUFBdkIsR0FBa0MsSUFBbEM7QUFDQTs7QUFFRDJCLGlCQUFpQnBILGdCQUFqQixDQUFrQyxPQUFsQyxFQUEyQyxVQUFVb0UsRUFBVixFQUFjO0FBQ3hELEtBQUl1RixlQUFldkYsR0FBR3VDLE1BQXRCOztBQUVBLFFBQU9nRCxnQkFBZ0IsQ0FBQ0EsYUFBYXJHLFNBQWIsQ0FBdUJDLFFBQXZCLENBQWdDLGNBQWhDLENBQXhCLEVBQXlFO0FBQ3hFb0csaUJBQWVBLGFBQWFLLGFBQTVCO0FBQ0E7O0FBRUQsS0FBSSxDQUFDTCxZQUFMLEVBQW1CO0FBQ2xCO0FBQ0E7O0FBRUR2RixJQUFHMEYsZUFBSDs7QUFFQSxLQUFJRywyQkFBMkI3QyxpQkFBaUIxRCxhQUFqQixDQUErQixXQUEvQixDQUEvQjtBQUNBLEtBQUl1Ryx3QkFBSixFQUE4QjtBQUM3QkEsMkJBQXlCM0csU0FBekIsQ0FBbUNHLE1BQW5DLENBQTBDLFVBQTFDO0FBQ0E7QUFDRGtHLGNBQWFyRyxTQUFiLENBQXVCRSxHQUF2QixDQUEyQixVQUEzQjs7QUFFQTZELG9DQUFtQ3hELFdBQW5DLEdBQWlEOEYsYUFBYWpHLGFBQWIsQ0FBMkIsbUJBQTNCLEVBQWdERyxXQUFqRztBQUNBd0Qsb0NBQW1DL0QsU0FBbkMsQ0FBNkNLLE1BQTdDLENBQW9ELGFBQXBELEVBQW1FZ0csYUFBYTlILE9BQWIsQ0FBcUJvRSxHQUFyQixLQUE2QixNQUFoRztBQUNBaEQsa0JBQWlCSyxTQUFqQixDQUEyQkssTUFBM0IsQ0FBa0MsNkJBQWxDLEVBQWlFZ0csYUFBYTlILE9BQWIsQ0FBcUJvRSxHQUFyQixLQUE2QixNQUE5Rjs7QUFFQW1CLGtCQUFpQjlELFNBQWpCLENBQTJCRSxHQUEzQixDQUErQixRQUEvQjs7QUFFQSxLQUFJaUcsd0JBQXdCRSxhQUFhOUgsT0FBYixDQUFxQm9FLEdBQXJCLEtBQTZCLE1BQTdCLElBQXVDMEQsYUFBYTlILE9BQWIsQ0FBcUIrSCxRQUFyQixLQUFrQyxRQUFyRztBQUNBOUosVUFBUzhCLElBQVQsQ0FBYzBCLFNBQWQsQ0FBd0JLLE1BQXhCLENBQStCLHVCQUEvQixFQUF3RDhGLHFCQUF4RDtBQUNBM0osVUFBUzhCLElBQVQsQ0FBYzBCLFNBQWQsQ0FBd0JHLE1BQXhCLENBQStCLFlBQS9CO0FBQ0F1RCx1QkFBc0J2QixRQUF0QixHQUFpQyxJQUFqQztBQUNBLEtBQUksQ0FBQ2dFLHFCQUFMLEVBQTRCO0FBQzNCTSwwQkFBd0JKLFlBQXhCO0FBQ0E7QUFDRCxDQWhDRDs7QUFrQ0Esc0VBQTRCLHlCQUE1QixFQUF1RCxVQUFVMUosS0FBVixFQUFpQjtBQUN2RWdELGtCQUFpQkwsU0FBakIsR0FBNkIsMEJBQTdCO0FBQ0dtSCx5QkFBd0I5SixNQUFNTSxNQUE5QjtBQUNILENBSEQ7O0FBS0F3RyxZQUFZL0csZ0JBQVosQ0FBNkIsT0FBN0IsRUFBc0MsVUFBVW9FLEVBQVYsRUFBYztBQUNuRCxLQUFJOEQsVUFBVTlELEdBQUd1QyxNQUFqQjs7QUFFQSxRQUFPdUIsV0FBVyxDQUFDQSxRQUFRNUUsU0FBUixDQUFrQkMsUUFBbEIsQ0FBMkIsU0FBM0IsQ0FBbkIsRUFBMEQ7QUFDekQyRSxZQUFVQSxRQUFROEIsYUFBbEI7QUFDQTs7QUFFRCxLQUFJLENBQUM5QixPQUFMLEVBQWM7QUFDYjtBQUNBOztBQUVEYSxlQUFjYixRQUFRckcsT0FBUixDQUFnQnNHLEtBQTlCO0FBQ0EsQ0FaRDs7QUFjQSxTQUFTK0IsZUFBVCxDQUF5QmhDLE9BQXpCLEVBQWtDO0FBQ2pDbkUsY0FBYXFGLE9BQWIsQ0FBcUIscUJBQXJCLEVBQTRDbEIsUUFBUXJHLE9BQVIsQ0FBZ0I0RyxHQUE1RDs7QUFFQSxLQUFJMEIsdUJBQXVCL0MsaUJBQWlCMUQsYUFBakIsQ0FBK0Isd0JBQS9CLENBQTNCO0FBQ0EsS0FBSXlHLG9CQUFKLEVBQTBCO0FBQ3pCcEcsZUFBYXFGLE9BQWIsQ0FBcUIsMEJBQXJCLEVBQWlEZSxxQkFBcUJ0SSxPQUFyQixDQUE2Qm9FLEdBQTlFO0FBQ0E7O0FBRUQsS0FBSW1FLGtCQUFrQmxDLFFBQVFyRyxPQUFSLENBQWdCNkcsT0FBdEM7QUFDQSxLQUFJMEIsb0JBQW9CLFNBQXhCLEVBQW1DO0FBQzVCLE1BQUksQ0FBQzNDLGlCQUFpQlMsUUFBUXJHLE9BQVIsQ0FBZ0IrQixJQUFqQyxDQUFMLEVBQTZDO0FBQ3pDOUQsWUFBUzhCLElBQVQsQ0FBY2dCLFNBQWQsR0FBMEIsa0JBQTFCO0FBQ0E5QyxZQUFTOEIsSUFBVCxDQUFjMEIsU0FBZCxDQUF3QkUsR0FBeEIsQ0FBNEIwRSxRQUFRckcsT0FBUixDQUFnQitCLElBQTVDO0FBQ0E7QUFDVDtBQUNLd0csb0JBQWtCM0MsaUJBQWlCUyxRQUFRckcsT0FBUixDQUFnQitCLElBQWpDLENBQWxCO0FBQ047O0FBRURkLENBQUEsd0RBQUFBLENBQU91QixJQUFQLENBQVksUUFBWixFQUFzQjtBQUNyQm9FLE9BQUtQLFFBQVFyRyxPQUFSLENBQWdCNEcsR0FEQTtBQUVyQkMsV0FBUzBCLGVBRlk7QUFHckJ4RyxRQUFNc0UsUUFBUXJHLE9BQVIsQ0FBZ0IrQixJQUhEO0FBSXJCMkUsV0FBU2YsY0FBYzZDO0FBSkYsRUFBdEI7O0FBT0E1Rix5QkFBd0JnQixRQUF4QixHQUFtQyxJQUFuQztBQUNBZixjQUFhZSxRQUFiLEdBQXdCLElBQXhCOztBQUVBM0YsVUFBUzhCLElBQVQsQ0FBY2dCLFNBQWQsR0FBMEIsa0JBQTFCO0FBQ0E5QyxVQUFTOEIsSUFBVCxDQUFjMEIsU0FBZCxDQUF3QkUsR0FBeEIsQ0FBNEIsV0FBNUI7QUFDQTs7QUFFRHVELFlBQVkvRyxnQkFBWixDQUE2QixVQUE3QixFQUF5QyxVQUFVb0UsRUFBVixFQUFjO0FBQ3RELEtBQUk4RCxVQUFVOUQsR0FBR3VDLE1BQWpCOztBQUVBLFFBQU91QixXQUFXLENBQUNBLFFBQVE1RSxTQUFSLENBQWtCQyxRQUFsQixDQUEyQixTQUEzQixDQUFuQixFQUEwRDtBQUN6RDJFLFlBQVVBLFFBQVE4QixhQUFsQjtBQUNBOztBQUVELEtBQUksQ0FBQzlCLE9BQUwsRUFBYztBQUNiO0FBQ0E7O0FBRURnQyxpQkFBZ0JoQyxPQUFoQjtBQUNBLENBWkQ7O0FBY0FsQixzQkFBc0JoSCxnQkFBdEIsQ0FBdUMsT0FBdkMsRUFBZ0QsVUFBVW9FLEVBQVYsRUFBYztBQUM3RCxLQUFJOEQsVUFBVW5CLFlBQVlyRCxhQUFaLENBQTBCLG1CQUExQixDQUFkOztBQUVBLEtBQUksQ0FBQ3dFLE9BQUwsRUFBYztBQUNiO0FBQ0E7O0FBRURnQyxpQkFBZ0JoQyxPQUFoQjtBQUNBLENBUkQ7O0FBVUFqQix1QkFBdUJqSCxnQkFBdkIsQ0FBd0MsT0FBeEMsRUFBaUQsWUFBWTtBQUM1RHNLO0FBQ0EsQ0FGRDs7QUFJQSxTQUFTQSxvQkFBVCxHQUFnQztBQUMvQjdGLHlCQUF3QmdCLFFBQXhCLEdBQW1DLEtBQW5DO0FBQ0FmLGNBQWFlLFFBQWIsR0FBd0IsS0FBeEI7O0FBRUEzRixVQUFTOEIsSUFBVCxDQUFjZ0IsU0FBZCxHQUEwQixrQkFBMUI7QUFDQTs7QUFFRCxzRUFBNEIsc0JBQTVCLEVBQW9EMEgsb0JBQXBEOztBQUVBQyx1QkFBdUJ2SyxnQkFBdkIsQ0FBd0MsT0FBeEMsRUFBaUQsWUFBWTtBQUM1RHNLO0FBQ0EsQ0FGRDs7QUFJQUUsY0FBY3hLLGdCQUFkLENBQStCLE9BQS9CLEVBQXdDLFlBQVk7QUFDbkQsS0FBSWtJLFVBQVVuQixZQUFZckQsYUFBWixDQUEwQixtQkFBMUIsQ0FBZDtBQUNBLEtBQUkrRyxjQUFjdkMsUUFBUXJHLE9BQVIsQ0FBZ0IrQixJQUFsQztBQUNBLEtBQUk2RyxnQkFBZ0IsS0FBcEIsRUFBMkI7QUFDMUJBLGdCQUFjLEtBQWQ7QUFDQTtBQUNELEtBQUlDLGtCQUFrQjVLLFNBQVM0RCxhQUFULENBQXVCLCtCQUErQitHLFdBQS9CLEdBQTZDLG1CQUFwRSxFQUF5RnpKLEtBQS9HO0FBQ0FrSCxTQUFRckcsT0FBUixDQUFnQjZHLE9BQWhCLEdBQTBCZ0MsZUFBMUI7QUFDQVIsaUJBQWdCaEMsT0FBaEI7QUFDQSxDQVREOztBQVdBLFNBQVN5Qyx1QkFBVCxHQUFtQztBQUNsQyxLQUFJQyxZQUFZckQsUUFBUXlDLGFBQVIsQ0FBc0JZLFNBQXRDO0FBQ0FyRCxTQUFRaEMsS0FBUixDQUFjc0IsT0FBZCxHQUF3QixNQUF4QjtBQUNBVSxTQUFRVCxZQUFSO0FBQ0FTLFNBQVFoQyxLQUFSLENBQWNzQixPQUFkLEdBQXdCLEVBQXhCO0FBQ0FVLFNBQVF5QyxhQUFSLENBQXNCWSxTQUF0QixHQUFrQ0EsU0FBbEM7QUFDQTs7QUFFRCxHQUFHM0csT0FBSCxDQUFXaEYsSUFBWCxDQUNDYSxTQUFTb0UsZ0JBQVQsQ0FBMEIsNENBQTFCLENBREQsRUFFQyxVQUFVMkcsVUFBVixFQUFzQjtBQUNyQkEsWUFBVzdLLGdCQUFYLENBQTRCLFFBQTVCLEVBQXNDLFVBQVVvRSxFQUFWLEVBQWM7QUFDbkQsTUFBSTBHLGNBQWNoTCxTQUFTNEQsYUFBVCxDQUF1QixzREFBcURVLEdBQUd1QyxNQUFILENBQVUzRixLQUEvRCxHQUF1RSxJQUE5RixDQUFsQjtBQUNBLE1BQUk4SixXQUFKLEVBQWlCO0FBQ2hCQSxlQUFZVCxPQUFaLEdBQXNCLElBQXRCO0FBQ0EsR0FGRCxNQUVPO0FBQ05TLGlCQUFjaEwsU0FBUzRELGFBQVQsQ0FBdUIsbURBQXZCLENBQWQ7QUFDQSxPQUFJb0gsV0FBSixFQUFpQjtBQUNoQkEsZ0JBQVlULE9BQVosR0FBc0IsS0FBdEI7QUFDQTtBQUNEO0FBQ0RNO0FBQ0EsRUFYRDtBQVlBLENBZkY7O0FBa0JBLEdBQUcxRyxPQUFILENBQVdoRixJQUFYLENBQ0NhLFNBQVNvRSxnQkFBVCxDQUEwQiwyQ0FBMUIsQ0FERCxFQUVDLFVBQVU0RyxXQUFWLEVBQXVCO0FBQ3RCQSxhQUFZOUssZ0JBQVosQ0FBNkIsUUFBN0IsRUFBdUMsVUFBVW9FLEVBQVYsRUFBYztBQUNwRCxNQUFJeUcsYUFBYS9LLFNBQVM0RCxhQUFULENBQXVCLHVEQUFzRFUsR0FBR3VDLE1BQUgsQ0FBVTNGLEtBQWhFLEdBQXdFLElBQS9GLENBQWpCO0FBQ0EsTUFBSTZKLFVBQUosRUFBZ0I7QUFDZkEsY0FBV1IsT0FBWCxHQUFxQixJQUFyQjtBQUNBO0FBQ0RNO0FBQ0EsRUFORDtBQU9BLENBVkY7O0FBYUFuRCxjQUFjNkMsT0FBZCxHQUF5QixZQUFZO0FBQ3BDLEtBQUlVLGlCQUFpQmhILGFBQWFpQyxPQUFiLENBQXFCLGdCQUFyQixDQUFyQjtBQUNBLEtBQUkrRSxrQkFBa0JBLG1CQUFtQixPQUF6QyxFQUFrRDtBQUNqRCxTQUFPLEtBQVA7QUFDQSxFQUZELE1BRU87QUFDTixTQUFPLElBQVA7QUFDQTtBQUNELENBUHVCLEVBQXhCO0FBUUF2RCxjQUFjeEgsZ0JBQWQsQ0FBK0IsUUFBL0IsRUFBeUMsVUFBVW9FLEVBQVYsRUFBYztBQUN0REwsY0FBYXFGLE9BQWIsQ0FBcUIsZ0JBQXJCLEVBQXVDNUIsY0FBYzZDLE9BQXJEO0FBQ0EsQ0FGRCxFOzs7Ozs7OztBQzVXQTs7QUFFQSxTQUFTVyxZQUFULENBQXNCNUcsRUFBdEIsRUFBMEI7QUFDdEIsS0FBSTZHLHdCQUF3QjdHLEdBQUd1QyxNQUEvQjs7QUFFSCxRQUFPc0UseUJBQXlCLENBQUNBLHNCQUFzQjNILFNBQXRCLENBQWdDQyxRQUFoQyxDQUF5Qyx1QkFBekMsQ0FBakMsRUFBb0c7QUFDbkcwSCwwQkFBd0JBLHNCQUFzQmpCLGFBQTlDO0FBQ0E7O0FBRUQsS0FBSSxDQUFDaUIscUJBQUwsRUFBNEI7QUFDM0I7QUFDQTs7QUFFRCxLQUFJZCx1QkFBdUJjLHNCQUFzQnZILGFBQXRCLENBQW9DLHdCQUFwQyxDQUEzQjs7QUFFQSxLQUFJeUcsb0JBQUosRUFBMEI7QUFDekI3RixFQUFBLDBEQUFnQix5QkFBaEIsRUFBMkM2RixvQkFBM0M7QUFDQSxFQUZELE1BRU87QUFDTjdGLEVBQUEsMERBQWdCLFFBQWhCO0FBQ0E7QUFDRDs7QUFFRCxHQUFHTCxPQUFILENBQVdoRixJQUFYLENBQ0lhLFNBQVNvRSxnQkFBVCxDQUEwQixRQUExQixDQURKLEVBRUksVUFBVWdILEtBQVYsRUFBaUI7QUFDYkEsT0FBTWxMLGdCQUFOLENBQXVCLE9BQXZCLEVBQWdDZ0wsWUFBaEM7QUFDSCxDQUpMLEU7Ozs7Ozs7OztBQ3RCQTtBQUNBOztBQUVBLElBQUlHLE9BQU9yTCxTQUFTNEQsYUFBVCxDQUF1QixNQUF2QixDQUFYO0FBQUEsSUFDSTBILDhCQUE4QnRMLFNBQVNvRCxjQUFULENBQXdCLDZCQUF4QixDQURsQztBQUFBLElBRUlELG1CQUFtQm5ELFNBQVNvRCxjQUFULENBQXdCLGVBQXhCLENBRnZCO0FBQUEsSUFHSXVCLDBCQUEwQjNFLFNBQVNvRCxjQUFULENBQXdCLHlCQUF4QixDQUg5QjtBQUFBLElBSUl3QixlQUFlNUUsU0FBUzRELGFBQVQsQ0FBdUIsd0JBQXZCLENBSm5CO0FBQUEsSUFLSTJILGVBQWV2TCxTQUFTNEQsYUFBVCxDQUF1QixvQkFBdkIsQ0FMbkI7QUFBQSxJQU1JNEgsZ0JBQWdCeEwsU0FBUzRELGFBQVQsQ0FBdUIscUJBQXZCLENBTnBCO0FBQUEsSUFPSTZILHFCQUFxQnpMLFNBQVM0RCxhQUFULENBQXVCLGtDQUF2QixDQVB6QjtBQUFBLElBUUk4SCwwQkFBMEIxTCxTQUFTNEQsYUFBVCxDQUF1Qix1Q0FBdkIsQ0FSOUI7QUFBQSxJQVNJK0gsY0FBYzNMLFNBQVNvRCxjQUFULENBQXdCLGFBQXhCLENBVGxCO0FBQUEsSUFVSXdJLGdCQUFnQjVMLFNBQVNvRCxjQUFULENBQXdCLGVBQXhCLENBVnBCO0FBQUEsSUFXSXlJLGlCQUFpQixFQVhyQjs7QUFhQSxTQUFTQyx3QkFBVCxDQUFrQ0MsYUFBbEMsRUFBaURDLGNBQWpELEVBQWlFO0FBQ2hFLEtBQUlDLGNBQWMsS0FBbEI7QUFDQSxLQUFJRixnQkFBZ0IsQ0FBcEIsRUFBdUI7QUFDdEIvTCxXQUFTOEIsSUFBVCxDQUFjZ0IsU0FBZCxHQUEwQixrQkFBMUI7QUFDQW9KLHdCQUFzQm5JLFdBQXRCLEdBQW9DZ0ksYUFBcEM7QUFDQSxNQUFJQSxnQkFBZ0IsQ0FBcEIsRUFBdUI7QUFDdEJULCtCQUE0QnZKLE9BQTVCLENBQW9Db0ssSUFBcEMsR0FBMkMsSUFBM0M7QUFDQSxHQUZELE1BRU87QUFDTixVQUFPYiw0QkFBNEJ2SixPQUE1QixDQUFvQ29LLElBQTNDO0FBQ0E7QUFDRCxFQVJELE1BUU87QUFDTm5NLFdBQVM4QixJQUFULENBQWNnQixTQUFkLEdBQTBCLG1CQUExQjtBQUNBLE1BQUlpSixrQkFBa0IsQ0FBbEIsSUFBdUJDLGlCQUFpQixDQUE1QyxFQUErQztBQUM5Q2hNLFlBQVM4QixJQUFULENBQWNnQixTQUFkLEdBQTBCLG9CQUExQjtBQUNBOUMsWUFBUzhCLElBQVQsQ0FBYzBCLFNBQWQsQ0FBd0JLLE1BQXhCLENBQStCLHdCQUEvQixFQUF5RG1JLGlCQUFpQixDQUExRTtBQUNBO0FBQ0RDLGdCQUFjLElBQWQ7QUFDQTtBQUNELFFBQU9BLFdBQVA7QUFDQTs7QUFFRCxTQUFTRyxtQkFBVCxDQUE2QkMsU0FBN0IsRUFBd0NDLFNBQXhDLEVBQW1EO0FBQ2xELEtBQUl0TSxTQUFTOEIsSUFBVCxDQUFjMEIsU0FBZCxDQUF3QkMsUUFBeEIsQ0FBaUMsaUJBQWpDLEtBQXVETixpQkFBaUJLLFNBQWpCLENBQTJCQyxRQUEzQixDQUFvQyw2QkFBcEMsQ0FBM0QsRUFBK0g7QUFDOUg7QUFDQTtBQUNEa0IseUJBQXdCZ0IsUUFBeEIsR0FBbUMsS0FBbkM7QUFDQWYsY0FBYWUsUUFBYixHQUF3QixLQUF4QjtBQUNBa0csa0JBQWlCUSxTQUFqQjs7QUFFQSxLQUFJQSxTQUFKLEVBQWU7QUFDZCxNQUFJTixnQkFBZ0JPLFVBQVVoTCxNQUE5QjtBQUNBLE1BQUl3Syx5QkFBeUJDLGFBQXpCLEVBQXdDTSxVQUFVL0ssTUFBbEQsQ0FBSixFQUErRDtBQUM5RDtBQUNBO0FBQ0QrSixPQUFLdEosT0FBTCxDQUFhZ0ssYUFBYixHQUE2QkEsYUFBN0I7O0FBRUEsTUFBSVEsU0FBU0YsVUFBVUcsTUFBVixDQUFpQixVQUFVQyxJQUFWLEVBQWdCO0FBQzdDLFVBQU9BLEtBQUszSSxJQUFMLEtBQWMsT0FBckI7QUFDQSxHQUZZLENBQWI7QUFHQSxNQUFJNEksY0FBY0wsVUFBVUcsTUFBVixDQUFpQixVQUFVQyxJQUFWLEVBQWdCO0FBQ2xELFVBQU9BLEtBQUszSSxJQUFMLEtBQWMsY0FBckI7QUFDQSxHQUZpQixDQUFsQjs7QUFJQSxNQUFJaUksa0JBQWtCLENBQXRCLEVBQXlCO0FBQ3hCUixnQkFBYXhILFdBQWIsR0FBMkJ1SSxVQUFVLENBQVYsRUFBYTNOLElBQXhDO0FBQ0EsR0FGRCxNQUVPLElBQUlvTixnQkFBZ0IsQ0FBcEIsRUFBdUI7QUFDN0JQLGlCQUFjekgsV0FBZCxHQUE0QmdJLGFBQTVCO0FBQ0E7O0FBRUROLHFCQUFtQjFILFdBQW5CLEdBQWlDd0ksT0FBT2pMLE1BQXhDO0FBQ0FtSyxxQkFBbUJqSSxTQUFuQixDQUE2QkssTUFBN0IsQ0FBb0MsWUFBcEMsRUFBa0QwSSxPQUFPakwsTUFBUCxHQUFnQixDQUFsRTs7QUFFQW9LLDBCQUF3QjNILFdBQXhCLEdBQXNDMkksWUFBWXBMLE1BQWxEO0FBQ0FvSywwQkFBd0JsSSxTQUF4QixDQUFrQ0ssTUFBbEMsQ0FBeUMsaUJBQXpDLEVBQTRENkksWUFBWXBMLE1BQVosR0FBcUIsQ0FBakY7O0FBRUEsTUFBSW9MLFlBQVlwTCxNQUFaLElBQXNCLENBQXRCLElBQTJCeUssa0JBQWtCLENBQTdDLElBQWtEUSxPQUFPakwsTUFBUCxLQUFrQixDQUF4RSxFQUEyRTtBQUMxRSxPQUFJcUwsNEJBQTRCRCxZQUFZRixNQUFaLENBQW1CLFVBQVVJLFVBQVYsRUFBc0I7QUFDeEUsV0FBT0EsV0FBV0MsVUFBbEI7QUFDQSxJQUYrQixFQUU3QnZMLE1BRkg7O0FBSUEsT0FBSXFMLDRCQUE0QixDQUFoQyxFQUFtQztBQUNsQzNNLGFBQVM4QixJQUFULENBQWMwQixTQUFkLENBQXdCRSxHQUF4QixDQUE0Qix1QkFBNUI7QUFDQSxJQUZELE1BRU87QUFDTjFELGFBQVM4QixJQUFULENBQWMwQixTQUFkLENBQXdCRSxHQUF4QixDQUE0Qix5QkFBNUI7QUFDQTs7QUFFRCxPQUFJZ0osWUFBWXBMLE1BQVosS0FBdUIsQ0FBM0IsRUFBOEI7QUFDN0J0QixhQUFTOEIsSUFBVCxDQUFjMEIsU0FBZCxDQUF3QkUsR0FBeEIsQ0FBNEIsZUFBNUI7QUFDQWtCLGlCQUFhMkYsT0FBYixHQUF1QixDQUFDbUMsWUFBWSxDQUFaLEVBQWVJLFNBQXZDO0FBQ0E7QUFDRCxHQWZELE1BZU8sSUFBSVAsT0FBT2pMLE1BQVAsR0FBZ0IsQ0FBcEIsRUFBdUI7QUFDN0IsT0FBSXlMLHVCQUF1QlYsVUFBVUcsTUFBVixDQUFpQixVQUFVUSxLQUFWLEVBQWlCO0FBQzVELFdBQU9BLE1BQU1ILFVBQWI7QUFDQSxJQUYwQixFQUV4QnZMLE1BRkg7O0FBSUEsT0FBSXlMLHVCQUF1QixDQUEzQixFQUE4QjtBQUM3Qi9NLGFBQVM4QixJQUFULENBQWMwQixTQUFkLENBQXdCRSxHQUF4QixDQUE0QixrQkFBNUI7QUFDQSxJQUZELE1BRU87QUFDTjFELGFBQVM4QixJQUFULENBQWMwQixTQUFkLENBQXdCRSxHQUF4QixDQUE0QixvQkFBNUI7QUFDQTtBQUNEO0FBQ0Q7QUFDRDs7QUFFRCx3REFBQVYsQ0FBT0MsRUFBUCxDQUFVLHVCQUFWLEVBQW1DLFVBQVUzQyxJQUFWLEVBQWdCO0FBQ2xEeEMsQ0FBQSx3REFBQUEsQ0FBT2UsSUFBUCxDQUFZLDJCQUFaLEVBQXlDeUIsSUFBekMsRUFBK0MsRUFBL0M7QUFDQThMLHFCQUFvQjlMLEtBQUsrTCxTQUF6QixFQUFvQy9MLEtBQUtnTSxTQUF6QztBQUNBLENBSEQ7O0FBS0FYLFlBQVl6TCxnQkFBWixDQUE2QixPQUE3QixFQUFzQyxVQUFVb0UsRUFBVixFQUFjO0FBQ25EdEIsQ0FBQSx3REFBQUEsQ0FBT3VCLElBQVAsQ0FBWSxRQUFaLEVBQXNCO0FBQ3JCMEksVUFBUSxJQURhO0FBRXJCQyxRQUFNLEtBRmU7QUFHckJYLFVBQVFWLGNBSGE7QUFJckJ0QixXQUFTO0FBSlksRUFBdEI7QUFNQSxDQVBEOztBQVNBcUIsY0FBYzFMLGdCQUFkLENBQStCLE9BQS9CLEVBQXdDLFVBQVVvRSxFQUFWLEVBQWM7QUFDckR0QixDQUFBLHdEQUFBQSxDQUFPdUIsSUFBUCxDQUFZLFFBQVosRUFBc0I7QUFDckIwSSxVQUFRLElBRGE7QUFFckJDLFFBQU0sS0FGZTtBQUdyQkYsU0FBT25CLGNBSGM7QUFJckJ0QixXQUFTO0FBSlksRUFBdEI7QUFNQSxDQVBEOztBQVNBM0YsYUFBYTFFLGdCQUFiLENBQStCLFFBQS9CLEVBQXlDLFVBQVVvRSxFQUFWLEVBQWM7QUFDdER0QixDQUFBLHdEQUFBQSxDQUFPdUIsSUFBUCxDQUFZLFFBQVosRUFBc0I7QUFDckIwSSxVQUFRLEtBRGE7QUFFckJDLFFBQU0sSUFGZTtBQUdyQlgsVUFBUVYsY0FIYTtBQUlyQnRCLFdBQVNqRyxHQUFHdUMsTUFBSCxDQUFVMEQ7QUFKRSxFQUF0QjtBQU1BLENBUEQsRTs7Ozs7Ozs7OztBQzNIQTtBQUFBLFNBQVM0Qyx3QkFBVCxDQUFrQ0MsT0FBbEMsRUFBMkM7QUFDMUMsS0FBSWhFLFlBQVlnRSxRQUFRbEQsYUFBeEI7O0FBRUE7QUFDQSxRQUFPZCxhQUFhQSxVQUFVaUUsWUFBVixJQUEwQmpFLFVBQVVrRSxZQUF4RCxFQUFzRTtBQUNyRWxFLGNBQVlBLFVBQVVjLGFBQXRCO0FBQ0E7O0FBRUQsUUFBT2QsU0FBUDtBQUNBOztBQUVNLFNBQVNtRSxpQkFBVCxDQUEyQkgsT0FBM0IsRUFBb0NoRSxTQUFwQyxFQUErQztBQUNyREEsYUFBWUEsYUFBYStELHlCQUF5QkMsT0FBekIsQ0FBekI7O0FBRUEsS0FBSSxDQUFDaEUsU0FBTCxFQUFnQjtBQUNmO0FBQ0E7O0FBRUQsS0FBSW9FLGNBQWNKLFFBQVFLLHFCQUFSLEVBQWxCO0FBQUEsS0FDQ0MsZ0JBQWdCdEUsVUFBVXFFLHFCQUFWLEVBRGpCOztBQUdBLEtBQUlELFlBQVlHLEdBQVosR0FBa0JELGNBQWNDLEdBQXBDLEVBQXlDO0FBQ3hDdkUsWUFBVTBCLFNBQVYsSUFBdUI0QyxjQUFjQyxHQUFkLEdBQW9CSCxZQUFZRyxHQUF2RDtBQUNBLEVBRkQsTUFFTyxJQUFJSCxZQUFZSSxNQUFaLEdBQXFCRixjQUFjRSxNQUF2QyxFQUErQztBQUNyRHhFLFlBQVUwQixTQUFWLElBQXVCMEMsWUFBWUksTUFBWixHQUFxQkYsY0FBY0UsTUFBMUQ7QUFDQTtBQUNELEM7Ozs7Ozs7OztBQzFCRCw2Qjs7Ozs7O0FDQUEsc0I7Ozs7OztBQ0FBLHlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6InBhbmVsLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pXG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG5cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGlkZW50aXR5IGZ1bmN0aW9uIGZvciBjYWxsaW5nIGhhcm1vbnkgaW1wb3J0cyB3aXRoIHRoZSBjb3JyZWN0IGNvbnRleHRcbiBcdF9fd2VicGFja19yZXF1aXJlX18uaSA9IGZ1bmN0aW9uKHZhbHVlKSB7IHJldHVybiB2YWx1ZTsgfTtcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7XG4gXHRcdFx0XHRjb25maWd1cmFibGU6IGZhbHNlLFxuIFx0XHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcbiBcdFx0XHRcdGdldDogZ2V0dGVyXG4gXHRcdFx0fSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gMjMpO1xuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIHdlYnBhY2svYm9vdHN0cmFwIDMyM2JhZDFiYTU0NTJjNTgzMGE0IiwiaW1wb3J0IHdpbnN0b24gZnJvbSBcIndpbnN0b25cIjtcbmltcG9ydCBwYXRoIGZyb20gXCJwYXRoXCI7XG5pbXBvcnQgUGFuZWxDb25maWcgZnJvbSBcIi4vY29uZmlnXCI7XG5cbnZhciBsb2dnZXI7XG5pZiAod2luc3Rvbi5Mb2dnZXIpIHtcblx0bG9nZ2VyID0gbmV3ICh3aW5zdG9uLkxvZ2dlcikoe1xuXHRcdHRyYW5zcG9ydHM6IFtcblx0XHRcdG5ldyAod2luc3Rvbi50cmFuc3BvcnRzLkRhaWx5Um90YXRlRmlsZSkoe1xuXHRcdFx0XHRmaWxlbmFtZTogKGZ1bmN0aW9uICgpIHtcblx0XHRcdFx0XHRpZiAocHJvY2Vzcy5wbGF0Zm9ybSA9PT0gXCJ3aW4zMlwiKSB7XG5cdFx0XHRcdFx0XHRyZXR1cm4gcGF0aC5yZXNvbHZlKHByb2Nlc3MuZW52LkFQUERBVEEsIFwiWmVwbGluXCIsIFBhbmVsQ29uZmlnLm5hbWUgKyBcIi5sb2dcIik7XG5cdFx0XHRcdFx0fSBlbHNlIGlmIChwcm9jZXNzLnBsYXRmb3JtID09PSBcImRhcndpblwiKSB7XG5cdFx0XHRcdFx0XHRyZXR1cm4gcGF0aC5yZXNvbHZlKHByb2Nlc3MuZW52LkhPTUUsIFwiTGlicmFyeVwiLCBcIkxvZ3NcIiwgXCJaZXBsaW5cIiwgUGFuZWxDb25maWcubmFtZSArIFwiLmxvZ1wiKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0pKClcblx0XHRcdH0pXG5cdFx0XVxuXHR9KTtcbn0gZWxzZSB7XG5cdGxvZ2dlciA9IHtcblx0XHRpbmZvOiBmdW5jdGlvbiAoKSB7XG5cdFx0XHRjb25zb2xlLmxvZyhBcnJheS5wcm90b3R5cGUuam9pbi5jYWxsKGFyZ3VtZW50cywgXCIsIFwiKSk7XG5cdFx0fSxcblx0XHRlcnJvcjogZnVuY3Rpb24gKCkge1xuXHRcdFx0Y29uc29sZS5lcnJvcihBcnJheS5wcm90b3R5cGUuam9pbi5jYWxsKGFyZ3VtZW50cywgXCIsIFwiKSk7XG5cdFx0fVxuXHR9O1xufVxud2luZG93Lm9uZXJyb3IgPSBmdW5jdGlvbiAobWVzc2FnZSwgc291cmNlLCBsaW5lbm8sIGNvbG5vLCBlcnJvcikge1xuXHRsb2dnZXIuZXJyb3IoXCIlczolZDolZCAlcyAlalwiLCBzb3VyY2UsIGxpbmVubywgY29sbm8sIG1lc3NhZ2UsIGVycm9yLCB7fSk7XG5cdHJldHVybiB0cnVlO1xufTtcbmxvZ2dlci5pbmZvKFwibG9nZ2VyIGlzIGluaXRpYWxpemVkXCIpO1xuZXhwb3J0IGRlZmF1bHQgbG9nZ2VyO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuLi9FeHRlbnNpb25Db250ZW50L3NyYy9sb2dnZXIuanMiLCJpbXBvcnQgUGFuZWxDb25maWcgZnJvbSBcIi4vY29uZmlnXCI7XG5pbXBvcnQgbG9nZ2VyIGZyb20gXCIuL2xvZ2dlclwiO1xuXG5sb2dnZXIuaW5mbyhcImNvbm5lY3RpbmcgdG8gdXJsOiAlc1wiLCBQYW5lbENvbmZpZy5zb2NrZXRVcmwpO1xuZXhwb3J0IGRlZmF1bHQgaW8uY29ubmVjdChQYW5lbENvbmZpZy5zb2NrZXRVcmwpO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuLi9FeHRlbnNpb25Db250ZW50L3NyYy9zb2NrZXQuanMiLCJpbXBvcnQgbG9nZ2VyIGZyb20gXCIuL2xvZ2dlclwiO1xuXG52YXIgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcblxuZXhwb3J0IGZ1bmN0aW9uIGFkZEV2ZW50TGlzdGVuZXIoZXZlbnQsIGxpc3RlbmVyKSB7XG4gICAgZGl2LmFkZEV2ZW50TGlzdGVuZXIoZXZlbnQsIGxpc3RlbmVyKTsgICAgXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzZW5kKGV2ZW50LCBkYXRhKSB7XG4gICAgbG9nZ2VyLmluZm8oXCJzZW5kaW5nIFwiICsgZXZlbnQgKyBcIjogXCIgKyBkYXRhKTtcbiAgICBkaXYuZGlzcGF0Y2hFdmVudChuZXcgQ3VzdG9tRXZlbnQoZXZlbnQsIHsgZGV0YWlsOiBkYXRhIH0pKTtcbn1cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi4vRXh0ZW5zaW9uQ29udGVudC9zcmMvZGlzcGF0Y2hlci5qcyIsImV4cG9ydCBkZWZhdWx0IHtcbiAgICBzb2NrZXRVcmw6IFwiaHR0cDovLzEyNy4wLjAuMToxNzk5OVwiLFxuICAgIG5hbWU6IFwiaW8uemVwbGluLnBob3Rvc2hvcC1wYW5lbFwiLFxuICAgIGV4dGVuc2lvbklkOiBcImlvLnplcGxpbi5wcy5leHRlbnNpb25cIlxufVxuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuLi9FeHRlbnNpb25Db250ZW50L3NyYy9jb25maWcuanMiLCJpbXBvcnQgQ1NJbnRlcmZhY2UgZnJvbSBcImNzaW50ZXJmYWNlXCI7XG5pbXBvcnQgUGFuZWxDb25maWcgZnJvbSBcIi4vY29uZmlnXCI7XG5cbnZhciBjc0ludGVyZmFjZSA9IG5ldyBDU0ludGVyZmFjZSgpO1xuXG5mdW5jdGlvbiBtYWtlUGVyc2lzdGVudChjc0ludGVyZmFjZSkge1xuXHR2YXIgZXZlbnQgPSBuZXcgQ1NFdmVudChcImNvbS5hZG9iZS5QaG90b3Nob3BQZXJzaXN0ZW50XCIsIFwiQVBQTElDQVRJT05cIik7XG5cdGV2ZW50LmV4dGVuc2lvbklkID0gUGFuZWxDb25maWcuZXh0ZW5zaW9uSWQ7XG5cdGNzSW50ZXJmYWNlLmRpc3BhdGNoRXZlbnQoZXZlbnQpO1xufVxuXG4vKipcbiAqIENvbnZlcnQgdGhlIENvbG9yIG9iamVjdCB0byBzdHJpbmcgaW4gaGV4YWRlY2ltYWwgZm9ybWF0O1xuICovXG5mdW5jdGlvbiB0b0hleChjb2xvciwgZGVsdGEpIHtcblx0ZnVuY3Rpb24gY29tcHV0ZVZhbHVlKHZhbHVlLCBkZWx0YSkge1xuXHRcdHZhciBjb21wdXRlZFZhbHVlID0gIWlzTmFOKGRlbHRhKSA/IHZhbHVlICsgZGVsdGEgOiB2YWx1ZTtcblx0XHRpZiAoY29tcHV0ZWRWYWx1ZSA8IDApIHtcblx0XHRcdGNvbXB1dGVkVmFsdWUgPSAwO1xuXHRcdH0gZWxzZSBpZiAoY29tcHV0ZWRWYWx1ZSA+IDI1NSkge1xuXHRcdFx0Y29tcHV0ZWRWYWx1ZSA9IDI1NTtcblx0XHR9XG5cblx0XHRjb21wdXRlZFZhbHVlID0gY29tcHV0ZWRWYWx1ZS50b1N0cmluZygxNik7XG5cdFx0cmV0dXJuIGNvbXB1dGVkVmFsdWUubGVuZ3RoID09IDEgPyBcIjBcIiArIGNvbXB1dGVkVmFsdWUgOiBjb21wdXRlZFZhbHVlO1xuXHR9XG5cblx0dmFyIGhleCA9IFwiXCI7XG5cdGlmIChjb2xvcikge1xuXHRcdGhleCA9IGNvbXB1dGVWYWx1ZShjb2xvci5yZWQsIGNvbG9yLmRlbHRhKSArIGNvbXB1dGVWYWx1ZShjb2xvci5ncmVlbiwgY29sb3IuZGVsdGEpICsgY29tcHV0ZVZhbHVlKGNvbG9yLmJsdWUsIGNvbG9yLmRlbHRhKTtcblx0fVxuXHRyZXR1cm4gaGV4O1xufVxuXG4vKipcbiAqIFVwZGF0ZSB0aGUgdGhlbWUgd2l0aCB0aGUgQXBwU2tpbkluZm8gcmV0cmlldmVkIGZyb20gdGhlIGhvc3QgcHJvZHVjdC5cbiAqL1xuZnVuY3Rpb24gdXBkYXRlVGhlbWVXaXRoQXBwU2tpbkluZm8oYXBwU2tpbkluZm8pIHtcblx0dmFyIHBhbmVsQmFja2dyb3VuZENvbG9yID0gYXBwU2tpbkluZm8ucGFuZWxCYWNrZ3JvdW5kQ29sb3IuY29sb3I7XG5cdGRvY3VtZW50LmJvZHkuZGF0YXNldC5iZyA9IFwiYmdcIiArIHRvSGV4KHBhbmVsQmFja2dyb3VuZENvbG9yKTtcbn1cblxuZnVuY3Rpb24gb25BcHBUaGVtZUNvbG9yQ2hhbmdlZChldmVudCkge1xuXHQvLyBTaG91bGQgZ2V0IGEgbGF0ZXN0IEhvc3RFbnZpcm9ubWVudCBvYmplY3QgZnJvbSBhcHBsaWNhdGlvbi5cblx0dmFyIHNraW5JbmZvID0gSlNPTi5wYXJzZSh3aW5kb3cuX19hZG9iZV9jZXBfXy5nZXRIb3N0RW52aXJvbm1lbnQoKSkuYXBwU2tpbkluZm87XG5cdC8vIEdldHMgdGhlIHN0eWxlIGluZm9ybWF0aW9uIHN1Y2ggYXMgY29sb3IgaW5mbyBmcm9tIHRoZSBza2luSW5mbywgXG5cdC8vIGFuZCByZWRyYXcgYWxsIFVJIGNvbnRyb2xzIG9mIHlvdXIgZXh0ZW5zaW9uIGFjY29yZGluZyB0byB0aGUgc3R5bGUgaW5mby5cblx0dXBkYXRlVGhlbWVXaXRoQXBwU2tpbkluZm8oc2tpbkluZm8pO1xufVxuXG51cGRhdGVUaGVtZVdpdGhBcHBTa2luSW5mbyhjc0ludGVyZmFjZS5ob3N0RW52aXJvbm1lbnQuYXBwU2tpbkluZm8pO1xuLy8gVXBkYXRlIHRoZSBjb2xvciBvZiB0aGUgcGFuZWwgd2hlbiB0aGUgdGhlbWUgY29sb3Igb2YgdGhlIHByb2R1Y3QgY2hhbmdlZC5cbmNzSW50ZXJmYWNlLmFkZEV2ZW50TGlzdGVuZXIoQ1NJbnRlcmZhY2UuVEhFTUVfQ09MT1JfQ0hBTkdFRF9FVkVOVCwgb25BcHBUaGVtZUNvbG9yQ2hhbmdlZCk7XG5cbm1ha2VQZXJzaXN0ZW50KGNzSW50ZXJmYWNlKTtcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi4vRXh0ZW5zaW9uQ29udGVudC9zcmMvYmdjb2xvci5qcyIsImltcG9ydCBzb2NrZXQgZnJvbSBcIi4vc29ja2V0XCI7XG5pbXBvcnQgbG9nZ2VyIGZyb20gXCIuL2xvZ2dlclwiO1xuXG52YXIgdG9sZXJhdGlvbkRlbGF5ID0gMjAwMDAsXG4gICAgdGVsb3JhdGlvblRpbWVvdXRJZCA9IDAsXG4gICAgY29ubmVjdGVkID0gZmFsc2U7XG5cbmZ1bmN0aW9uIG9uQ29ubmVjdEVycm9yKGVycm9yKSB7XG4gICAgaWYgKGRvY3VtZW50LmJvZHkuY2xhc3NOYW1lID09PSBcImNvbm5lY3Rpb25GYWlsdXJlRGlzcGxheVwiKSB7XG4gICAgICAgIGxvZ2dlci5pbmZvKFwiYWxyZWFkeSBzaG93aW5nIGNvbm5lY3Rpb24gZmFpbHVyZSBkaXNwbGF5LCBza2lwcGluZ1wiKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAodGVsb3JhdGlvblRpbWVvdXRJZCkge1xuICAgICAgICBsb2dnZXIuaW5mbyhcImlnbm9yaW5nIHRoaXMsIGFscmVhZHkgc2V0dXAgdG9sZXJhdGlvbiBkZWxheVwiKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoY29ubmVjdGVkKSB7IC8vIGNvbm5lY3RlZCBiZWZvcmUgaW4gdGhpcyBzZXNzaW9uIGFscmVhZHksXG4gICAgICAgIGxvZ2dlci5pbmZvKFwiYWxyZWFkeSBjb25uZWN0ZWQgYmVmb3JlIGluIHRoaXMgc2Vzc2lvbiwgc2hvd2luZyBjb25uZWN0IGVycm9yIHJpZ2h0IG5vd1wiKTtcbiAgICAgICAgbG9nZ2VyLmVycm9yKFwiY29ubmVjdGlvbiBlcnJvcjogJWpcIiwgZXJyb3IsIHt9KTtcbiAgICAgICAgZG9jdW1lbnQuYm9keS5jbGFzc05hbWUgPSBcImNvbm5lY3Rpb25GYWlsdXJlRGlzcGxheVwiO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGxvZ2dlci5pbmZvKFwiaW5pdGlhbCBjb25uZWN0IGVycm9yLCBzZXR0aW5nIHVwIHRvbGVyYXRpb24gZGVsYXkgdG8gZGlzcGxheSBjb25uZWN0aW9uIGZhaWx1cmUgXCIpO1xuICAgIHRlbG9yYXRpb25UaW1lb3V0SWQgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgbG9nZ2VyLmluZm8oXCJnaXZpbmcgdXAgYWZ0ZXIgdG9sZXJhdGlvbiBkZWxheVwiKTtcbiAgICAgICAgbG9nZ2VyLmVycm9yKFwiY29ubmVjdGlvbiBlcnJvcjogJWpcIiwgZXJyb3IsIHt9KTtcbiAgICAgICAgZG9jdW1lbnQuYm9keS5jbGFzc05hbWUgPSBcImNvbm5lY3Rpb25GYWlsdXJlRGlzcGxheVwiO1xuICAgICAgICB0ZWxvcmF0aW9uVGltZW91dElkID0gMDtcbiAgICB9LCB0b2xlcmF0aW9uRGVsYXkpO1xufVxuXG5zb2NrZXQub24oXCJjb25uZWN0X2Vycm9yXCIsIG9uQ29ubmVjdEVycm9yKTtcbnNvY2tldC5vbihcImNvbm5lY3RfdGltZW91dFwiLCBvbkNvbm5lY3RFcnJvcik7XG5cbnNvY2tldC5vbihcImNvbm5lY3RcIiwgZnVuY3Rpb24gKCkge1xuICAgIGxvZ2dlci5pbmZvKFwiY29ubmVjdGVkXCIpO1xuICAgIGlmICh0ZWxvcmF0aW9uVGltZW91dElkKSB7XG4gICAgICAgIGxvZ2dlci5pbmZvKFwiY2xlYXJpbmcgdG9sZXJhdGlvbiB0aW1lb3V0OiAlZFwiLCB0ZWxvcmF0aW9uVGltZW91dElkKTtcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRlbG9yYXRpb25UaW1lb3V0SWQpO1xuICAgICAgICB0ZWxvcmF0aW9uVGltZW91dElkID0gMDtcbiAgICB9XG4gICAgZG9jdW1lbnQuYm9keS5jbGFzc05hbWUgPSBcImFydGJvYXJkU2VsZWN0aW9uXCI7XG4gICAgY29ubmVjdGVkID0gdHJ1ZTtcbn0pO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuLi9FeHRlbnNpb25Db250ZW50L3NyYy9jb25uZWN0aW9uLmpzIiwiaW1wb3J0IHNvY2tldCBmcm9tIFwiLi9zb2NrZXRcIjtcbmltcG9ydCBsb2dnZXIgZnJvbSBcIi4vbG9nZ2VyXCI7XG5pbXBvcnQgKiBhcyBkaXNwYXRjaGVyIGZyb20gXCIuL2Rpc3BhdGNoZXJcIjtcblxudmFyIHNlbGVjdFByb2plY3REaXYgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInNlbGVjdFByb2plY3RcIik7XG5cbnNvY2tldC5vbihcInplcGxpbkVycm9yXCIsIGZ1bmN0aW9uIChlcnJvcikge1xuICAgIGxvZ2dlci5lcnJvcihcImVycm9yIHJlY2V2aWVkIGZvciB6ZXBsaW5FcnJvcjogJWpcIiwgZXJyb3IsIHt9KTtcbiAgICB2YXIgZWwsIGdldHRpbmdQcm9qZWN0c0ZhaWxlZFRpdGxlLCBwbGFuRXJyb3JUZXh0O1xuICAgIGlmIChzZWxlY3RQcm9qZWN0RGl2LmNsYXNzTGlzdC5jb250YWlucyhcImdldHRpbmdPcmdhbml6YXRpb25Qcm9qZWN0c1wiKSkge1xuICAgICAgICBlbCA9IHNlbGVjdFByb2plY3REaXY7XG4gICAgICAgIGVsLmNsYXNzTGlzdC5hZGQoXCJnZXR0aW5nUHJvamVjdHNGYWlsZWRcIik7XG4gICAgICAgIGVsLmNsYXNzTGlzdC5yZW1vdmUoXCJnZXR0aW5nT3JnYW5pemF0aW9uUHJvamVjdHNcIik7XG4gICAgICAgIGdldHRpbmdQcm9qZWN0c0ZhaWxlZFRpdGxlID0gZWwucXVlcnlTZWxlY3RvcihcIi5nZXR0aW5nUHJvamVjdHNGYWlsZWRUaXRsZSBzdHJvbmdcIik7XG4gICAgICAgIHBsYW5FcnJvclRleHQgPSBlbC5xdWVyeVNlbGVjdG9yKFwiLnBsYW5FcnJvclRleHRcIik7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgZWwgPSBkb2N1bWVudC5ib2R5O1xuICAgICAgICBlbC5jbGFzc05hbWUgPSBcImdldHRpbmdQcm9qZWN0c0ZhaWxlZFwiO1xuICAgICAgICBnZXR0aW5nUHJvamVjdHNGYWlsZWRUaXRsZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJib2R5ID4gLmdldHRpbmdQcm9qZWN0c0ZhaWxlZENvbnRlbnQgLmdldHRpbmdQcm9qZWN0c0ZhaWxlZFRpdGxlIHN0cm9uZ1wiKTtcbiAgICAgICAgcGxhbkVycm9yVGV4dCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJib2R5ID4gLmdldHRpbmdQcm9qZWN0c0ZhaWxlZENvbnRlbnQgLnBsYW5FcnJvclRleHRcIik7XG4gICAgfVxuICAgIFxuICAgIGVsLmNsYXNzTGlzdC50b2dnbGUoXCJ0aW1lb3V0RXJyb3JcIiwgZXJyb3IudHlwZSA9PT0gXCJ0aW1lb3V0XCIpO1xuICAgIGVsLmNsYXNzTGlzdC50b2dnbGUoXCJ6ZXBsaW5Ub2tlbkVycm9yXCIsIGVycm9yLnR5cGUgPT09IFwidG9rZW5fbm90X2ZvdW5kXCIpO1xuICAgIGVsLmNsYXNzTGlzdC50b2dnbGUoXCJwbGFuRXJyb3JcIiwgZXJyb3IudHlwZSA9PT0gXCJwbGFuXCIpO1xuICAgIGlmIChlcnJvci50eXBlID09PSBcInBsYW5cIikge1xuICAgICAgICBnZXR0aW5nUHJvamVjdHNGYWlsZWRUaXRsZS50ZXh0Q29udGVudCA9IGVycm9yLnRpdGxlO1xuICAgICAgICBwbGFuRXJyb3JUZXh0LnRleHRDb250ZW50ID0gZXJyb3IubWVzc2FnZTtcbiAgICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oXCJsYXN0U2VsZWN0ZWRQcm9qZWN0XCIpO1xuICAgIH1cbiAgICBpZiAoZXJyb3IudHlwZSA9PT0gXCJldmljdF9jYWNoZVwiKSB7XG4gICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKFwibGFzdFNlbGVjdGVkUHJvamVjdFwiKTtcbiAgICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oXCJsYXN0U2VsZWN0ZWRPcmdhbml6YXRpb25cIik7XG4gICAgfVxufSk7XG5cbltdLmZvckVhY2guY2FsbChcbiAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLnplcGxpblRva2VuRXJyb3JSZXRyeVwiKSxcbiAgICBmdW5jdGlvbiAoemVwbGluVG9rZW5FcnJvclJldHJ5KSB7XG4gICAgICAgIHplcGxpblRva2VuRXJyb3JSZXRyeS5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24gKGV2KSB7XG4gICAgICAgICAgICBzb2NrZXQuZW1pdChcIm9wZW5aZXBsaW5cIik7XG4gICAgICAgICAgICBkaXNwYXRjaGVyLnNlbmQoXCJnb1RvU2VsZWN0aW9uRGlzcGxheVwiKTtcbiAgICAgICAgfSk7XG4gICAgfVxuKTtcblxuW10uZm9yRWFjaC5jYWxsKFxuICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIuZ290SXRJbVBvb3JcIiksXG4gICAgZnVuY3Rpb24gKGdvdEl0SW1Qb29yKSB7XG4gICAgICAgIGdvdEl0SW1Qb29yLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBkaXNwYXRjaGVyLnNlbmQoXCJnb1RvU2VsZWN0aW9uRGlzcGxheVwiKTtcbiAgICAgICAgfSk7XG4gICAgfVxuKTtcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi4vRXh0ZW5zaW9uQ29udGVudC9zcmMvZXJyb3IuanMiLCJpbXBvcnQgbG9nZ2VyIGZyb20gXCIuL2xvZ2dlclwiO1xuaW1wb3J0IHNvY2tldCBmcm9tIFwiLi9zb2NrZXRcIjtcbmltcG9ydCAqIGFzIGRpc3BhdGNoZXIgZnJvbSBcIi4vZGlzcGF0Y2hlclwiO1xuXG52YXIgcHJvZ3Jlc3MgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInByb2dyZXNzXCIpLFxuICAgIGV4cG9ydFNlbGVjdGVkQXJ0Ym9hcmRzID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJleHBvcnRTZWxlY3RlZEFydGJvYXJkc1wiKSxcbiAgICBza2lwQ2hlY2tib3ggPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdpbnB1dFt0eXBlPVwiY2hlY2tib3hcIl0nKSxcbiAgICBmYWlsZWRMYXllciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZmFpbGVkTGF5ZXJcIiksXG4gICAgZmFpbGVkQXJ0Ym9hcmQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImZhaWxlZEFydGJvYXJkXCIpLFxuICAgIHJlcG9ydCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicmVwb3J0XCIpLFxuICAgIGdvdEl0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJnb3RJdFwiKTtcblxuZnVuY3Rpb24gcHJlcGFyZVJlcG9ydEhyZWYoZXJyb3IsIHN0YWNrKSB7XG5cdHJldHVybiBlbmNvZGVVUkkoXCJtYWlsdG86c3VwcG9ydEB6ZXBsaW4uaW8/c3ViamVjdD1QaG90b3Nob3AgRXhwb3J0IEVycm9yJmJvZHk9SSBqdXN0IGdvdCBhbiBlcnJvciB3aGVuIGV4cG9ydGluZyBhcnRib2FyZHMgZnJvbSBQaG90b3Nob3A6XFxuXFxuXCIgKyAoZXJyb3IgPyBlcnJvciA6IFwiXCIpICsgKHN0YWNrID8gXCJcXG5cXG5cIiArIHN0YWNrIDogXCJcIikpO1xufVxuXG5zb2NrZXQub24oXCJwcm9ncmVzc1wiLCBmdW5jdGlvbiAoZGF0YSkge1xuICAgIGxvZ2dlci5pbmZvKFwiZ2VuZXJhdG9yIHNlbnQgcHJvZ3Jlc3M6ICVqXCIsIGRhdGEsIHt9KTtcbiAgICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5hZGQoXCJ3aXRoUHJvZ3Jlc3NcIik7XG4gICAgdmFyIHByb2dyZXNzUGVyY2VudGFnZSA9IE1hdGguZmxvb3IoKGRhdGEuY291bnQgLyBkYXRhLnRvdGFsKSAqIDEwMCk7XG4gICAgcHJvZ3Jlc3Muc3R5bGUud2lkdGggPSBwcm9ncmVzc1BlcmNlbnRhZ2UgKyBcIiVcIjtcbn0pO1xuXG5zb2NrZXQub24oXCJjb21wbGV0ZVwiLCBmdW5jdGlvbiAoZGF0YSkge1xuICAgIHByb2dyZXNzLnN0eWxlLndpZHRoID0gXCIxMDAlXCI7XG4gICAgbG9nZ2VyLmluZm8oXCJnZW5lcmF0b3Igc2VudCBjb21wbGV0ZTogJWpcIiwgZGF0YSwge30pO1xuXG4gICAgZXhwb3J0U2VsZWN0ZWRBcnRib2FyZHMuZGlzYWJsZWQgPSBmYWxzZTtcbiAgICBza2lwQ2hlY2tib3guZGlzYWJsZWQgPSBmYWxzZTtcbiAgICBwcm9ncmVzcy5zdHlsZS53aWR0aCA9IFwiMCVcIjtcbiAgICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5yZW1vdmUoXCJleHBvcnRpbmdcIiwgXCJ3aXRoUHJvZ3Jlc3NcIik7XG4gICAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QuYWRkKFwic2VsZWN0aW9uRGlzcGxheVwiKTtcbn0pO1xuXG5zb2NrZXQub24oXCJwYXJzZUVycm9yXCIsIGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgbG9nZ2VyLmVycm9yKFwiZ2VuZXJhdG9yIHNlbnQgYW4gZXJyb3I6ICVqXCIsIGRhdGEuZXJyb3IsIHt9KTtcblxuICAgIGZhaWxlZExheWVyLnRleHRDb250ZW50ID0gZGF0YS5sYXllck5hbWU7XG4gICAgZmFpbGVkTGF5ZXIuY2xhc3NMaXN0LnRvZ2dsZShcImhpZGRlblwiLCAhZGF0YS5sYXllck5hbWUpO1xuXG4gICAgZmFpbGVkQXJ0Ym9hcmQudGV4dENvbnRlbnQgPSBkYXRhLmFydGJvYXJkTmFtZTtcblxuICAgIHJlcG9ydC5ocmVmID0gcHJlcGFyZVJlcG9ydEhyZWYoZGF0YS5lcnJvci5tZXNzYWdlLCBkYXRhLmVycm9yLnN0YWNrKTtcblxuICAgIGV4cG9ydFNlbGVjdGVkQXJ0Ym9hcmRzLmRpc2FibGVkID0gZmFsc2U7XG4gICAgc2tpcENoZWNrYm94LmRpc2FibGUgPSBmYWxzZTtcbiAgICBwcm9ncmVzcy5zdHlsZS53aWR0aCA9IFwiMCVcIjtcbiAgICBkb2N1bWVudC5ib2R5LmNsYXNzTmFtZSA9IFwiZmFpbHVyZURpc3BsYXlcIjtcbn0pO1xuXG5mdW5jdGlvbiBvbkNsaWNrRXhwb3J0KCkge1xuICAgIHZhciBkYXRhO1xuICAgIHZhciBsYXN0U2VsZWN0ZWRPcmdhbml6YXRpb24gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImxhc3RTZWxlY3RlZE9yZ2FuaXphdGlvblwiKTtcbiAgICBpZiAobGFzdFNlbGVjdGVkT3JnYW5pemF0aW9uICYmIGxhc3RTZWxlY3RlZE9yZ2FuaXphdGlvbiAhPT0gXCJ1c2VyXCIpIHtcbiAgICAgICAgZGF0YSA9IHtcbiAgICAgICAgICAgIG9pZDogbGFzdFNlbGVjdGVkT3JnYW5pemF0aW9uXG4gICAgICAgIH07XG4gICAgfVxuICAgIHNvY2tldC5lbWl0KFwiaW5pdGlhdGVcIiwgZGF0YSk7XG4gICAgZG9jdW1lbnQuYm9keS5jbGFzc05hbWUgPSBcImdldHRpbmdQcm9qZWN0c1wiO1xufVxuXG5leHBvcnRTZWxlY3RlZEFydGJvYXJkcy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgb25DbGlja0V4cG9ydCk7XG5cbmRpc3BhdGNoZXIuYWRkRXZlbnRMaXN0ZW5lcihcImV4cG9ydFwiLCBvbkNsaWNrRXhwb3J0KTtcblxuZ290SXQuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uIChldikge1xuICAgIGRpc3BhdGNoZXIuc2VuZChcImdvVG9TZWxlY3Rpb25EaXNwbGF5XCIpO1xufSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4uL0V4dGVuc2lvbkNvbnRlbnQvc3JjL2V4cG9ydC5qcyIsInZhciBsaW5rcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJhXCIpO1xudmFyIHplcGxpbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiemVwbGluXCIpO1xudmFyIHdoYXRJTmVlZFRvQ2hvb3NlRm9yRGVuc2l0eSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjc2VsZWN0RGVuc2l0eUNvbW1hbmRzIC5mb290ZXJDb21tYW5kc0hlYWRlckxpbmVcIik7XG5cbmZ1bmN0aW9uIG9wZW5JbkRlZmF1bHRCcm93c2VyIChlKSB7XG5cdGUucHJldmVudERlZmF1bHQoKTtcblx0d2luZG93LmNlcC51dGlsLm9wZW5VUkxJbkRlZmF1bHRCcm93c2VyKGUudGFyZ2V0LmhyZWYpO1xufVxuXG56ZXBsaW4uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uICgpIHtcblx0d2luZG93LmNlcC51dGlsLm9wZW5VUkxJbkRlZmF1bHRCcm93c2VyKFwiaHR0cHM6Ly96ZXBsaW4uaW9cIik7XG59KTtcblxud2hhdElOZWVkVG9DaG9vc2VGb3JEZW5zaXR5LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbiAoKSB7XG4gICAgd2luZG93LmNlcC51dGlsLm9wZW5VUkxJbkRlZmF1bHRCcm93c2VyKFwiaHR0cHM6Ly9zdXBwb3J0LnplcGxpbi5pby9mYXEvYWxsLXRoZS1tZWFzdXJlbWVudHMtYXJlLXdyb25nLWhhbGZ0d2ljZS10aGUtc2l6ZVwiKTtcbn0pO1xuXG5mb3IodmFyIGkgPSAwOyBpIDwgbGlua3MubGVuZ3RoOyBpKyspIHtcblx0bGlua3NbaV0uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIG9wZW5JbkRlZmF1bHRCcm93c2VyKTsgXG59XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIC4uL0V4dGVuc2lvbkNvbnRlbnQvc3JjL2xpbmtzLmpzIiwiaW1wb3J0IHNvY2tldCBmcm9tIFwiLi9zb2NrZXRcIjtcbmltcG9ydCBsb2dnZXIgZnJvbSBcIi4vbG9nZ2VyXCI7XG5pbXBvcnQgKiBhcyB1dGlsIGZyb20gXCIuL3V0aWxcIjtcbmltcG9ydCAqIGFzIGRpc3BhdGNoZXIgZnJvbSBcIi4vZGlzcGF0Y2hlclwiO1xuXG4vLyBzdHVwaWQgc3R1cGlkIGhhY2sgdG8gZm9yY2UgcmVwYWludCA6KFxuZG9jdW1lbnQuYm9keS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG5kb2N1bWVudC5ib2R5Lm9mZnNldEhlaWdodDtcbmRvY3VtZW50LmJvZHkuc3R5bGUuZGlzcGxheSA9IFwiXCI7XG5cbnZhciBwcm9qZWN0c0RpdiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicHJvamVjdHNcIiksXG4gICAgaW1wb3J0VG9Qcm9qZWN0QnV0dG9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJpbXBvcnRUb1Byb2plY3RcIiksXG4gICAgc2VsZWN0UHJvamVjdERpdiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwic2VsZWN0UHJvamVjdFwiKSxcbiAgICBjYW5jZWxQcm9qZWN0U2VsZWN0aW9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjYW5jZWxQcm9qZWN0U2VsZWN0aW9uXCIpLFxuICAgIG9yZ2FuaXphdGlvbkRyb3Bkb3duID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJvcmdhbml6YXRpb25Ecm9wZG93blwiKSxcbiAgICBwcm9qZWN0VGVtcGxhdGUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInByb2plY3RUZW1wbGF0ZVwiKSxcbiAgICBvcmdhbml6YXRpb25zRGl2ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJvcmdhbml6YXRpb25zXCIpLFxuICAgIHNlbGVjdGVkT3JnYW5pemF0aW9uVGV4dEluRHJvcGRvd24gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInNlbGVjdGVkT3JnYW5pemF0aW9uXCIpLFxuICAgIG9yZ2FuaXphdGlvblRlbXBsYXRlID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJvcmdhbml6YXRpb25UZW1wbGF0ZVwiKSxcbiAgICBhbmRyb2lkID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJhbmRyb2lkXCIpLFxuICAgIHVwZGF0ZVNjcmVlbnMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInVwZGF0ZVNjcmVlbnNcIiksXG5cdHNraXBDaGVja2JveCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2lucHV0W3R5cGU9XCJjaGVja2JveFwiXScpLFxuICAgIGV4cG9ydFNlbGVjdGVkQXJ0Ym9hcmRzID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJleHBvcnRTZWxlY3RlZEFydGJvYXJkc1wiKSxcblx0cHJlZGljdGVkRGVuc2l0eSA9IHt9O1xuXG52YXIgZW1vamlSZWdleCA9IC8oPzowXFx1MjBFM3wxXFx1MjBFM3wyXFx1MjBFM3wzXFx1MjBFM3w0XFx1MjBFM3w1XFx1MjBFM3w2XFx1MjBFM3w3XFx1MjBFM3w4XFx1MjBFM3w5XFx1MjBFM3wjXFx1MjBFM3xcXCpcXHUyMEUzfFxcdUQ4M0MoPzpcXHVEREU2XFx1RDgzQyg/OlxcdURERTh8XFx1RERFOXxcXHVEREVBfFxcdURERUJ8XFx1RERFQ3xcXHVEREVFfFxcdURERjF8XFx1RERGMnxcXHVEREY0fFxcdURERjZ8XFx1RERGN3xcXHVEREY4fFxcdURERjl8XFx1RERGQXxcXHVEREZDfFxcdURERkR8XFx1RERGRil8XFx1RERFN1xcdUQ4M0MoPzpcXHVEREU2fFxcdURERTd8XFx1RERFOXxcXHVEREVBfFxcdURERUJ8XFx1RERFQ3xcXHVEREVEfFxcdURERUV8XFx1RERFRnxcXHVEREYxfFxcdURERjJ8XFx1RERGM3xcXHVEREY0fFxcdURERjZ8XFx1RERGN3xcXHVEREY4fFxcdURERjl8XFx1RERGQnxcXHVEREZDfFxcdURERkV8XFx1RERGRil8XFx1RERFOFxcdUQ4M0MoPzpcXHVEREU2fFxcdURERTh8XFx1RERFOXxcXHVEREVCfFxcdURERUN8XFx1RERFRHxcXHVEREVFfFxcdURERjB8XFx1RERGMXxcXHVEREYyfFxcdURERjN8XFx1RERGNHxcXHVEREY1fFxcdURERjd8XFx1RERGQXxcXHVEREZCfFxcdURERkN8XFx1RERGRHxcXHVEREZFfFxcdURERkYpfFxcdURERTlcXHVEODNDKD86XFx1RERFQXxcXHVEREVDfFxcdURERUZ8XFx1RERGMHxcXHVEREYyfFxcdURERjR8XFx1RERGRil8XFx1RERFQVxcdUQ4M0MoPzpcXHVEREU2fFxcdURERTh8XFx1RERFQXxcXHVEREVDfFxcdURERUR8XFx1RERGN3xcXHVEREY4fFxcdURERjl8XFx1RERGQSl8XFx1RERFQlxcdUQ4M0MoPzpcXHVEREVFfFxcdURERUZ8XFx1RERGMHxcXHVEREYyfFxcdURERjR8XFx1RERGNyl8XFx1RERFQ1xcdUQ4M0MoPzpcXHVEREU2fFxcdURERTd8XFx1RERFOXxcXHVEREVBfFxcdURERUJ8XFx1RERFQ3xcXHVEREVEfFxcdURERUV8XFx1RERGMXxcXHVEREYyfFxcdURERjN8XFx1RERGNXxcXHVEREY2fFxcdURERjd8XFx1RERGOHxcXHVEREY5fFxcdURERkF8XFx1RERGQ3xcXHVEREZFKXxcXHVEREVEXFx1RDgzQyg/OlxcdURERjB8XFx1RERGMnxcXHVEREYzfFxcdURERjd8XFx1RERGOXxcXHVEREZBKXxcXHVEREVFXFx1RDgzQyg/OlxcdURERTh8XFx1RERFOXxcXHVEREVBfFxcdURERjF8XFx1RERGMnxcXHVEREYzfFxcdURERjR8XFx1RERGNnxcXHVEREY3fFxcdURERjh8XFx1RERGOSl8XFx1RERFRlxcdUQ4M0MoPzpcXHVEREVBfFxcdURERjJ8XFx1RERGNHxcXHVEREY1KXxcXHVEREYwXFx1RDgzQyg/OlxcdURERUF8XFx1RERFQ3xcXHVEREVEfFxcdURERUV8XFx1RERGMnxcXHVEREYzfFxcdURERjV8XFx1RERGN3xcXHVEREZDfFxcdURERkV8XFx1RERGRil8XFx1RERGMVxcdUQ4M0MoPzpcXHVEREU2fFxcdURERTd8XFx1RERFOHxcXHVEREVFfFxcdURERjB8XFx1RERGN3xcXHVEREY4fFxcdURERjl8XFx1RERGQXxcXHVEREZCfFxcdURERkUpfFxcdURERjJcXHVEODNDKD86XFx1RERFNnxcXHVEREU4fFxcdURERTl8XFx1RERFQXxcXHVEREVCfFxcdURERUN8XFx1RERFRHxcXHVEREYwfFxcdURERjF8XFx1RERGMnxcXHVEREYzfFxcdURERjR8XFx1RERGNXxcXHVEREY2fFxcdURERjd8XFx1RERGOHxcXHVEREY5fFxcdURERkF8XFx1RERGQnxcXHVEREZDfFxcdURERkR8XFx1RERGRXxcXHVEREZGKXxcXHVEREYzXFx1RDgzQyg/OlxcdURERTZ8XFx1RERFOHxcXHVEREVBfFxcdURERUJ8XFx1RERFQ3xcXHVEREVFfFxcdURERjF8XFx1RERGNHxcXHVEREY1fFxcdURERjd8XFx1RERGQXxcXHVEREZGKXxcXHVEREY0XFx1RDgzQ1xcdURERjJ8XFx1RERGNVxcdUQ4M0MoPzpcXHVEREU2fFxcdURERUF8XFx1RERFQnxcXHVEREVDfFxcdURERUR8XFx1RERGMHxcXHVEREYxfFxcdURERjJ8XFx1RERGM3xcXHVEREY3fFxcdURERjh8XFx1RERGOXxcXHVEREZDfFxcdURERkUpfFxcdURERjZcXHVEODNDXFx1RERFNnxcXHVEREY3XFx1RDgzQyg/OlxcdURERUF8XFx1RERGNHxcXHVEREY4fFxcdURERkF8XFx1RERGQyl8XFx1RERGOFxcdUQ4M0MoPzpcXHVEREU2fFxcdURERTd8XFx1RERFOHxcXHVEREU5fFxcdURERUF8XFx1RERFQ3xcXHVEREVEfFxcdURERUV8XFx1RERFRnxcXHVEREYwfFxcdURERjF8XFx1RERGMnxcXHVEREYzfFxcdURERjR8XFx1RERGN3xcXHVEREY4fFxcdURERjl8XFx1RERGQnxcXHVEREZEfFxcdURERkV8XFx1RERGRil8XFx1RERGOVxcdUQ4M0MoPzpcXHVEREU2fFxcdURERTh8XFx1RERFOXxcXHVEREVCfFxcdURERUN8XFx1RERFRHxcXHVEREVGfFxcdURERjB8XFx1RERGMXxcXHVEREYyfFxcdURERjN8XFx1RERGNHxcXHVEREY3fFxcdURERjl8XFx1RERGQnxcXHVEREZDfFxcdURERkYpfFxcdURERkFcXHVEODNDKD86XFx1RERFNnxcXHVEREVDfFxcdURERjJ8XFx1RERGOHxcXHVEREZFfFxcdURERkYpfFxcdURERkJcXHVEODNDKD86XFx1RERFNnxcXHVEREU4fFxcdURERUF8XFx1RERFQ3xcXHVEREVFfFxcdURERjN8XFx1RERGQSl8XFx1RERGQ1xcdUQ4M0MoPzpcXHVEREVCfFxcdURERjgpfFxcdURERkRcXHVEODNDXFx1RERGMHxcXHVEREZFXFx1RDgzQyg/OlxcdURERUF8XFx1RERGOSl8XFx1RERGRlxcdUQ4M0MoPzpcXHVEREU2fFxcdURERjJ8XFx1RERGQykpKXxbXFx4QTlcXHhBRVxcdTIwM0NcXHUyMDQ5XFx1MjEyMlxcdTIxMzlcXHUyMTk0LVxcdTIxOTlcXHUyMUE5XFx1MjFBQVxcdTIzMUFcXHUyMzFCXFx1MjMyOFxcdTIzQ0ZcXHUyM0U5LVxcdTIzRjNcXHUyM0Y4LVxcdTIzRkFcXHUyNEMyXFx1MjVBQVxcdTI1QUJcXHUyNUI2XFx1MjVDMFxcdTI1RkItXFx1MjVGRVxcdTI2MDAtXFx1MjYwNFxcdTI2MEVcXHUyNjExXFx1MjYxNFxcdTI2MTVcXHUyNjE4XFx1MjYxRFxcdTI2MjBcXHUyNjIyXFx1MjYyM1xcdTI2MjZcXHUyNjJBXFx1MjYyRVxcdTI2MkZcXHUyNjM4LVxcdTI2M0FcXHUyNjQ4LVxcdTI2NTNcXHUyNjYwXFx1MjY2M1xcdTI2NjVcXHUyNjY2XFx1MjY2OFxcdTI2N0JcXHUyNjdGXFx1MjY5Mi1cXHUyNjk0XFx1MjY5NlxcdTI2OTdcXHUyNjk5XFx1MjY5QlxcdTI2OUNcXHUyNkEwXFx1MjZBMVxcdTI2QUFcXHUyNkFCXFx1MjZCMFxcdTI2QjFcXHUyNkJEXFx1MjZCRVxcdTI2QzRcXHUyNkM1XFx1MjZDOFxcdTI2Q0VcXHUyNkNGXFx1MjZEMVxcdTI2RDNcXHUyNkQ0XFx1MjZFOVxcdTI2RUFcXHUyNkYwLVxcdTI2RjVcXHUyNkY3LVxcdTI2RkFcXHUyNkZEXFx1MjcwMlxcdTI3MDVcXHUyNzA4LVxcdTI3MERcXHUyNzBGXFx1MjcxMlxcdTI3MTRcXHUyNzE2XFx1MjcxRFxcdTI3MjFcXHUyNzI4XFx1MjczM1xcdTI3MzRcXHUyNzQ0XFx1Mjc0N1xcdTI3NENcXHUyNzRFXFx1Mjc1My1cXHUyNzU1XFx1Mjc1N1xcdTI3NjNcXHUyNzY0XFx1Mjc5NS1cXHUyNzk3XFx1MjdBMVxcdTI3QjBcXHUyN0JGXFx1MjkzNFxcdTI5MzVcXHUyQjA1LVxcdTJCMDdcXHUyQjFCXFx1MkIxQ1xcdTJCNTBcXHUyQjU1XFx1MzAzMFxcdTMwM0RcXHUzMjk3XFx1MzI5OV18XFx1RDgzQ1tcXHVEQzA0XFx1RENDRlxcdURENzBcXHVERDcxXFx1REQ3RVxcdUREN0ZcXHVERDhFXFx1REQ5MS1cXHVERDlBXFx1REUwMVxcdURFMDJcXHVERTFBXFx1REUyRlxcdURFMzItXFx1REUzQVxcdURFNTBcXHVERTUxXFx1REYwMC1cXHVERjIxXFx1REYyNC1cXHVERjkzXFx1REY5NlxcdURGOTdcXHVERjk5LVxcdURGOUJcXHVERjlFLVxcdURGRjBcXHVERkYzLVxcdURGRjVcXHVERkY3LVxcdURGRkZdfFxcdUQ4M0RbXFx1REMwMC1cXHVEQ0ZEXFx1RENGRi1cXHVERDNEXFx1REQ0OS1cXHVERDRFXFx1REQ1MC1cXHVERDY3XFx1REQ2RlxcdURENzBcXHVERDczLVxcdURENzlcXHVERDg3XFx1REQ4QS1cXHVERDhEXFx1REQ5MFxcdUREOTVcXHVERDk2XFx1RERBNVxcdUREQThcXHVEREIxXFx1RERCMlxcdUREQkNcXHVEREMyLVxcdUREQzRcXHVEREQxLVxcdURERDNcXHVERERDLVxcdUREREVcXHVEREUxXFx1RERFM1xcdURERUZcXHVEREYzXFx1RERGQS1cXHVERTRGXFx1REU4MC1cXHVERUM1XFx1REVDQi1cXHVERUQwXFx1REVFMC1cXHVERUU1XFx1REVFOVxcdURFRUJcXHVERUVDXFx1REVGMFxcdURFRjNdfFxcdUQ4M0VbXFx1REQxMC1cXHVERDE4XFx1REQ4MC1cXHVERDg0XFx1RERDMF0vZztcbmZ1bmN0aW9uIGhhbmRsZVByb2plY3RzKHByb2plY3RzKSB7XG4gICAgZG9jdW1lbnQuYm9keS5jbGFzc05hbWUgPSBcInByb2plY3RTZWxlY3Rpb25cIjtcbiAgICBwcm9qZWN0c0Rpdi5pbm5lckhUTUwgPSBcIlwiO1xuICAgIGltcG9ydFRvUHJvamVjdEJ1dHRvbi5kaXNhYmxlZCA9IHRydWU7XG4gICAgXG4gICAgaWYgKHNlbGVjdFByb2plY3REaXYuY2xhc3NMaXN0LmNvbnRhaW5zKFwiZGVzaWduZXJXaXRoT3JnYW5pemF0aW9uXCIpKSB7XG4gICAgICAgIHNlbGVjdFByb2plY3REaXYuY2xhc3NMaXN0LnJlbW92ZShcImdldHRpbmdPcmdhbml6YXRpb25Qcm9qZWN0c1wiKTtcbiAgICAgICAgY2FuY2VsUHJvamVjdFNlbGVjdGlvbi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgICBvcmdhbml6YXRpb25Ecm9wZG93bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgIH1cbiAgICBcbiAgICB2YXIgbGFzdFNlbGVjdGVkUHJvamVjdCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwibGFzdFNlbGVjdGVkUHJvamVjdFwiKTtcblxuICAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QudG9nZ2xlKFwibm9Qcm9qZWN0c1wiLCAhcHJvamVjdHMubGVuZ3RoKTtcblxuICAgIHZhciBwcm9qZWN0VG9TZWxlY3QgPSBwcm9qZWN0cy5yZWR1Y2UoZnVuY3Rpb24gKHByZXYsIHByb2plY3QsIGluZGV4KSB7XG4gICAgICAgIHZhciBuZXdQcm9qZWN0ID0gZG9jdW1lbnQuaW1wb3J0Tm9kZShwcm9qZWN0VGVtcGxhdGUuY29udGVudCwgdHJ1ZSk7XG5cbiAgICAgICAgbmV3UHJvamVjdC5xdWVyeVNlbGVjdG9yKFwiLnByb2plY3ROYW1lXCIpLnRleHRDb250ZW50ID0gcHJvamVjdC5uYW1lLnJlcGxhY2UoZW1vamlSZWdleCwgJycpLnRyaW0oKTtcblxuICAgICAgICBuZXdQcm9qZWN0LnF1ZXJ5U2VsZWN0b3IoXCIucHJvamVjdFwiKS5kYXRhc2V0LnR5cGUgPSBwcm9qZWN0LnR5cGU7XG4gICAgICAgIFxuICAgICAgICBuZXdQcm9qZWN0LnF1ZXJ5U2VsZWN0b3IoXCIucHJvamVjdFwiKS5kYXRhc2V0LnBpZCA9IHByb2plY3QucGlkO1xuICAgICAgICBuZXdQcm9qZWN0LnF1ZXJ5U2VsZWN0b3IoXCIucHJvamVjdFwiKS5kYXRhc2V0LmRlbnNpdHkgPSBwcm9qZWN0LmRlbnNpdHk7XG4gICAgICAgIFxuICAgICAgICBuZXdQcm9qZWN0LnF1ZXJ5U2VsZWN0b3IoXCIucHJvamVjdEljb25cIikuZGF0YXNldC50eXBlID0gcHJvamVjdC5pY29uLnR5cGU7XG4gICAgICAgIFxuICAgICAgICBuZXdQcm9qZWN0LnF1ZXJ5U2VsZWN0b3IoXCIucHJvamVjdFwiKS5kYXRhc2V0LmluZGV4ID0gaW5kZXg7XG5cbiAgICAgICAgcHJvamVjdHNEaXYuYXBwZW5kQ2hpbGQobmV3UHJvamVjdCk7XG4gICAgICAgIGlmIChwcmV2ICE9PSAtMSkge1xuICAgICAgICAgICAgcmV0dXJuIHByZXY7XG4gICAgICAgIH0gZWxzZSBpZiAobGFzdFNlbGVjdGVkUHJvamVjdCAmJiBsYXN0U2VsZWN0ZWRQcm9qZWN0ID09PSBwcm9qZWN0LnBpZCkge1xuICAgICAgICAgICAgcmV0dXJuIGluZGV4O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIHByZXY7XG4gICAgICAgIH1cbiAgICB9LCAtMSk7XG5cbiAgICBzZWxlY3RlZFByb2plY3RJbmRleCA9IHVuZGVmaW5lZDtcbiAgICBpZiAocHJvamVjdFRvU2VsZWN0ICE9PSAtMSkge1xuICAgICAgICBzZWxlY3RQcm9qZWN0KHByb2plY3RUb1NlbGVjdCk7XG4gICAgfVxufVxuXG52YXIgc2VsZWN0ZWRQcm9qZWN0SW5kZXg7XG5mdW5jdGlvbiBzZWxlY3RQcm9qZWN0KGluZGV4KSB7XG5cdHZhciBzZWxlY3RlZFByb2plY3Q7XG5cdGlmIChzZWxlY3RlZFByb2plY3RJbmRleCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0c2VsZWN0ZWRQcm9qZWN0ID0gcHJvamVjdHNEaXYucXVlcnlTZWxlY3RvcignLnByb2plY3RbZGF0YS1pbmRleD1cIicgKyBzZWxlY3RlZFByb2plY3RJbmRleCArICdcIl0nKTtcblx0XHRzZWxlY3RlZFByb2plY3QuY2xhc3NMaXN0LnJlbW92ZShcInNlbGVjdGVkXCIpO1xuXHR9XG5cblx0c2VsZWN0ZWRQcm9qZWN0SW5kZXggPSBwYXJzZUludChpbmRleCwgMTApO1xuXHRzZWxlY3RlZFByb2plY3QgPSBwcm9qZWN0c0Rpdi5xdWVyeVNlbGVjdG9yKCcucHJvamVjdFtkYXRhLWluZGV4PVwiJyArIHNlbGVjdGVkUHJvamVjdEluZGV4ICsgJ1wiXScpO1xuXHRzZWxlY3RlZFByb2plY3QuY2xhc3NMaXN0LmFkZChcInNlbGVjdGVkXCIpO1xuXHRcblx0dmFyIGNvbnRhaW5lciA9IHNlbGVjdFByb2plY3REaXYuY2xhc3NMaXN0LmNvbnRhaW5zKFwiZGVzaWduZXJXaXRoT3JnYW5pemF0aW9uXCIpID8gc2VsZWN0UHJvamVjdENvbnRlbnQgOiBwcm9qZWN0c0RpdjsgXG5cdHV0aWwuc2Nyb2xsSWZOZWNlc3Nhcnkoc2VsZWN0ZWRQcm9qZWN0LCBjb250YWluZXIpO1xuXG5cdGltcG9ydFRvUHJvamVjdEJ1dHRvbi5kaXNhYmxlZCA9IGZhbHNlO1xuXHRsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImxhc3RTZWxlY3RlZFByb2plY3RcIiwgc2VsZWN0ZWRQcm9qZWN0LmRhdGFzZXQucGlkKTtcbn1cblxuc29ja2V0Lm9uKFwicHJvamVjdHNWMlwiLCBmdW5jdGlvbiAocHJvamVjdHNEYXRhKSB7XG4gICAgdmFyIHByb2plY3RzID0gSlNPTi5wYXJzZShwcm9qZWN0c0RhdGEpO1xuICAgIGhhbmRsZVByb2plY3RzKHByb2plY3RzKTtcbn0pO1xuXG5zb2NrZXQub24oXCJwcm9qZWN0c1dpdGhPcmdhbml6YXRpb25zXCIsIGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgdmFyIGRhdGFKU09OID0gSlNPTi5wYXJzZShkYXRhKTtcbiAgICBcbiAgICB2YXIgcHJvamVjdHMgPSBkYXRhSlNPTi5wcm9qZWN0cztcbiAgICB2YXIgb3JnYW5pemF0aW9ucyA9IGRhdGFKU09OLm9yZ2FuaXphdGlvbnM7XG4gICAgdmFyIHByb2ZpbGVzID0gZGF0YUpTT04ucHJvZmlsZXM7XG4gICAgdmFyIG9pZCA9IGRhdGFKU09OLm9pZDtcblxuICAgIHByZWRpY3RlZERlbnNpdHkgPSBkYXRhSlNPTi5wcmVkaWN0ZWREZW5zaXR5IHx8IHt9O1xuICAgIFxuICAgIHZhciB1c2VyQ2FudFVwbG9hZERlc2lnbnMgPSBmYWxzZTtcblxuICAgIGlmIChvcmdhbml6YXRpb25zICYmIG9yZ2FuaXphdGlvbnMubGVuZ3RoID4gMCkge1xuICAgICAgICBvcmdhbml6YXRpb25zRGl2LmlubmVySFRNTCA9IFwiXCI7XG4gICAgICAgIHNlbGVjdGVkT3JnYW5pemF0aW9uVGV4dEluRHJvcGRvd24uY2xhc3NMaXN0LnJlbW92ZShcIm5vblBlcnNvbmFsXCIpO1xuICAgICAgICBzZWxlY3RQcm9qZWN0RGl2LmNsYXNzTGlzdC5yZW1vdmUoXCJsaXN0aW5nT3JnYW5pemF0aW9uUHJvamVjdHNcIik7XG4gICAgICAgIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnJlbW92ZShcInVzZXJDYW50VXBsb2FkRGVzaWduc1wiKTtcbiAgICAgICAgc2VsZWN0ZWRPcmdhbml6YXRpb25UZXh0SW5Ecm9wZG93bi50ZXh0Q29udGVudCA9IFwiUGVyc29uYWwgcHJvamVjdHNcIjtcbiAgICAgICAgXG4gICAgICAgIHZhciBuZXdPcmdhbml6YXRpb24gPSBkb2N1bWVudC5pbXBvcnROb2RlKG9yZ2FuaXphdGlvblRlbXBsYXRlLmNvbnRlbnQsIHRydWUpO1xuICAgICAgICBcbiAgICAgICAgbmV3T3JnYW5pemF0aW9uLnF1ZXJ5U2VsZWN0b3IoXCIub3JnYW5pemF0aW9uTmFtZVwiKS50ZXh0Q29udGVudCA9IFwiUGVyc29uYWwgcHJvamVjdHNcIjtcbiAgICAgICAgbmV3T3JnYW5pemF0aW9uLnF1ZXJ5U2VsZWN0b3IoXCIub3JnYW5pemF0aW9uXCIpLmNsYXNzTGlzdC5hZGQoXCJzZWxlY3RlZFwiKTtcbiAgICAgICAgbmV3T3JnYW5pemF0aW9uLnF1ZXJ5U2VsZWN0b3IoXCIub3JnYW5pemF0aW9uXCIpLmRhdGFzZXQub2lkID0gXCJ1c2VyXCI7XG4gICAgICAgIFxuICAgICAgICBvcmdhbml6YXRpb25zRGl2LmFwcGVuZENoaWxkKG5ld09yZ2FuaXphdGlvbik7XG4gICAgICAgIFxuICAgICAgICBvcmdhbml6YXRpb25zLmZvckVhY2goZnVuY3Rpb24gKG9yZ2FuaXphdGlvbikge1xuICAgICAgICAgICAgdmFyIG5ld09yZ2FuaXphdGlvbiA9IGRvY3VtZW50LmltcG9ydE5vZGUob3JnYW5pemF0aW9uVGVtcGxhdGUuY29udGVudCwgdHJ1ZSk7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIG5ld09yZ2FuaXphdGlvbi5xdWVyeVNlbGVjdG9yKFwiLm9yZ2FuaXphdGlvbk5hbWVcIikudGV4dENvbnRlbnQgPSBvcmdhbml6YXRpb24ubmFtZS5yZXBsYWNlKGVtb2ppUmVnZXgsICcnKS50cmltKCk7XG4gICAgICAgICAgICBuZXdPcmdhbml6YXRpb24ucXVlcnlTZWxlY3RvcihcIi5vcmdhbml6YXRpb25cIikuZGF0YXNldC5vaWQgPSBvcmdhbml6YXRpb24ub2lkO1xuICAgICAgICAgICAgaWYgKHByb2ZpbGVzW29yZ2FuaXphdGlvbi5vaWRdKSB7XG4gICAgICAgICAgICAgICAgbmV3T3JnYW5pemF0aW9uLnF1ZXJ5U2VsZWN0b3IoXCIub3JnYW5pemF0aW9uXCIpLmRhdGFzZXQudXNlclJvbGUgPSBwcm9maWxlc1tvcmdhbml6YXRpb24ub2lkXTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgb3JnYW5pemF0aW9uc0Rpdi5hcHBlbmRDaGlsZChuZXdPcmdhbml6YXRpb24pO1xuICAgICAgICB9KTtcblxuICAgICAgICBpZiAob2lkKSB7XG4gICAgICAgICAgICBvcmdhbml6YXRpb25zRGl2LnF1ZXJ5U2VsZWN0b3IoXCIuc2VsZWN0ZWRcIikuY2xhc3NMaXN0LnJlbW92ZShcInNlbGVjdGVkXCIpO1xuXG4gICAgICAgICAgICB2YXIgb3JnYW5pemF0aW9uRWwgPSBvcmdhbml6YXRpb25zRGl2LnF1ZXJ5U2VsZWN0b3IoJy5vcmdhbml6YXRpb25bZGF0YS1vaWQ9XCInICsgb2lkICsgJ1wiXScpO1xuICAgICAgICAgICAgb3JnYW5pemF0aW9uRWwuY2xhc3NMaXN0LmFkZChcInNlbGVjdGVkXCIpO1xuXG4gICAgICAgICAgICBzZWxlY3RlZE9yZ2FuaXphdGlvblRleHRJbkRyb3Bkb3duLnRleHRDb250ZW50ID0gb3JnYW5pemF0aW9uRWwucXVlcnlTZWxlY3RvcihcIi5vcmdhbml6YXRpb25OYW1lXCIpLnRleHRDb250ZW50O1xuICAgICAgICAgICAgc2VsZWN0ZWRPcmdhbml6YXRpb25UZXh0SW5Ecm9wZG93bi5jbGFzc0xpc3QuYWRkKFwibm9uUGVyc29uYWxcIik7XG4gICAgICAgICAgICBzZWxlY3RQcm9qZWN0RGl2LmNsYXNzTGlzdC5hZGQoXCJsaXN0aW5nT3JnYW5pemF0aW9uUHJvamVjdHNcIik7XG5cbiAgICAgICAgICAgIHVzZXJDYW50VXBsb2FkRGVzaWducyA9IG9yZ2FuaXphdGlvbkVsLmRhdGFzZXQub2lkICE9PSBcInVzZXJcIiAmJiBvcmdhbml6YXRpb25FbC5kYXRhc2V0LnVzZXJSb2xlID09PSBcImtuaWdodFwiO1xuICAgICAgICAgICAgZG9jdW1lbnQuYm9keS5jbGFzc05hbWUgPSBcInByb2plY3RTZWxlY3Rpb25cIjtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnRvZ2dsZShcInVzZXJDYW50VXBsb2FkRGVzaWduc1wiLCB1c2VyQ2FudFVwbG9hZERlc2lnbnMpO1xuICAgICAgICAgICAgaW1wb3J0VG9Qcm9qZWN0QnV0dG9uLmRpc2FibGVkID0gdHJ1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIHNlbGVjdFByb2plY3REaXYuY2xhc3NMaXN0LmFkZChcImRlc2lnbmVyV2l0aE9yZ2FuaXphdGlvblwiKTtcbiAgICB9XG5cdFx0XG4gICAgaWYgKCF1c2VyQ2FudFVwbG9hZERlc2lnbnMpIHtcbiAgICAgICAgaGFuZGxlUHJvamVjdHMocHJvamVjdHMpO1xuICAgIH1cbn0pO1xuXG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24gKCkge1xuXHRvcmdhbml6YXRpb25zRGl2LmNsYXNzTGlzdC5hZGQoXCJoaWRkZW5cIik7XG59KTtcblxub3JnYW5pemF0aW9uRHJvcGRvd24uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uIChldikge1xuXHRldi5zdG9wUHJvcGFnYXRpb24oKTtcblx0b3JnYW5pemF0aW9uc0Rpdi5jbGFzc0xpc3QudG9nZ2xlKFwiaGlkZGVuXCIpO1xufSk7XG5cbmZ1bmN0aW9uIGdldE9yZ2FuaXphdGlvblByb2plY3RzKG9yZ2FuaXphdGlvbkVsKSB7XG5cdGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFzdFNlbGVjdGVkT3JnYW5pemF0aW9uXCIsIG9yZ2FuaXphdGlvbkVsLmRhdGFzZXQub2lkKTtcblx0dmFyIG9pZDtcblx0aWYgKG9yZ2FuaXphdGlvbkVsLmRhdGFzZXQub2lkICE9PSBcInVzZXJcIikge1xuXHRcdG9pZCA9IG9yZ2FuaXphdGlvbkVsLmRhdGFzZXQub2lkO1xuXHR9XG5cdHNvY2tldC5lbWl0KFwiZ2V0UHJvamVjdHNcIiwgb2lkKTtcblx0c2VsZWN0UHJvamVjdERpdi5jbGFzc0xpc3QuYWRkKFwiZ2V0dGluZ09yZ2FuaXphdGlvblByb2plY3RzXCIpO1xuXHRvcmdhbml6YXRpb25Ecm9wZG93bi5kaXNhYmxlZCA9IHRydWU7XG5cdGltcG9ydFRvUHJvamVjdEJ1dHRvbi5kaXNhYmxlZCA9IHRydWU7XG5cdGNhbmNlbFByb2plY3RTZWxlY3Rpb24uZGlzYWJsZWQgPSB0cnVlO1xufVxuXG5vcmdhbml6YXRpb25zRGl2LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbiAoZXYpIHtcblx0dmFyIG9yZ2FuaXphdGlvbiA9IGV2LnRhcmdldDtcblxuXHR3aGlsZSAob3JnYW5pemF0aW9uICYmICFvcmdhbml6YXRpb24uY2xhc3NMaXN0LmNvbnRhaW5zKFwib3JnYW5pemF0aW9uXCIpKSB7XG5cdFx0b3JnYW5pemF0aW9uID0gb3JnYW5pemF0aW9uLnBhcmVudEVsZW1lbnQ7XG5cdH1cblxuXHRpZiAoIW9yZ2FuaXphdGlvbikge1xuXHRcdHJldHVybjtcblx0fVxuXG5cdGV2LnN0b3BQcm9wYWdhdGlvbigpO1xuXG5cdHZhciBwcmV2U2VsZWN0ZWRPcmdhbml6YXRpb24gPSBvcmdhbml6YXRpb25zRGl2LnF1ZXJ5U2VsZWN0b3IoXCIuc2VsZWN0ZWRcIik7XG5cdGlmIChwcmV2U2VsZWN0ZWRPcmdhbml6YXRpb24pIHtcblx0XHRwcmV2U2VsZWN0ZWRPcmdhbml6YXRpb24uY2xhc3NMaXN0LnJlbW92ZShcInNlbGVjdGVkXCIpO1xuXHR9XG5cdG9yZ2FuaXphdGlvbi5jbGFzc0xpc3QuYWRkKFwic2VsZWN0ZWRcIik7XG5cblx0c2VsZWN0ZWRPcmdhbml6YXRpb25UZXh0SW5Ecm9wZG93bi50ZXh0Q29udGVudCA9IG9yZ2FuaXphdGlvbi5xdWVyeVNlbGVjdG9yKFwiLm9yZ2FuaXphdGlvbk5hbWVcIikudGV4dENvbnRlbnQ7XG5cdHNlbGVjdGVkT3JnYW5pemF0aW9uVGV4dEluRHJvcGRvd24uY2xhc3NMaXN0LnRvZ2dsZShcIm5vblBlcnNvbmFsXCIsIG9yZ2FuaXphdGlvbi5kYXRhc2V0Lm9pZCAhPT0gXCJ1c2VyXCIpO1xuXHRzZWxlY3RQcm9qZWN0RGl2LmNsYXNzTGlzdC50b2dnbGUoXCJsaXN0aW5nT3JnYW5pemF0aW9uUHJvamVjdHNcIiwgb3JnYW5pemF0aW9uLmRhdGFzZXQub2lkICE9PSBcInVzZXJcIik7XG5cblx0b3JnYW5pemF0aW9uc0Rpdi5jbGFzc0xpc3QuYWRkKFwiaGlkZGVuXCIpO1xuXG5cdHZhciB1c2VyQ2FudFVwbG9hZERlc2lnbnMgPSBvcmdhbml6YXRpb24uZGF0YXNldC5vaWQgIT09IFwidXNlclwiICYmIG9yZ2FuaXphdGlvbi5kYXRhc2V0LnVzZXJSb2xlID09PSBcImtuaWdodFwiO1xuXHRkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC50b2dnbGUoXCJ1c2VyQ2FudFVwbG9hZERlc2lnbnNcIiwgdXNlckNhbnRVcGxvYWREZXNpZ25zKTtcblx0ZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QucmVtb3ZlKFwibm9Qcm9qZWN0c1wiKTtcblx0aW1wb3J0VG9Qcm9qZWN0QnV0dG9uLmRpc2FibGVkID0gdHJ1ZTtcblx0aWYgKCF1c2VyQ2FudFVwbG9hZERlc2lnbnMpIHtcblx0XHRnZXRPcmdhbml6YXRpb25Qcm9qZWN0cyhvcmdhbml6YXRpb24pO1xuXHR9XG59KTtcblxuZGlzcGF0Y2hlci5hZGRFdmVudExpc3RlbmVyKFwiZ2V0T3JnYW5pemF0aW9uUHJvamVjdHNcIiwgZnVuY3Rpb24gKGV2ZW50KSB7XG5cdHNlbGVjdFByb2plY3REaXYuY2xhc3NOYW1lID0gXCJkZXNpZ25lcldpdGhPcmdhbml6YXRpb25cIjtcbiAgICBnZXRPcmdhbml6YXRpb25Qcm9qZWN0cyhldmVudC5kZXRhaWwpO1xufSk7XG5cbnByb2plY3RzRGl2LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbiAoZXYpIHtcblx0dmFyIHByb2plY3QgPSBldi50YXJnZXQ7XG5cblx0d2hpbGUgKHByb2plY3QgJiYgIXByb2plY3QuY2xhc3NMaXN0LmNvbnRhaW5zKFwicHJvamVjdFwiKSkge1xuXHRcdHByb2plY3QgPSBwcm9qZWN0LnBhcmVudEVsZW1lbnQ7XG5cdH1cblxuXHRpZiAoIXByb2plY3QpIHtcblx0XHRyZXR1cm47XG5cdH1cblxuXHRzZWxlY3RQcm9qZWN0KHByb2plY3QuZGF0YXNldC5pbmRleCk7XG59KTtcblxuZnVuY3Rpb24gaW1wb3J0VG9Qcm9qZWN0KHByb2plY3QpIHtcblx0bG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJsYXN0U2VsZWN0ZWRQcm9qZWN0XCIsIHByb2plY3QuZGF0YXNldC5waWQpO1xuXG5cdHZhciBzZWxlY3RlZE9yZ2FuaXphdGlvbiA9IG9yZ2FuaXphdGlvbnNEaXYucXVlcnlTZWxlY3RvcihcIi5vcmdhbml6YXRpb24uc2VsZWN0ZWRcIik7XG5cdGlmIChzZWxlY3RlZE9yZ2FuaXphdGlvbikge1xuXHRcdGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwibGFzdFNlbGVjdGVkT3JnYW5pemF0aW9uXCIsIHNlbGVjdGVkT3JnYW5pemF0aW9uLmRhdGFzZXQub2lkKTtcblx0fVxuXG5cdHZhciBkZW5zaXR5VG9DaG9vc2UgPSBwcm9qZWN0LmRhdGFzZXQuZGVuc2l0eTtcblx0aWYgKGRlbnNpdHlUb0Nob29zZSA9PT0gXCJ1bmtub3duXCIpIHtcbiAgICAgICAgaWYgKCFwcmVkaWN0ZWREZW5zaXR5W3Byb2plY3QuZGF0YXNldC50eXBlXSkge1xuICAgICAgICAgICAgZG9jdW1lbnQuYm9keS5jbGFzc05hbWUgPSBcImRlbnNpdHlTZWxlY3Rpb25cIjtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LmFkZChwcm9qZWN0LmRhdGFzZXQudHlwZSk7XG4gICAgICAgICAgICByZXR1cm47XG5cdFx0fVxuICAgICAgICBkZW5zaXR5VG9DaG9vc2UgPSBwcmVkaWN0ZWREZW5zaXR5W3Byb2plY3QuZGF0YXNldC50eXBlXTtcblx0fVxuXG5cdHNvY2tldC5lbWl0KFwiZXhwb3J0XCIsIHtcblx0XHRwaWQ6IHByb2plY3QuZGF0YXNldC5waWQsXG5cdFx0ZGVuc2l0eTogZGVuc2l0eVRvQ2hvb3NlLFxuXHRcdHR5cGU6IHByb2plY3QuZGF0YXNldC50eXBlLFxuXHRcdHJlcGxhY2U6IHVwZGF0ZVNjcmVlbnMuY2hlY2tlZFxuXHR9KTtcblxuXHRleHBvcnRTZWxlY3RlZEFydGJvYXJkcy5kaXNhYmxlZCA9IHRydWU7XG5cdHNraXBDaGVja2JveC5kaXNhYmxlZCA9IHRydWU7XG5cblx0ZG9jdW1lbnQuYm9keS5jbGFzc05hbWUgPSBcInNlbGVjdGlvbkRpc3BsYXlcIjtcblx0ZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QuYWRkKFwiZXhwb3J0aW5nXCIpO1xufVxuXG5wcm9qZWN0c0Rpdi5hZGRFdmVudExpc3RlbmVyKFwiZGJsY2xpY2tcIiwgZnVuY3Rpb24gKGV2KSB7XG5cdHZhciBwcm9qZWN0ID0gZXYudGFyZ2V0O1xuXG5cdHdoaWxlIChwcm9qZWN0ICYmICFwcm9qZWN0LmNsYXNzTGlzdC5jb250YWlucyhcInByb2plY3RcIikpIHtcblx0XHRwcm9qZWN0ID0gcHJvamVjdC5wYXJlbnRFbGVtZW50O1xuXHR9XG5cblx0aWYgKCFwcm9qZWN0KSB7XG5cdFx0cmV0dXJuO1xuXHR9XG5cblx0aW1wb3J0VG9Qcm9qZWN0KHByb2plY3QpO1xufSk7XG5cbmltcG9ydFRvUHJvamVjdEJ1dHRvbi5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24gKGV2KSB7XG5cdHZhciBwcm9qZWN0ID0gcHJvamVjdHNEaXYucXVlcnlTZWxlY3RvcihcIi5wcm9qZWN0LnNlbGVjdGVkXCIpO1xuXG5cdGlmICghcHJvamVjdCkge1xuXHRcdHJldHVybjtcblx0fVxuXG5cdGltcG9ydFRvUHJvamVjdChwcm9qZWN0KTtcbn0pO1xuXG5jYW5jZWxQcm9qZWN0U2VsZWN0aW9uLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbiAoKSB7XG5cdGdvVG9TZWxlY3Rpb25EaXNwbGF5KCk7XG59KTtcblxuZnVuY3Rpb24gZ29Ub1NlbGVjdGlvbkRpc3BsYXkoKSB7XHRcdFxuXHRleHBvcnRTZWxlY3RlZEFydGJvYXJkcy5kaXNhYmxlZCA9IGZhbHNlO1xuXHRza2lwQ2hlY2tib3guZGlzYWJsZWQgPSBmYWxzZTtcblxuXHRkb2N1bWVudC5ib2R5LmNsYXNzTmFtZSA9IFwic2VsZWN0aW9uRGlzcGxheVwiO1xufVxuXG5kaXNwYXRjaGVyLmFkZEV2ZW50TGlzdGVuZXIoXCJnb1RvU2VsZWN0aW9uRGlzcGxheVwiLCBnb1RvU2VsZWN0aW9uRGlzcGxheSk7XG5cbmNhbmNlbERlbnNpdHlTZWxlY3Rpb24uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uICgpIHtcblx0Z29Ub1NlbGVjdGlvbkRpc3BsYXkoKTtcbn0pO1xuXG5jaG9vc2VEZW5zaXR5LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbiAoKSB7XG5cdHZhciBwcm9qZWN0ID0gcHJvamVjdHNEaXYucXVlcnlTZWxlY3RvcihcIi5wcm9qZWN0LnNlbGVjdGVkXCIpO1xuXHR2YXIgcHJvamVjdFR5cGUgPSBwcm9qZWN0LmRhdGFzZXQudHlwZTtcblx0aWYgKHByb2plY3RUeXBlID09PSBcIm9zeFwiKSB7XG5cdFx0cHJvamVjdFR5cGUgPSBcImlvc1wiO1xuXHR9XG5cdHZhciBzZWxlY3RlZERlbnNpdHkgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdpbnB1dFt0eXBlPVwicmFkaW9cIl1bbmFtZT1cIicgKyBwcm9qZWN0VHlwZSArICdEZW5zaXR5XCJdOmNoZWNrZWQnKS52YWx1ZTtcblx0cHJvamVjdC5kYXRhc2V0LmRlbnNpdHkgPSBzZWxlY3RlZERlbnNpdHk7XG5cdGltcG9ydFRvUHJvamVjdChwcm9qZWN0KTtcbn0pO1xuXG5mdW5jdGlvbiByZXBhaW50QW5kcm9pZERlbnNpdGllcygpIHtcblx0dmFyIHNjcm9sbFRvcCA9IGFuZHJvaWQucGFyZW50RWxlbWVudC5zY3JvbGxUb3A7XG5cdGFuZHJvaWQuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuXHRhbmRyb2lkLm9mZnNldEhlaWdodDtcblx0YW5kcm9pZC5zdHlsZS5kaXNwbGF5ID0gXCJcIjtcblx0YW5kcm9pZC5wYXJlbnRFbGVtZW50LnNjcm9sbFRvcCA9IHNjcm9sbFRvcDtcbn1cblxuW10uZm9yRWFjaC5jYWxsKFxuXHRkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdpbnB1dFt0eXBlPVwicmFkaW9cIl1bbmFtZT1cImFuZHJvaWREZW5zaXR5XCJdJyksXG5cdGZ1bmN0aW9uIChwaG9uZVJhZGlvKSB7XG5cdFx0cGhvbmVSYWRpby5hZGRFdmVudExpc3RlbmVyKFwiY2hhbmdlXCIsIGZ1bmN0aW9uIChldikge1xuXHRcdFx0dmFyIHRhYmxldFJhZGlvID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignaW5wdXRbdHlwZT1cInJhZGlvXCJdW25hbWU9XCJ0YWJsZXREZW5zaXR5XCJdW3ZhbHVlPVwiJysgZXYudGFyZ2V0LnZhbHVlICsgJ1wiXScpO1xuXHRcdFx0aWYgKHRhYmxldFJhZGlvKSB7XG5cdFx0XHRcdHRhYmxldFJhZGlvLmNoZWNrZWQgPSB0cnVlO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0dGFibGV0UmFkaW8gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdpbnB1dFt0eXBlPVwicmFkaW9cIl1bbmFtZT1cInRhYmxldERlbnNpdHlcIl06Y2hlY2tlZCcpO1xuXHRcdFx0XHRpZiAodGFibGV0UmFkaW8pIHtcblx0XHRcdFx0XHR0YWJsZXRSYWRpby5jaGVja2VkID0gZmFsc2U7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHJlcGFpbnRBbmRyb2lkRGVuc2l0aWVzKCk7XG5cdFx0fSk7XG5cdH1cbik7XG5cbltdLmZvckVhY2guY2FsbChcblx0ZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnaW5wdXRbdHlwZT1cInJhZGlvXCJdW25hbWU9XCJ0YWJsZXREZW5zaXR5XCJdJyksXG5cdGZ1bmN0aW9uICh0YWJsZXRSYWRpbykge1xuXHRcdHRhYmxldFJhZGlvLmFkZEV2ZW50TGlzdGVuZXIoXCJjaGFuZ2VcIiwgZnVuY3Rpb24gKGV2KSB7XG5cdFx0XHR2YXIgcGhvbmVSYWRpbyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2lucHV0W3R5cGU9XCJyYWRpb1wiXVtuYW1lPVwiYW5kcm9pZERlbnNpdHlcIl1bdmFsdWU9XCInKyBldi50YXJnZXQudmFsdWUgKyAnXCJdJyk7XG5cdFx0XHRpZiAocGhvbmVSYWRpbykge1xuXHRcdFx0XHRwaG9uZVJhZGlvLmNoZWNrZWQgPSB0cnVlO1xuXHRcdFx0fVxuXHRcdFx0cmVwYWludEFuZHJvaWREZW5zaXRpZXMoKTtcblx0XHR9KTtcblx0fVxuKTtcblxudXBkYXRlU2NyZWVucy5jaGVja2VkID0gKGZ1bmN0aW9uICgpIHtcblx0dmFyIHJlcGxhY2VTY3JlZW5zID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJyZXBsYWNlU2NyZWVuc1wiKTtcblx0aWYgKHJlcGxhY2VTY3JlZW5zICYmIHJlcGxhY2VTY3JlZW5zID09PSBcImZhbHNlXCIpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH0gZWxzZSB7XG5cdFx0cmV0dXJuIHRydWU7XG5cdH1cbn0pKCk7XG51cGRhdGVTY3JlZW5zLmFkZEV2ZW50TGlzdGVuZXIoXCJjaGFuZ2VcIiwgZnVuY3Rpb24gKGV2KSB7XG5cdGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwicmVwbGFjZVNjcmVlbnNcIiwgdXBkYXRlU2NyZWVucy5jaGVja2VkKTtcbn0pO1xuXG5cbi8vIFdFQlBBQ0sgRk9PVEVSIC8vXG4vLyAuLi9FeHRlbnNpb25Db250ZW50L3NyYy9wcm9qZWN0cy5qcyIsImltcG9ydCAqIGFzIGRpc3BhdGNoZXIgZnJvbSBcIi4vZGlzcGF0Y2hlclwiO1xuXG5mdW5jdGlvbiBvbkNsaWNrUmV0cnkoZXYpIHtcbiAgICB2YXIgZ2V0dGluZ1Byb2plY3RzRmFpbGVkID0gZXYudGFyZ2V0O1xuXHRcblx0d2hpbGUgKGdldHRpbmdQcm9qZWN0c0ZhaWxlZCAmJiAhZ2V0dGluZ1Byb2plY3RzRmFpbGVkLmNsYXNzTGlzdC5jb250YWlucyhcImdldHRpbmdQcm9qZWN0c0ZhaWxlZFwiKSkge1xuXHRcdGdldHRpbmdQcm9qZWN0c0ZhaWxlZCA9IGdldHRpbmdQcm9qZWN0c0ZhaWxlZC5wYXJlbnRFbGVtZW50O1xuXHR9XG5cdFxuXHRpZiAoIWdldHRpbmdQcm9qZWN0c0ZhaWxlZCkge1xuXHRcdHJldHVybjtcblx0fVxuXHRcblx0dmFyIHNlbGVjdGVkT3JnYW5pemF0aW9uID0gZ2V0dGluZ1Byb2plY3RzRmFpbGVkLnF1ZXJ5U2VsZWN0b3IoXCIub3JnYW5pemF0aW9uLnNlbGVjdGVkXCIpO1xuXHRcblx0aWYgKHNlbGVjdGVkT3JnYW5pemF0aW9uKSB7XG5cdFx0ZGlzcGF0Y2hlci5zZW5kKFwiZ2V0T3JnYW5pemF0aW9uUHJvamVjdHNcIiwgc2VsZWN0ZWRPcmdhbml6YXRpb24pO1xuXHR9IGVsc2Uge1xuXHRcdGRpc3BhdGNoZXIuc2VuZChcImV4cG9ydFwiKTtcblx0fVxufVxuXG5bXS5mb3JFYWNoLmNhbGwoXG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi5yZXRyeVwiKSxcbiAgICBmdW5jdGlvbiAocmV0cnkpIHtcbiAgICAgICAgcmV0cnkuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIG9uQ2xpY2tSZXRyeSk7XG4gICAgfVxuKTtcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi4vRXh0ZW5zaW9uQ29udGVudC9zcmMvcmV0cnkuanMiLCJpbXBvcnQgc29ja2V0IGZyb20gXCIuL3NvY2tldFwiO1xuaW1wb3J0IGxvZ2dlciBmcm9tIFwiLi9sb2dnZXJcIjtcblxudmFyIG1haW4gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwibWFpblwiKSxcbiAgICBzZWxlY3RlZEFydGJvYXJkSW5mb3JtYXRpb24gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInNlbGVjdGVkQXJ0Ym9hcmRJbmZvcm1hdGlvblwiKSxcbiAgICBzZWxlY3RQcm9qZWN0RGl2ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJzZWxlY3RQcm9qZWN0XCIpLFxuICAgIGV4cG9ydFNlbGVjdGVkQXJ0Ym9hcmRzID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJleHBvcnRTZWxlY3RlZEFydGJvYXJkc1wiKSxcbiAgICBza2lwQ2hlY2tib3ggPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdpbnB1dFt0eXBlPVwiY2hlY2tib3hcIl0nKSxcbiAgICBleHBvcnRpbmdPbmUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2V4cG9ydGluZ09uZSBzcGFuXCIpLFxuICAgIGV4cG9ydGluZ01hbnkgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2V4cG9ydGluZ01hbnkgc3BhblwiKSxcbiAgICBzZWxlY3RlZExheWVyQ291bnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3NlbGVjdGVkTGF5ZXJJbmZvcm1hdGlvbiBzdHJvbmdcIiksXG4gICAgc2VsZWN0ZWRMYXllckdyb3VwQ291bnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3NlbGVjdGVkTGF5ZXJHcm91cEluZm9ybWF0aW9uIHN0cm9uZ1wiKSxcbiAgICBtYXJrQXNBc3NldCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibWFya0FzQXNzZXRcIiksXG4gICAgdW5tYXJrQXNBc3NldCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidW5tYXJrQXNBc3NldFwiKSxcbiAgICBzZWxlY3RlZExheWVycyA9IFtdO1xuXG5mdW5jdGlvbiBwcm9jZXNzQXJ0Ym9hcmRTZWxlY3Rpb24oYXJ0Ym9hcmRDb3VudCwgc2VsZWN0aW9uQ291bnQpIHtcblx0dmFyIHJldHVybkVhcmx5ID0gZmFsc2U7XG5cdGlmIChhcnRib2FyZENvdW50ID4gMCkge1xuXHRcdGRvY3VtZW50LmJvZHkuY2xhc3NOYW1lID0gXCJzZWxlY3Rpb25EaXNwbGF5XCI7XG5cdFx0c2VsZWN0ZWRBcnRib2FyZENvdW50LnRleHRDb250ZW50ID0gYXJ0Ym9hcmRDb3VudDsgXG5cdFx0aWYgKGFydGJvYXJkQ291bnQgPiAxKSB7XG5cdFx0XHRzZWxlY3RlZEFydGJvYXJkSW5mb3JtYXRpb24uZGF0YXNldC5tYW55ID0gdHJ1ZTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0ZGVsZXRlIHNlbGVjdGVkQXJ0Ym9hcmRJbmZvcm1hdGlvbi5kYXRhc2V0Lm1hbnk7XG5cdFx0fVxuXHR9IGVsc2Uge1xuXHRcdGRvY3VtZW50LmJvZHkuY2xhc3NOYW1lID0gXCJhcnRib2FyZFNlbGVjdGlvblwiO1xuXHRcdGlmIChhcnRib2FyZENvdW50ID09PSAwICYmIHNlbGVjdGlvbkNvdW50ID4gMCkge1xuXHRcdFx0ZG9jdW1lbnQuYm9keS5jbGFzc05hbWUgPSBcIm5vQXJ0Ym9hcmRTZWxlY3RlZFwiO1xuXHRcdFx0ZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QudG9nZ2xlKFwic2VsZWN0ZWRNdWx0aXBsZUxheWVyc1wiLCBzZWxlY3Rpb25Db3VudCA+IDEpO1xuXHRcdH1cblx0XHRyZXR1cm5FYXJseSA9IHRydWU7XG5cdH1cblx0cmV0dXJuIHJldHVybkVhcmx5O1xufVxuXG5mdW5jdGlvbiB1cGRhdGVTZWxlY3Rpb25JbmZvKHNlbGVjdGlvbiwgYXJ0Ym9hcmRzKSB7XG5cdGlmIChkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5jb250YWlucyhcImdldHRpbmdQcm9qZWN0c1wiKSB8fCBzZWxlY3RQcm9qZWN0RGl2LmNsYXNzTGlzdC5jb250YWlucyhcImdldHRpbmdPcmdhbml6YXRpb25Qcm9qZWN0c1wiKSkge1xuXHRcdHJldHVybjtcblx0fVxuXHRleHBvcnRTZWxlY3RlZEFydGJvYXJkcy5kaXNhYmxlZCA9IGZhbHNlO1xuXHRza2lwQ2hlY2tib3guZGlzYWJsZWQgPSBmYWxzZTtcblx0c2VsZWN0ZWRMYXllcnMgPSBzZWxlY3Rpb247XG5cblx0aWYgKHNlbGVjdGlvbikge1xuXHRcdHZhciBhcnRib2FyZENvdW50ID0gYXJ0Ym9hcmRzLmxlbmd0aDtcblx0XHRpZiAocHJvY2Vzc0FydGJvYXJkU2VsZWN0aW9uKGFydGJvYXJkQ291bnQsIHNlbGVjdGlvbi5sZW5ndGgpKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdG1haW4uZGF0YXNldC5hcnRib2FyZENvdW50ID0gYXJ0Ym9hcmRDb3VudDtcblxuXHRcdHZhciBsYXllcnMgPSBzZWxlY3Rpb24uZmlsdGVyKGZ1bmN0aW9uIChpdGVtKSB7XG5cdFx0XHRyZXR1cm4gaXRlbS50eXBlID09PSBcImxheWVyXCI7XG5cdFx0fSk7XG5cdFx0dmFyIGxheWVyR3JvdXBzID0gc2VsZWN0aW9uLmZpbHRlcihmdW5jdGlvbiAoaXRlbSkge1xuXHRcdFx0cmV0dXJuIGl0ZW0udHlwZSA9PT0gXCJsYXllclNlY3Rpb25cIjtcblx0XHR9KTtcblxuXHRcdGlmIChhcnRib2FyZENvdW50ID09PSAxKSB7XG5cdFx0XHRleHBvcnRpbmdPbmUudGV4dENvbnRlbnQgPSBhcnRib2FyZHNbMF0ubmFtZTtcblx0XHR9IGVsc2UgaWYgKGFydGJvYXJkQ291bnQgPiAxKSB7XG5cdFx0XHRleHBvcnRpbmdNYW55LnRleHRDb250ZW50ID0gYXJ0Ym9hcmRDb3VudDtcblx0XHR9XG5cblx0XHRzZWxlY3RlZExheWVyQ291bnQudGV4dENvbnRlbnQgPSBsYXllcnMubGVuZ3RoO1xuXHRcdHNlbGVjdGVkTGF5ZXJDb3VudC5jbGFzc0xpc3QudG9nZ2xlKFwibWFueUxheWVyc1wiLCBsYXllcnMubGVuZ3RoID4gMSk7XG5cblx0XHRzZWxlY3RlZExheWVyR3JvdXBDb3VudC50ZXh0Q29udGVudCA9IGxheWVyR3JvdXBzLmxlbmd0aDtcblx0XHRzZWxlY3RlZExheWVyR3JvdXBDb3VudC5jbGFzc0xpc3QudG9nZ2xlKFwibWFueUxheWVyR3JvdXBzXCIsIGxheWVyR3JvdXBzLmxlbmd0aCA+IDEpO1xuXG5cdFx0aWYgKGxheWVyR3JvdXBzLmxlbmd0aCA+PSAxICYmIGFydGJvYXJkQ291bnQgPT09IDEgJiYgbGF5ZXJzLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0dmFyIGV4cG9ydGFibGVMYXllckdyb3VwQ291bnQgPSBsYXllckdyb3Vwcy5maWx0ZXIoZnVuY3Rpb24gKGxheWVyR3JvdXApIHtcblx0XHRcdFx0cmV0dXJuIGxheWVyR3JvdXAuZXhwb3J0YWJsZTtcblx0XHRcdH0pLmxlbmd0aDtcblxuXHRcdFx0aWYgKGV4cG9ydGFibGVMYXllckdyb3VwQ291bnQgPiAwKSB7XG5cdFx0XHRcdGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LmFkZChcIm1hcmtMYXllckdyb3VwQXNBc3NldFwiKTtcdFxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0ZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QuYWRkKFwidW5tYXJrTGF5ZXJHcm91cEFzQXNzZXRcIik7XG5cdFx0XHR9XG5cblx0XHRcdGlmIChsYXllckdyb3Vwcy5sZW5ndGggPT09IDEpIHtcblx0XHRcdFx0ZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QuYWRkKFwib25lTGF5ZXJHcm91cFwiKTtcblx0XHRcdFx0c2tpcENoZWNrYm94LmNoZWNrZWQgPSAhbGF5ZXJHcm91cHNbMF0uc2tpcHBhYmxlO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSBpZiAobGF5ZXJzLmxlbmd0aCA+IDApIHtcblx0XHRcdHZhciBleHBvcnRhYmxlTGF5ZXJDb3VudCA9IHNlbGVjdGlvbi5maWx0ZXIoZnVuY3Rpb24gKGxheWVyKSB7XG5cdFx0XHRcdHJldHVybiBsYXllci5leHBvcnRhYmxlO1xuXHRcdFx0fSkubGVuZ3RoO1xuXG5cdFx0XHRpZiAoZXhwb3J0YWJsZUxheWVyQ291bnQgPiAwKSB7XG5cdFx0XHRcdGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LmFkZChcIm1hcmtMYXllckFzQXNzZXRcIik7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5hZGQoXCJ1bm1hcmtMYXllckFzQXNzZXRcIik7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG59XG5cbnNvY2tldC5vbihcImFjdGl2ZURvY3VtZW50Q2hhbmdlZFwiLCBmdW5jdGlvbiAoZGF0YSkge1xuXHRsb2dnZXIuaW5mbyhcImFjdGl2ZURvY3VtZW50Q2hhbmdlZDogJWpcIiwgZGF0YSwge30pO1xuXHR1cGRhdGVTZWxlY3Rpb25JbmZvKGRhdGEuc2VsZWN0aW9uLCBkYXRhLmFydGJvYXJkcyk7XG59KTtcblxubWFya0FzQXNzZXQuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uIChldikge1xuXHRzb2NrZXQuZW1pdChcInJlbmFtZVwiLCB7XG5cdFx0ZXhwb3J0OiB0cnVlLCBcblx0XHRza2lwOiBmYWxzZSwgXG5cdFx0bGF5ZXJzOiBzZWxlY3RlZExheWVycywgXG5cdFx0Y2hlY2tlZDogdHJ1ZVxuXHR9KTtcdFxufSk7XG5cbnVubWFya0FzQXNzZXQuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uIChldikge1xuXHRzb2NrZXQuZW1pdChcInJlbmFtZVwiLCB7XG5cdFx0ZXhwb3J0OiB0cnVlLCBcblx0XHRza2lwOiBmYWxzZSwgXG5cdFx0bGF5ZXI6IHNlbGVjdGVkTGF5ZXJzLCBcblx0XHRjaGVja2VkOiBmYWxzZVxuXHR9KTtcdFxufSk7XG5cbnNraXBDaGVja2JveC5hZGRFdmVudExpc3RlbmVyIChcImNoYW5nZVwiLCBmdW5jdGlvbiAoZXYpIHtcblx0c29ja2V0LmVtaXQoXCJyZW5hbWVcIiwge1xuXHRcdGV4cG9ydDogZmFsc2UsIFxuXHRcdHNraXA6IHRydWUsIFxuXHRcdGxheWVyczogc2VsZWN0ZWRMYXllcnMsIFxuXHRcdGNoZWNrZWQ6IGV2LnRhcmdldC5jaGVja2VkXG5cdH0pO1x0XG59KTtcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi4vRXh0ZW5zaW9uQ29udGVudC9zcmMvc2VsZWN0aW9uLmpzIiwiZnVuY3Rpb24gZ2V0Rmlyc3RTY3JvbGxhYmxlUGFyZW50KGVsZW1lbnQpIHtcblx0dmFyIGNvbnRhaW5lciA9IGVsZW1lbnQucGFyZW50RWxlbWVudDtcblxuXHQvLyBmaW5kIGZpcnN0IHNjcm9sbGFibGUgY29udGFpbmVyXG5cdHdoaWxlIChjb250YWluZXIgJiYgY29udGFpbmVyLnNjcm9sbEhlaWdodCA8PSBjb250YWluZXIuY2xpZW50SGVpZ2h0KSB7XG5cdFx0Y29udGFpbmVyID0gY29udGFpbmVyLnBhcmVudEVsZW1lbnQ7XG5cdH1cblxuXHRyZXR1cm4gY29udGFpbmVyO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc2Nyb2xsSWZOZWNlc3NhcnkoZWxlbWVudCwgY29udGFpbmVyKSB7XG5cdGNvbnRhaW5lciA9IGNvbnRhaW5lciB8fCBnZXRGaXJzdFNjcm9sbGFibGVQYXJlbnQoZWxlbWVudCk7XG5cblx0aWYgKCFjb250YWluZXIpIHtcblx0XHRyZXR1cm47XG5cdH1cblxuXHR2YXIgZWxlbWVudFJlY3QgPSBlbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxuXHRcdGNvbnRhaW5lclJlY3QgPSBjb250YWluZXIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG5cblx0aWYgKGVsZW1lbnRSZWN0LnRvcCA8IGNvbnRhaW5lclJlY3QudG9wKSB7XG5cdFx0Y29udGFpbmVyLnNjcm9sbFRvcCAtPSBjb250YWluZXJSZWN0LnRvcCAtIGVsZW1lbnRSZWN0LnRvcDtcblx0fSBlbHNlIGlmIChlbGVtZW50UmVjdC5ib3R0b20gPiBjb250YWluZXJSZWN0LmJvdHRvbSkge1xuXHRcdGNvbnRhaW5lci5zY3JvbGxUb3AgKz0gZWxlbWVudFJlY3QuYm90dG9tIC0gY29udGFpbmVyUmVjdC5ib3R0b207XG5cdH1cbn1cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi4vRXh0ZW5zaW9uQ29udGVudC9zcmMvdXRpbC5qcyIsIm1vZHVsZS5leHBvcnRzID0gQ1NJbnRlcmZhY2U7XG5cblxuLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBXRUJQQUNLIEZPT1RFUlxuLy8gZXh0ZXJuYWwgXCJDU0ludGVyZmFjZVwiXG4vLyBtb2R1bGUgaWQgPSAyMFxuLy8gbW9kdWxlIGNodW5rcyA9IDAiLCJtb2R1bGUuZXhwb3J0cyA9IHBhdGg7XG5cblxuLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBXRUJQQUNLIEZPT1RFUlxuLy8gZXh0ZXJuYWwgXCJwYXRoXCJcbi8vIG1vZHVsZSBpZCA9IDIxXG4vLyBtb2R1bGUgY2h1bmtzID0gMCIsIm1vZHVsZS5leHBvcnRzID0gd2luc3RvbjtcblxuXG4vLy8vLy8vLy8vLy8vLy8vLy9cbi8vIFdFQlBBQ0sgRk9PVEVSXG4vLyBleHRlcm5hbCBcIndpbnN0b25cIlxuLy8gbW9kdWxlIGlkID0gMjJcbi8vIG1vZHVsZSBjaHVua3MgPSAwIiwiaW1wb3J0IFwiLi9zb2NrZXRcIjtcbmltcG9ydCBcIi4vYmdjb2xvclwiO1xuaW1wb3J0IFwiLi9jb25uZWN0aW9uXCI7XG5pbXBvcnQgXCIuL3NlbGVjdGlvblwiO1xuaW1wb3J0IFwiLi9leHBvcnRcIjtcbmltcG9ydCBcIi4vcHJvamVjdHNcIjtcbmltcG9ydCBcIi4vcmV0cnlcIjtcbmltcG9ydCBcIi4vZXJyb3JcIjtcbmltcG9ydCBcIi4vbGlua3NcIjtcblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi4vRXh0ZW5zaW9uQ29udGVudC9zcmMvZXh0ZW5zaW9uLmpzIl0sInNvdXJjZVJvb3QiOiIifQ==